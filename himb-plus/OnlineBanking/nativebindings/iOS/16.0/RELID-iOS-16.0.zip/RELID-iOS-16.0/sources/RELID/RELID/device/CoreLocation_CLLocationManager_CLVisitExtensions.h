#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreLocation_CLLocationManager_CLVisitExtensions_symbols(JSContext*);
@protocol CLLocationManagerCLVisitExtensionsCategoryInstanceExports<JSExport>
-(void) startMonitoringVisits;
-(void) stopMonitoringVisits;
@end
@protocol CLLocationManagerCLVisitExtensionsCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop