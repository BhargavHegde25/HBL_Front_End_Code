#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreLocation_CLLocationPushServiceExtension_symbols(JSContext*);
@protocol CLLocationPushServiceExtensionInstanceExports_<JSExport, NSObjectInstanceExports_>
JSExportAs(didReceiveLocationPushPayloadCompletion,
-(void) jsdidReceiveLocationPushPayload: (NSDictionary *) payload completion: (JSValue *) completion );
-(void) serviceExtensionWillTerminate;
@end
@protocol CLLocationPushServiceExtensionClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop