#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreImage_CIContext_symbols(JSContext*);
@protocol CIContextInstanceExports<JSExport>
@property (readonly,nonatomic) id workingColorSpace;
@property (readonly,nonatomic) CIFormat workingFormat;
JSExportAs(initWithOptions,
-(id) jsinitWithOptions: (NSDictionary *) options );
-(id) jsinit;
-(void) drawImage: (CIImage *) image atPoint: (CGPoint) atPoint fromRect: (CGRect) fromRect ;
-(void) drawImage: (CIImage *) image inRect: (CGRect) inRect fromRect: (CGRect) fromRect ;
-(void) render: (CIImage *) image toIOSurface: (id) surface bounds: (CGRect) bounds colorSpace: (id) colorSpace ;
-(void) render: (CIImage *) image toCVPixelBuffer: (id) buffer ;
-(void) render: (CIImage *) image toCVPixelBuffer: (id) buffer bounds: (CGRect) bounds colorSpace: (id) colorSpace ;
-(void) render: (CIImage *) image toMTLTexture: (id) texture commandBuffer: (id) commandBuffer bounds: (CGRect) bounds colorSpace: (id) colorSpace ;
-(void) clearCaches;
-(CGSize) inputImageMaximumSize;
-(CGSize) outputImageMaximumSize;
@end
@protocol CIContextClassExports<JSExport>
+(CIContext *) contextWithCGContext: (id) cgctx options: (NSDictionary *) options ;
+(CIContext *) contextWithOptions: (NSDictionary *) options ;
+(CIContext *) context;
+(CIContext *) contextWithEAGLContext: (EAGLContext *) eaglContext ;
+(CIContext *) contextWithEAGLContext: (EAGLContext *) eaglContext options: (NSDictionary *) options ;
+(CIContext *) contextWithMTLDevice: (id) device ;
+(CIContext *) contextWithMTLDevice: (id) device options: (NSDictionary *) options ;
+(CIContext *) contextWithMTLCommandQueue: (id) commandQueue ;
+(CIContext *) contextWithMTLCommandQueue: (id) commandQueue options: (NSDictionary *) options ;
@end
@protocol CIContextcreateCGImageCategoryInstanceExports<JSExport>
-(id) createCGImage: (CIImage *) image fromRect: (CGRect) fromRect ;
-(id) createCGImage: (CIImage *) image fromRect: (CGRect) fromRect format: (CIFormat) format colorSpace: (id) colorSpace ;
-(id) createCGImage: (CIImage *) image fromRect: (CGRect) fromRect format: (CIFormat) format colorSpace: (id) colorSpace deferred: (BOOL) deferred ;
@end
@protocol CIContextcreateCGImageCategoryClassExports<JSExport>
@end
@protocol CIContextOfflineGPUSupportCategoryInstanceExports<JSExport>
@end
@protocol CIContextOfflineGPUSupportCategoryClassExports<JSExport>
@end
@protocol CIContextImageRepresentationCategoryInstanceExports<JSExport>
-(NSData *) TIFFRepresentationOfImage: (CIImage *) image format: (CIFormat) format colorSpace: (id) colorSpace options: (NSDictionary *) options ;
-(NSData *) JPEGRepresentationOfImage: (CIImage *) image colorSpace: (id) colorSpace options: (NSDictionary *) options ;
-(NSData *) HEIFRepresentationOfImage: (CIImage *) image format: (CIFormat) format colorSpace: (id) colorSpace options: (NSDictionary *) options ;
JSExportAs(HEIF10RepresentationOfImageColorSpaceOptionsError,
-(NSData *) jsHEIF10RepresentationOfImage: (CIImage *) image colorSpace: (id) colorSpace options: (NSDictionary *) options error: (JSValue *) errorPtr );
-(NSData *) PNGRepresentationOfImage: (CIImage *) image format: (CIFormat) format colorSpace: (id) colorSpace options: (NSDictionary *) options ;
JSExportAs(writeTIFFRepresentationOfImageToURLFormatColorSpaceOptionsError,
-(BOOL) jswriteTIFFRepresentationOfImage: (CIImage *) image toURL: (NSURL *) url format: (CIFormat) format colorSpace: (id) colorSpace options: (NSDictionary *) options error: (JSValue *) errorPtr );
JSExportAs(writePNGRepresentationOfImageToURLFormatColorSpaceOptionsError,
-(BOOL) jswritePNGRepresentationOfImage: (CIImage *) image toURL: (NSURL *) url format: (CIFormat) format colorSpace: (id) colorSpace options: (NSDictionary *) options error: (JSValue *) errorPtr );
JSExportAs(writeJPEGRepresentationOfImageToURLColorSpaceOptionsError,
-(BOOL) jswriteJPEGRepresentationOfImage: (CIImage *) image toURL: (NSURL *) url colorSpace: (id) colorSpace options: (NSDictionary *) options error: (JSValue *) errorPtr );
JSExportAs(writeHEIFRepresentationOfImageToURLFormatColorSpaceOptionsError,
-(BOOL) jswriteHEIFRepresentationOfImage: (CIImage *) image toURL: (NSURL *) url format: (CIFormat) format colorSpace: (id) colorSpace options: (NSDictionary *) options error: (JSValue *) errorPtr );
JSExportAs(writeHEIF10RepresentationOfImageToURLColorSpaceOptionsError,
-(BOOL) jswriteHEIF10RepresentationOfImage: (CIImage *) image toURL: (NSURL *) url colorSpace: (id) colorSpace options: (NSDictionary *) options error: (JSValue *) errorPtr );
@end
@protocol CIContextImageRepresentationCategoryClassExports<JSExport>
@end
@protocol CIContextCIDepthBlurEffectCategoryInstanceExports<JSExport>
-(CIFilter *) depthBlurEffectFilterForImageURL: (NSURL *) url options: (NSDictionary *) options ;
-(CIFilter *) depthBlurEffectFilterForImageData: (NSData *) data options: (NSDictionary *) options ;
-(CIFilter *) depthBlurEffectFilterForImage: (CIImage *) image disparityImage: (CIImage *) disparityImage portraitEffectsMatte: (CIImage *) portraitEffectsMatte orientation: (CGImagePropertyOrientation) orientation options: (NSDictionary *) options ;
-(CIFilter *) depthBlurEffectFilterForImage: (CIImage *) image disparityImage: (CIImage *) disparityImage portraitEffectsMatte: (CIImage *) portraitEffectsMatte hairSemanticSegmentation: (CIImage *) hairSemanticSegmentation orientation: (CGImagePropertyOrientation) orientation options: (NSDictionary *) options ;
-(CIFilter *) depthBlurEffectFilterForImage: (CIImage *) image disparityImage: (CIImage *) disparityImage portraitEffectsMatte: (CIImage *) portraitEffectsMatte hairSemanticSegmentation: (CIImage *) hairSemanticSegmentation glassesMatte: (CIImage *) glassesMatte gainMap: (CIImage *) gainMap orientation: (CGImagePropertyOrientation) orientation options: (NSDictionary *) options ;
@end
@protocol CIContextCIDepthBlurEffectCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop