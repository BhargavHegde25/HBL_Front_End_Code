#import <JavaScriptCore/JavaScriptCore.h>

void loadNFIMyPaymentUrlFrameworkModules(JSContext* context);
JSValue* extractNFIMyPaymentUrlFrameworkStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFIMyPaymentUrlFrameworkStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);
