#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Foundation_NSKeyValueSharedObservers_symbols(JSContext*);
@protocol NSKeyValueSharedObserversSnapshotInstanceExports<JSExport>
@end
@protocol NSKeyValueSharedObserversSnapshotClassExports<JSExport>
@end
@protocol NSKeyValueSharedObserversInstanceExports<JSExport>
JSExportAs(initWithObservableClass,
-(id) jsinitWithObservableClass: (JSValue *) observableClass );
-(NSKeyValueSharedObserversSnapshot *) snapshot;
@end
@protocol NSKeyValueSharedObserversClassExports<JSExport>
@end
@protocol NSObjectNSKeyValueSharedObserverRegistrationCategoryInstanceExports<JSExport>
-(void) setSharedObservers: (NSKeyValueSharedObserversSnapshot *) sharedObservers ;
@end
@protocol NSObjectNSKeyValueSharedObserverRegistrationCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop