#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Foundation_NSLocalizedNumberFormatRule_symbols(JSContext*);
@protocol NSLocalizedNumberFormatRuleInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@end
@protocol NSLocalizedNumberFormatRuleClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
+(NSLocalizedNumberFormatRule *) automatic;
@end
#pragma clang diagnostic pop