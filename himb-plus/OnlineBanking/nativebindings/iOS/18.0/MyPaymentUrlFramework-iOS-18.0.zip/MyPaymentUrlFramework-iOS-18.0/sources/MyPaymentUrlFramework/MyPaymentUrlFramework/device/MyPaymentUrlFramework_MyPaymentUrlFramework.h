#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_MyPaymentUrlFramework_MyPaymentUrlFramework_symbols(JSContext*);
@protocol MyPaymentUrlFrameworkInstanceExports<JSExport>
@property (copy,nonatomic) NSString * globalURLString;
@property (getter=getJsGlobalCallback,setter=setJsGlobalCallback:) JSValue* jsglobalCallback;
@property (getter=getJsCallback,setter=setJsCallback:) JSValue* jscallback;
JSExportAs(loadURLCallback,
-(void) jsloadURL: (NSString *) urlString callback: (JSValue *) callback );
@end
@protocol MyPaymentUrlFrameworkClassExports<JSExport>
+(id) sharedInstance;
@end
#pragma clang diagnostic pop