#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
@implementation MyPaymentUrlFramework (Exports)
-(void) jsloadURL: (NSString *) urlString callback: (JSValue *) callback 
{
	void (^ callback_)(NSString *) = nil;
	if (!callback.isUndefined) {
		callback_ = ^void(NSString * arg0) {
			JSContext* __jsContext = callback.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: (arg0 ? [JSValue valueWithObject: arg0 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, callback, self, parameters);
		};
	}
	[self loadURL: urlString callback: callback_ ];
}
-(JSValue *) getJsGlobalCallback
{
	return [JSValue valueWithObject: self.globalCallback inContext: [JSContext currentContext]];
}
-(void) setJsGlobalCallback: (JSValue *) value
{
	void (^ value_)(NSString *) = nil;
	if (!value.isUndefined) {
		value_ = ^void(NSString * arg0) {
			JSContext* __jsContext = value.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: (arg0 ? [JSValue valueWithObject: arg0 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, value, self, parameters);
		};
	}
	self.globalCallback = value_;
}
-(JSValue *) getJsCallback
{
	return [JSValue valueWithObject: self.callback inContext: [JSContext currentContext]];
}
-(void) setJsCallback: (JSValue *) value
{
	void (^ value_)(NSString *) = nil;
	if (!value.isUndefined) {
		value_ = ^void(NSString * arg0) {
			JSContext* __jsContext = value.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: (arg0 ? [JSValue valueWithObject: arg0 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, value, self, parameters);
		};
	}
	self.callback = value_;
}
@end
static void addProtocols()
{
	class_addProtocol([MyPaymentUrlFramework class], @protocol(MyPaymentUrlFrameworkInstanceExports));
	class_addProtocol([MyPaymentUrlFramework class], @protocol(MyPaymentUrlFrameworkClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
	p = (void*) &MyPaymentUrlFrameworkVersionNumber;
	if (p != NULL) context[@"MyPaymentUrlFrameworkVersionNumber"] = @(MyPaymentUrlFrameworkVersionNumber);
}
void load_MyPaymentUrlFramework_MyPaymentUrlFramework_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
