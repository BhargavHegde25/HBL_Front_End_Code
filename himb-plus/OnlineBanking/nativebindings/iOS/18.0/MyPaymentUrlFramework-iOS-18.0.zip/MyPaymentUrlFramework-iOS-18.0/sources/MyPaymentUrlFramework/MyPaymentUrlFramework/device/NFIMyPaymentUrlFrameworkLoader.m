#import "allincludes.h"
#import <JavaScriptCore/JavaScriptCore.h>
void loadNFIMyPaymentUrlFrameworkModules(JSContext* context)
{
	load_MyPaymentUrlFramework_MyPaymentUrlFramework_symbols(context);
}

JSValue* extractNFIMyPaymentUrlFrameworkStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context)
{
    
    return nil;
}

BOOL setNFIMyPaymentUrlFrameworkStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation)
{
    
    return NO;
}

