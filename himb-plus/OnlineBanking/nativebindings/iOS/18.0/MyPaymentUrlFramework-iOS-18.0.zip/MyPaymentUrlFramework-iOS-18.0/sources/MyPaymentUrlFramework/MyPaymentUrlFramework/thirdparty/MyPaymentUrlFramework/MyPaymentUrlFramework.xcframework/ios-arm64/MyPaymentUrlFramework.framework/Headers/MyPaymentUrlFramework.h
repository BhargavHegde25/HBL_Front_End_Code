//
//  MyPaymentUrlFramework.h
//  MyPaymentUrlFramework
//
//  Created by BCT Temenos on 11/03/25.
//

#import <Foundation/Foundation.h>

//! Project version number for MyPaymentUrlFramework.
FOUNDATION_EXPORT double MyPaymentUrlFrameworkVersionNumber;

//! Project version string for MyPaymentUrlFramework.
FOUNDATION_EXPORT const unsigned char MyPaymentUrlFrameworkVersionString[];




@interface MyPaymentUrlFramework : NSObject

@property (nonatomic, copy) NSString *globalURLString;
@property (nonatomic, copy) void (^globalCallback)(NSString *response);
@property (nonatomic, copy) void (^callback)(NSString *response);

+ (instancetype)sharedInstance;
- (void)loadURL:(NSString *)urlString callback:(void (^)(NSString *response))callback;

@end



