#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
static void addProtocols()
{
}
static void registerCFunctions(JSContext* context)
{
	context[@"SecKeyGetTypeID"] = ^CFTypeID() {
		return SecKeyGetTypeID();
	};
	context[@"SecKeyGetBlockSize"] = ^size_t(id arg0) {
		return SecKeyGetBlockSize(arg0);
	};
	context[@"SecKeyCopyAttributes"] = ^id(id arg0) {
		return SecKeyCopyAttributes(arg0);
	};
	context[@"SecKeyCopyPublicKey"] = ^id(id arg0) {
		return SecKeyCopyPublicKey(arg0);
	};
}
static void registerEnumConstants(JSContext* context)
{

	context[@"kSecPaddingNone"] = @0U;
	context[@"kSecPaddingPKCS1"] = @1U;
	context[@"kSecPaddingOAEP"] = @2U;
	context[@"kSecPaddingSigRaw"] = @16384U;
	context[@"kSecPaddingPKCS1MD2"] = @32768U;
	context[@"kSecPaddingPKCS1MD5"] = @32769U;
	context[@"kSecPaddingPKCS1SHA1"] = @32770U;
	context[@"kSecPaddingPKCS1SHA224"] = @32771U;
	context[@"kSecPaddingPKCS1SHA256"] = @32772U;
	context[@"kSecPaddingPKCS1SHA384"] = @32773U;
	context[@"kSecPaddingPKCS1SHA512"] = @32774U;


	context[@"kSecKeyOperationTypeSign"] = @0L;
	context[@"kSecKeyOperationTypeVerify"] = @1L;
	context[@"kSecKeyOperationTypeEncrypt"] = @2L;
	context[@"kSecKeyOperationTypeDecrypt"] = @3L;
	context[@"kSecKeyOperationTypeKeyExchange"] = @4L;

}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
	p = (void*) &kSecPrivateKeyAttrs;
	if (p != NULL) context[@"kSecPrivateKeyAttrs"] = [JSValue valueWithObject: (__bridge id) kSecPrivateKeyAttrs inContext: context];
	p = (void*) &kSecPublicKeyAttrs;
	if (p != NULL) context[@"kSecPublicKeyAttrs"] = [JSValue valueWithObject: (__bridge id) kSecPublicKeyAttrs inContext: context];
}
void load_Security_SecKey_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
