#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreImage_CIImageProcessor_symbols(JSContext*);
@protocol CIImageProcessorKernelInstanceExports<JSExport>
@end
@protocol CIImageProcessorKernelClassExports<JSExport>
JSExportAs(processWithInputsArgumentsOutputError,
+(BOOL) jsprocessWithInputs: (NSArray *) inputs arguments: (NSDictionary *) arguments output: (id) output error: (JSValue *) error );
+(CGRect) roiForInput: (int) input arguments: (NSDictionary *) arguments outputRect: (CGRect) outputRect ;
+(NSArray *) roiTileArrayForInput: (int) input arguments: (NSDictionary *) arguments outputRect: (CGRect) outputRect ;
+(CIFormat) formatForInputAtIndex: (int) input ;
JSExportAs(applyWithExtentInputsArgumentsError,
+(CIImage *) jsapplyWithExtent: (CGRect) extent inputs: (NSArray *) inputs arguments: (NSDictionary *) args error: (JSValue *) error );
+(CIFormat) outputFormat;
+(_Bool) outputIsOpaque;
+(_Bool) synchronizeInputs;
@end
@protocol CIImageProcessorInputInstanceExports_<JSExport>
@property (readonly,nonatomic) CGRect region;
@property (readonly,nonatomic) size_t bytesPerRow;
@property (readonly,nonatomic) CIFormat format;
@property (readonly,nonatomic) id surface;
@property (readonly,nonatomic) id metalTexture;
@property (readonly,nonatomic) uint64_t digest;
@property (readonly,nonatomic) NSUInteger roiTileIndex;
@property (readonly,nonatomic) NSUInteger roiTileCount;
@end
@protocol CIImageProcessorInputClassExports_<JSExport>
@end
@protocol CIImageProcessorOutputInstanceExports_<JSExport>
@property (readonly,nonatomic) CGRect region;
@property (readonly,nonatomic) size_t bytesPerRow;
@property (readonly,nonatomic) CIFormat format;
@property (readonly,nonatomic) id surface;
@property (readonly,nonatomic) id metalTexture;
@property (readonly,nonatomic) id metalCommandBuffer;
@property (readonly,nonatomic) uint64_t digest;
@end
@protocol CIImageProcessorOutputClassExports_<JSExport>
@end
#pragma clang diagnostic pop