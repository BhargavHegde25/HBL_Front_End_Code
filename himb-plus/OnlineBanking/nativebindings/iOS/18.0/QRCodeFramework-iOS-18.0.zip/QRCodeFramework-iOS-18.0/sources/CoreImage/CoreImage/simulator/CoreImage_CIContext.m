#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
@implementation CIContext (Exports)
-(id) jsinitWithOptions: (NSDictionary *) options 
{
	id resultVal__;
	resultVal__ = [[self initWithOptions: options ] autorelease];
	return resultVal__;
}
-(id) jsinit
{
	id resultVal__;
	resultVal__ = [[self init] autorelease];
	return resultVal__;
}
@end
@implementation CIContext (CIContextImageRepresentationCategoryExports)
-(NSData *) jsHEIF10RepresentationOfImage: (CIImage *) image colorSpace: (id) colorSpace options: (NSDictionary *) options error: (JSValue *) errorPtr 
{
	NSError* errorPtr_ = nil;
	NSData * resultVal__;
	resultVal__ = [self HEIF10RepresentationOfImage: image colorSpace: colorSpace options: options error: &errorPtr_ ];
	if (errorPtr_ && [errorPtr isObject]) {
		errorPtr[@"error"] = errorPtr_;
	}
	return resultVal__;
}
-(NSData *) jsOpenEXRRepresentationOfImage: (CIImage *) image options: (NSDictionary *) options error: (JSValue *) errorPtr 
{
	NSError* errorPtr_ = nil;
	NSData * resultVal__;
	resultVal__ = [self OpenEXRRepresentationOfImage: image options: options error: &errorPtr_ ];
	if (errorPtr_ && [errorPtr isObject]) {
		errorPtr[@"error"] = errorPtr_;
	}
	return resultVal__;
}
-(BOOL) jswriteTIFFRepresentationOfImage: (CIImage *) image toURL: (NSURL *) url format: (CIFormat) format colorSpace: (id) colorSpace options: (NSDictionary *) options error: (JSValue *) errorPtr 
{
	NSError* errorPtr_ = nil;
	BOOL resultVal__;
	resultVal__ = [self writeTIFFRepresentationOfImage: image toURL: url format: format colorSpace: colorSpace options: options error: &errorPtr_ ];
	if (errorPtr_ && [errorPtr isObject]) {
		errorPtr[@"error"] = errorPtr_;
	}
	return resultVal__;
}
-(BOOL) jswritePNGRepresentationOfImage: (CIImage *) image toURL: (NSURL *) url format: (CIFormat) format colorSpace: (id) colorSpace options: (NSDictionary *) options error: (JSValue *) errorPtr 
{
	NSError* errorPtr_ = nil;
	BOOL resultVal__;
	resultVal__ = [self writePNGRepresentationOfImage: image toURL: url format: format colorSpace: colorSpace options: options error: &errorPtr_ ];
	if (errorPtr_ && [errorPtr isObject]) {
		errorPtr[@"error"] = errorPtr_;
	}
	return resultVal__;
}
-(BOOL) jswriteJPEGRepresentationOfImage: (CIImage *) image toURL: (NSURL *) url colorSpace: (id) colorSpace options: (NSDictionary *) options error: (JSValue *) errorPtr 
{
	NSError* errorPtr_ = nil;
	BOOL resultVal__;
	resultVal__ = [self writeJPEGRepresentationOfImage: image toURL: url colorSpace: colorSpace options: options error: &errorPtr_ ];
	if (errorPtr_ && [errorPtr isObject]) {
		errorPtr[@"error"] = errorPtr_;
	}
	return resultVal__;
}
-(BOOL) jswriteHEIFRepresentationOfImage: (CIImage *) image toURL: (NSURL *) url format: (CIFormat) format colorSpace: (id) colorSpace options: (NSDictionary *) options error: (JSValue *) errorPtr 
{
	NSError* errorPtr_ = nil;
	BOOL resultVal__;
	resultVal__ = [self writeHEIFRepresentationOfImage: image toURL: url format: format colorSpace: colorSpace options: options error: &errorPtr_ ];
	if (errorPtr_ && [errorPtr isObject]) {
		errorPtr[@"error"] = errorPtr_;
	}
	return resultVal__;
}
-(BOOL) jswriteHEIF10RepresentationOfImage: (CIImage *) image toURL: (NSURL *) url colorSpace: (id) colorSpace options: (NSDictionary *) options error: (JSValue *) errorPtr 
{
	NSError* errorPtr_ = nil;
	BOOL resultVal__;
	resultVal__ = [self writeHEIF10RepresentationOfImage: image toURL: url colorSpace: colorSpace options: options error: &errorPtr_ ];
	if (errorPtr_ && [errorPtr isObject]) {
		errorPtr[@"error"] = errorPtr_;
	}
	return resultVal__;
}
-(BOOL) jswriteOpenEXRRepresentationOfImage: (CIImage *) image toURL: (NSURL *) url options: (NSDictionary *) options error: (JSValue *) errorPtr 
{
	NSError* errorPtr_ = nil;
	BOOL resultVal__;
	resultVal__ = [self writeOpenEXRRepresentationOfImage: image toURL: url options: options error: &errorPtr_ ];
	if (errorPtr_ && [errorPtr isObject]) {
		errorPtr[@"error"] = errorPtr_;
	}
	return resultVal__;
}
@end
static void addProtocols()
{
	class_addProtocol([CIContext class], @protocol(CIContextInstanceExports));
	class_addProtocol([CIContext class], @protocol(CIContextClassExports));
	class_addProtocol([CIContext class], @protocol(CIContextcreateCGImageCategoryInstanceExports));
	class_addProtocol([CIContext class], @protocol(CIContextcreateCGImageCategoryClassExports));
	class_addProtocol([CIContext class], @protocol(CIContextOfflineGPUSupportCategoryInstanceExports));
	class_addProtocol([CIContext class], @protocol(CIContextOfflineGPUSupportCategoryClassExports));
	class_addProtocol([CIContext class], @protocol(CIContextImageRepresentationCategoryInstanceExports));
	class_addProtocol([CIContext class], @protocol(CIContextImageRepresentationCategoryClassExports));
	class_addProtocol([CIContext class], @protocol(CIContextCIDepthBlurEffectCategoryInstanceExports));
	class_addProtocol([CIContext class], @protocol(CIContextCIDepthBlurEffectCategoryClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
	p = (void*) &kCIContextOutputColorSpace;
	if (p != NULL) context[@"kCIContextOutputColorSpace"] = kCIContextOutputColorSpace;
	p = (void*) &kCIContextWorkingColorSpace;
	if (p != NULL) context[@"kCIContextWorkingColorSpace"] = kCIContextWorkingColorSpace;
	p = (void*) &kCIContextWorkingFormat;
	if (p != NULL) context[@"kCIContextWorkingFormat"] = kCIContextWorkingFormat;
	p = (void*) &kCIContextHighQualityDownsample;
	if (p != NULL) context[@"kCIContextHighQualityDownsample"] = kCIContextHighQualityDownsample;
	p = (void*) &kCIContextOutputPremultiplied;
	if (p != NULL) context[@"kCIContextOutputPremultiplied"] = kCIContextOutputPremultiplied;
	p = (void*) &kCIContextCacheIntermediates;
	if (p != NULL) context[@"kCIContextCacheIntermediates"] = kCIContextCacheIntermediates;
	p = (void*) &kCIContextUseSoftwareRenderer;
	if (p != NULL) context[@"kCIContextUseSoftwareRenderer"] = kCIContextUseSoftwareRenderer;
	p = (void*) &kCIContextPriorityRequestLow;
	if (p != NULL) context[@"kCIContextPriorityRequestLow"] = kCIContextPriorityRequestLow;
	p = (void*) &kCIContextAllowLowPower;
	if (p != NULL) context[@"kCIContextAllowLowPower"] = kCIContextAllowLowPower;
	p = (void*) &kCIContextName;
	if (p != NULL) context[@"kCIContextName"] = kCIContextName;
	p = (void*) &kCIContextMemoryLimit;
	if (p != NULL) context[@"kCIContextMemoryLimit"] = kCIContextMemoryLimit;
	p = (void*) &kCIImageRepresentationAVDepthData;
	if (p != NULL) context[@"kCIImageRepresentationAVDepthData"] = kCIImageRepresentationAVDepthData;
	p = (void*) &kCIImageRepresentationDepthImage;
	if (p != NULL) context[@"kCIImageRepresentationDepthImage"] = kCIImageRepresentationDepthImage;
	p = (void*) &kCIImageRepresentationDisparityImage;
	if (p != NULL) context[@"kCIImageRepresentationDisparityImage"] = kCIImageRepresentationDisparityImage;
	p = (void*) &kCIImageRepresentationAVPortraitEffectsMatte;
	if (p != NULL) context[@"kCIImageRepresentationAVPortraitEffectsMatte"] = kCIImageRepresentationAVPortraitEffectsMatte;
	p = (void*) &kCIImageRepresentationPortraitEffectsMatteImage;
	if (p != NULL) context[@"kCIImageRepresentationPortraitEffectsMatteImage"] = kCIImageRepresentationPortraitEffectsMatteImage;
	p = (void*) &kCIImageRepresentationAVSemanticSegmentationMattes;
	if (p != NULL) context[@"kCIImageRepresentationAVSemanticSegmentationMattes"] = kCIImageRepresentationAVSemanticSegmentationMattes;
	p = (void*) &kCIImageRepresentationSemanticSegmentationSkinMatteImage;
	if (p != NULL) context[@"kCIImageRepresentationSemanticSegmentationSkinMatteImage"] = kCIImageRepresentationSemanticSegmentationSkinMatteImage;
	p = (void*) &kCIImageRepresentationSemanticSegmentationHairMatteImage;
	if (p != NULL) context[@"kCIImageRepresentationSemanticSegmentationHairMatteImage"] = kCIImageRepresentationSemanticSegmentationHairMatteImage;
	p = (void*) &kCIImageRepresentationSemanticSegmentationTeethMatteImage;
	if (p != NULL) context[@"kCIImageRepresentationSemanticSegmentationTeethMatteImage"] = kCIImageRepresentationSemanticSegmentationTeethMatteImage;
	p = (void*) &kCIImageRepresentationSemanticSegmentationGlassesMatteImage;
	if (p != NULL) context[@"kCIImageRepresentationSemanticSegmentationGlassesMatteImage"] = kCIImageRepresentationSemanticSegmentationGlassesMatteImage;
	p = (void*) &kCIImageRepresentationSemanticSegmentationSkyMatteImage;
	if (p != NULL) context[@"kCIImageRepresentationSemanticSegmentationSkyMatteImage"] = kCIImageRepresentationSemanticSegmentationSkyMatteImage;
}
void load_CoreImage_CIContext_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
