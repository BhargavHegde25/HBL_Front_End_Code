#import <JavaScriptCore/JavaScriptCore.h>

void loadNFIShareFrameworkModules(JSContext* context);
JSValue* extractNFIShareFrameworkStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFIShareFrameworkStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);
