#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_CoreImage_CIImageProvider_symbols(JSContext*);
@protocol CIImageCIImageProviderCategoryInstanceExports<JSExport>
@end
@protocol CIImageCIImageProviderCategoryClassExports<JSExport>
@end
@protocol NSObjectCIImageProviderCategoryInstanceExports<JSExport>
@end
@protocol NSObjectCIImageProviderCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop