#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_FileProvider_NSFileProviderItem_symbols(JSContext*);
@protocol NSFileProviderItemVersionInstanceExports<JSExport>
@property (readonly,nonatomic) NSData * contentVersion;
@property (readonly,nonatomic) NSData * metadataVersion;
JSExportAs(initWithContentVersionMetadataVersion,
-(id) jsinitWithContentVersion: (NSData *) contentVersion metadataVersion: (NSData *) metadataVersion );
@end
@protocol NSFileProviderItemVersionClassExports<JSExport>
+(NSData *) beforeFirstSyncComponent;
@end
@protocol NSFileProviderItemInstanceExports_<JSExport, NSObjectInstanceExports_>
@property (readonly,copy,nonatomic) NSFileProviderItemIdentifier itemIdentifier;
@property (readonly,copy,nonatomic) NSFileProviderItemIdentifier parentItemIdentifier;
@property (readonly,copy,nonatomic) NSString * filename;
@property (readonly,copy,nonatomic) UTType * contentType;
@property (readonly,copy,nonatomic) NSString * typeIdentifier;
@property (readonly,nonatomic) NSFileProviderItemCapabilities capabilities;
@property (readonly,nonatomic) NSFileProviderFileSystemFlags fileSystemFlags;
@property (readonly,copy,nonatomic) NSNumber * documentSize;
@property (readonly,copy,nonatomic) NSNumber * childItemCount;
@property (readonly,copy,nonatomic) NSDate * creationDate;
@property (readonly,copy,nonatomic) NSDate * contentModificationDate;
@property (readonly,nonatomic,strong) NSDictionary * extendedAttributes;
@property (readonly,copy,nonatomic) NSDate * lastUsedDate;
@property (readonly,copy,nonatomic) NSData * tagData;
@property (readonly,copy,nonatomic) NSNumber * favoriteRank;
@property (getter=isTrashed,readonly,nonatomic) BOOL trashed;
@property (getter=isUploaded,readonly,nonatomic) BOOL uploaded;
@property (getter=isUploading,readonly,nonatomic) BOOL uploading;
@property (readonly,copy,nonatomic) NSError * uploadingError;
@property (getter=isDownloaded,readonly,nonatomic) BOOL downloaded;
@property (getter=isDownloading,readonly,nonatomic) BOOL downloading;
@property (readonly,copy,nonatomic) NSError * downloadingError;
@property (getter=isMostRecentVersionDownloaded,readonly,nonatomic) BOOL mostRecentVersionDownloaded;
@property (getter=isShared,readonly,nonatomic) BOOL shared;
@property (getter=isSharedByCurrentUser,readonly,nonatomic) BOOL sharedByCurrentUser;
@property (readonly,nonatomic,strong) NSPersonNameComponents * ownerNameComponents;
@property (readonly,nonatomic,strong) NSPersonNameComponents * mostRecentEditorNameComponents;
@property (readonly,nonatomic,strong) NSData * versionIdentifier;
@property (readonly,nonatomic,strong) NSFileProviderItemVersion * itemVersion;
@property (readonly,copy,nonatomic) NSString * symlinkTargetPath;
@property (readonly,nonatomic,strong) NSDictionary * userInfo;
@property (readonly,nonatomic) NSFileProviderContentPolicy contentPolicy;
@end
@protocol NSFileProviderItemClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop