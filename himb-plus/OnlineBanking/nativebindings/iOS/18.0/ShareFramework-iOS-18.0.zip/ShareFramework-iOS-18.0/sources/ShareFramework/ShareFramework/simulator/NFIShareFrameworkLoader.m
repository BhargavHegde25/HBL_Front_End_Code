#import "allincludes.h"
#import <JavaScriptCore/JavaScriptCore.h>
void loadNFIShareFrameworkModules(JSContext* context)
{
	load_ShareFramework_ShareFramework_symbols(context);
}

JSValue* extractNFIShareFrameworkStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context)
{
    
    return nil;
}

BOOL setNFIShareFrameworkStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation)
{
    
    return NO;
}

