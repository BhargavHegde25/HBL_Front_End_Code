#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_QuartzCore_CAEDRMetadata_symbols(JSContext*);
@protocol CAEDRMetadataInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@end
@protocol CAEDRMetadataClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
+(CAEDRMetadata *) HDR10MetadataWithDisplayInfo: (NSData *) displayData contentInfo: (NSData *) contentData opticalOutputScale: (float) scale ;
+(CAEDRMetadata *) HDR10MetadataWithMinLuminance: (float) minNits maxLuminance: (float) maxNits opticalOutputScale: (float) scale ;
+(CAEDRMetadata *) HLGMetadataWithAmbientViewingEnvironment: (NSData *) data ;
+(CAEDRMetadata *) HLGMetadata;
+(BOOL) isAvailable;
@end
#pragma clang diagnostic pop