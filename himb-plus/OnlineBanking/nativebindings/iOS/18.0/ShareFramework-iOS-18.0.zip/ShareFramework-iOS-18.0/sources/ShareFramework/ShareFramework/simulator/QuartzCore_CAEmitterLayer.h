#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_QuartzCore_CAEmitterLayer_symbols(JSContext*);
@protocol CAEmitterLayerInstanceExports<JSExport>
@property (copy) NSArray * emitterCells;
@property () float birthRate;
@property () float lifetime;
@property () CGPoint emitterPosition;
@property () CGFloat emitterZPosition;
@property () CGSize emitterSize;
@property () CGFloat emitterDepth;
@property (copy) CAEmitterLayerEmitterShape emitterShape;
@property (copy) CAEmitterLayerEmitterMode emitterMode;
@property (copy) CAEmitterLayerRenderMode renderMode;
@property () BOOL preservesDepth;
@property () float velocity;
@property () float scale;
@property () float spin;
@property () unsigned int seed;
@end
@protocol CAEmitterLayerClassExports<JSExport>
@end
#pragma clang diagnostic pop