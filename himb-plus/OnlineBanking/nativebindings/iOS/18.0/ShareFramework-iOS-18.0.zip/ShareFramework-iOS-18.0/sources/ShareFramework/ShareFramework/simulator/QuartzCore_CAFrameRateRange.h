#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_QuartzCore_CAFrameRateRange_symbols(JSContext*);
@interface JSValue (QuartzCore_CAFrameRateRange)
+(JSValue*) valueWithCAFrameRateRange: (CAFrameRateRange) s inContext: (JSContext*) context;
-(CAFrameRateRange) toCAFrameRateRange;
@end
#pragma clang diagnostic pop