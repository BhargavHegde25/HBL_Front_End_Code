#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_QuartzCore_CALayer_symbols(JSContext*);
@protocol CALayerInstanceExports<JSExport, NSSecureCodingInstanceExports_, CAMediaTimingInstanceExports_>
@property () CGRect bounds;
@property () CGPoint position;
@property () CGFloat zPosition;
@property () CGPoint anchorPoint;
@property () CGFloat anchorPointZ;
@property () CATransform3D transform;
@property () CGRect frame;
@property (getter=isHidden) BOOL hidden;
@property (getter=isDoubleSided) BOOL doubleSided;
@property (getter=isGeometryFlipped) BOOL geometryFlipped;
@property (readonly) CALayer * superlayer;
@property (copy) NSArray * sublayers;
@property () CATransform3D sublayerTransform;
@property (strong) __kindof CALayer * mask;
@property () BOOL masksToBounds;
@property (strong) id contents;
@property () CGRect contentsRect;
@property (copy) CALayerContentsGravity contentsGravity;
@property () CGFloat contentsScale;
@property () CGRect contentsCenter;
@property (copy) CALayerContentsFormat contentsFormat;
@property () BOOL wantsExtendedDynamicRangeContent;
@property (copy) CALayerContentsFilter minificationFilter;
@property (copy) CALayerContentsFilter magnificationFilter;
@property () float minificationFilterBias;
@property (getter=isOpaque) BOOL opaque;
@property () BOOL needsDisplayOnBoundsChange;
@property () BOOL drawsAsynchronously;
@property () CAEdgeAntialiasingMask edgeAntialiasingMask;
@property () BOOL allowsEdgeAntialiasing;
@property () id backgroundColor;
@property () CGFloat cornerRadius;
@property () CACornerMask maskedCorners;
@property (copy) CALayerCornerCurve cornerCurve;
@property () CGFloat borderWidth;
@property () id borderColor;
@property () float opacity;
@property () BOOL allowsGroupOpacity;
@property (strong) id compositingFilter;
@property (copy) NSArray * filters;
@property (copy) NSArray * backgroundFilters;
@property () BOOL shouldRasterize;
@property () CGFloat rasterizationScale;
@property () id shadowColor;
@property () float shadowOpacity;
@property () CGSize shadowOffset;
@property () CGFloat shadowRadius;
@property () id shadowPath;
@property (copy) NSDictionary * actions;
@property (copy) NSString * name;
@property (weak) id delegate;
@property (copy) NSDictionary * style;
-(id) jsinit;
JSExportAs(initWithLayer,
-(id) jsinitWithLayer: (id) layer );
-(id) presentationLayer;
-(id) modelLayer;
-(BOOL) shouldArchiveValueForKey: (NSString *) key ;
-(CGAffineTransform) affineTransform;
-(void) setAffineTransform: (CGAffineTransform) m ;
-(BOOL) contentsAreFlipped;
-(void) removeFromSuperlayer;
-(void) addSublayer: (CALayer *) layer ;
-(void) insertSublayer: (CALayer *) layer atIndex: (unsigned int) idx ;
-(void) insertSublayer: (CALayer *) layer below: (CALayer *) sibling ;
-(void) insertSublayer: (CALayer *) layer above: (CALayer *) sibling ;
-(void) replaceSublayer: (CALayer *) oldLayer with: (CALayer *) newLayer ;
-(CGPoint) convertPoint: (CGPoint) p fromLayer: (CALayer *) l ;
-(CGPoint) convertPoint: (CGPoint) p toLayer: (CALayer *) l ;
-(CGRect) convertRect: (CGRect) r fromLayer: (CALayer *) l ;
-(CGRect) convertRect: (CGRect) r toLayer: (CALayer *) l ;
-(CFTimeInterval) convertTime: (CFTimeInterval) t fromLayer: (CALayer *) l ;
-(CFTimeInterval) convertTime: (CFTimeInterval) t toLayer: (CALayer *) l ;
-(__kindof CALayer *) hitTest: (CGPoint) p ;
-(BOOL) containsPoint: (CGPoint) p ;
-(void) display;
-(void) setNeedsDisplay;
-(void) setNeedsDisplayInRect: (CGRect) r ;
-(BOOL) needsDisplay;
-(void) displayIfNeeded;
-(void) drawInContext: (id) ctx ;
-(void) renderInContext: (id) ctx ;
-(CGSize) preferredFrameSize;
-(void) setNeedsLayout;
-(BOOL) needsLayout;
-(void) layoutIfNeeded;
-(void) layoutSublayers;
-(id) actionForKey: (NSString *) event ;
-(void) addAnimation: (CAAnimation *) anim forKey: (NSString *) key ;
-(void) removeAllAnimations;
-(void) removeAnimationForKey: (NSString *) key ;
-(NSArray *) animationKeys;
-(__kindof CAAnimation *) animationForKey: (NSString *) key ;
@end
@protocol CALayerClassExports<JSExport, NSSecureCodingClassExports_, CAMediaTimingClassExports_>
+(id) layer;
+(id) defaultValueForKey: (NSString *) key ;
+(BOOL) needsDisplayForKey: (NSString *) key ;
+(CGFloat) cornerCurveExpansionFactor: (CALayerCornerCurve) curve ;
+(id) defaultActionForKey: (NSString *) event ;
@end
@protocol NSNullCAActionAdditionsCategoryInstanceExports<JSExport, CAActionInstanceExports_>
@end
@protocol NSNullCAActionAdditionsCategoryClassExports<JSExport, CAActionClassExports_>
@end
@protocol CAActionInstanceExports_<JSExport>
-(void) runActionForKey: (NSString *) event object: (id) anObject arguments: (NSDictionary *) dict ;
@end
@protocol CAActionClassExports_<JSExport>
@end
@protocol CALayerDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) displayLayer: (CALayer *) layer ;
-(void) drawLayer: (CALayer *) layer inContext: (id) ctx ;
-(void) layerWillDraw: (CALayer *) layer ;
-(void) layoutSublayersOfLayer: (CALayer *) layer ;
-(id) actionForLayer: (CALayer *) layer forKey: (NSString *) event ;
@end
@protocol CALayerDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop