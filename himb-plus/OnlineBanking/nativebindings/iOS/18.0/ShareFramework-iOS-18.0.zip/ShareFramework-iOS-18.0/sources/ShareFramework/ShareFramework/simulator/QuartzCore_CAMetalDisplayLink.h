#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_QuartzCore_CAMetalDisplayLink_symbols(JSContext*);
@protocol CAMetalDisplayLinkUpdateInstanceExports<JSExport>
@property (readonly,nonatomic) id drawable;
@property (readonly,nonatomic) CFTimeInterval targetTimestamp;
@property (readonly,nonatomic) CFTimeInterval targetPresentationTimestamp;
@end
@protocol CAMetalDisplayLinkUpdateClassExports<JSExport>
@end
@protocol CAMetalDisplayLinkInstanceExports<JSExport>
@property (nonatomic,weak) id delegate;
@property (nonatomic) float preferredFrameLatency;
@property (nonatomic) CAFrameRateRange preferredFrameRateRange;
@property (getter=isPaused,nonatomic) BOOL paused;
JSExportAs(initWithMetalLayer,
-(id) jsinitWithMetalLayer: (CAMetalLayer *) layer );
-(void) addToRunLoop: (NSRunLoop *) runloop forMode: (NSRunLoopMode) mode ;
-(void) removeFromRunLoop: (NSRunLoop *) runloop forMode: (NSRunLoopMode) mode ;
-(void) invalidate;
@end
@protocol CAMetalDisplayLinkClassExports<JSExport>
@end
@protocol CAMetalDisplayLinkDelegateInstanceExports_<JSExport>
-(void) metalDisplayLink: (CAMetalDisplayLink *) link needsUpdate: (CAMetalDisplayLinkUpdate *) update ;
@end
@protocol CAMetalDisplayLinkDelegateClassExports_<JSExport>
@end
#pragma clang diagnostic pop