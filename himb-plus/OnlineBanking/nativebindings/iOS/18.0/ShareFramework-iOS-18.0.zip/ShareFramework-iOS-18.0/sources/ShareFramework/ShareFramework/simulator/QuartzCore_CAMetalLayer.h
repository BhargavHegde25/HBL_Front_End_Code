#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_QuartzCore_CAMetalLayer_symbols(JSContext*);
@protocol CAMetalLayerInstanceExports<JSExport>
@property (retain) id device;
@property (readonly) id preferredDevice;
@property () MTLPixelFormat pixelFormat;
@property () BOOL framebufferOnly;
@property () CGSize drawableSize;
@property () NSUInteger maximumDrawableCount;
@property () BOOL presentsWithTransaction;
@property () id colorspace;
@property () BOOL wantsExtendedDynamicRangeContent;
@property (strong) CAEDRMetadata * EDRMetadata;
@property () BOOL allowsNextDrawableTimeout;
@property (copy) NSDictionary * developerHUDProperties;
-(id) nextDrawable;
@end
@protocol CAMetalLayerClassExports<JSExport>
@end
@protocol CAMetalDrawableInstanceExports_<JSExport, MTLDrawableInstanceExports_>
@property (readonly) id texture;
@property (readonly) CAMetalLayer * layer;
@end
@protocol CAMetalDrawableClassExports_<JSExport, MTLDrawableClassExports_>
@end
#pragma clang diagnostic pop