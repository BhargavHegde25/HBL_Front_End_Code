#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_QuartzCore_CARenderer_symbols(JSContext*);
@protocol CARendererInstanceExports<JSExport>
@property (strong) CALayer * layer;
@property () CGRect bounds;
-(CGRect) updateBounds;
-(void) addUpdateRect: (CGRect) r ;
-(void) render;
-(CFTimeInterval) nextFrameTime;
-(void) endFrame;
-(void) setDestination: (id) tex ;
@end
@protocol CARendererClassExports<JSExport>
+(CARenderer *) rendererWithMTLTexture: (id) tex options: (NSDictionary *) dict ;
@end
#pragma clang diagnostic pop