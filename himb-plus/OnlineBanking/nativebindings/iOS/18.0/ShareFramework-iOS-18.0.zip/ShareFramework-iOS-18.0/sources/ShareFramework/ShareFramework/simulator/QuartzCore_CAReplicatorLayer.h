#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_QuartzCore_CAReplicatorLayer_symbols(JSContext*);
@protocol CAReplicatorLayerInstanceExports<JSExport>
@property () NSInteger instanceCount;
@property () BOOL preservesDepth;
@property () CFTimeInterval instanceDelay;
@property () CATransform3D instanceTransform;
@property () id instanceColor;
@property () float instanceRedOffset;
@property () float instanceGreenOffset;
@property () float instanceBlueOffset;
@property () float instanceAlphaOffset;
@end
@protocol CAReplicatorLayerClassExports<JSExport>
@end
#pragma clang diagnostic pop