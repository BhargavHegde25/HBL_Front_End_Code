#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_QuartzCore_CAShapeLayer_symbols(JSContext*);
@protocol CAShapeLayerInstanceExports<JSExport>
@property () id path;
@property () id fillColor;
@property (copy) CAShapeLayerFillRule fillRule;
@property () id strokeColor;
@property () CGFloat strokeStart;
@property () CGFloat strokeEnd;
@property () CGFloat lineWidth;
@property () CGFloat miterLimit;
@property (copy) CAShapeLayerLineCap lineCap;
@property (copy) CAShapeLayerLineJoin lineJoin;
@property () CGFloat lineDashPhase;
@property (copy) NSArray * lineDashPattern;
@end
@protocol CAShapeLayerClassExports<JSExport>
@end
#pragma clang diagnostic pop