#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_QuartzCore_CATextLayer_symbols(JSContext*);
@protocol CATextLayerInstanceExports<JSExport>
@property (copy) id string;
@property () id font;
@property () CGFloat fontSize;
@property () id foregroundColor;
@property (getter=isWrapped) BOOL wrapped;
@property (copy) CATextLayerTruncationMode truncationMode;
@property (copy) CATextLayerAlignmentMode alignmentMode;
@property () BOOL allowsFontSubpixelQuantization;
@end
@protocol CATextLayerClassExports<JSExport>
@end
#pragma clang diagnostic pop