#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_QuartzCore_CATransaction_symbols(JSContext*);
@protocol CATransactionInstanceExports<JSExport>
@end
@protocol CATransactionClassExports<JSExport>
+(void) begin;
+(void) commit;
+(void) flush;
+(void) lock;
+(void) unlock;
+(CFTimeInterval) animationDuration;
+(void) setAnimationDuration: (CFTimeInterval) dur ;
+(CAMediaTimingFunction *) animationTimingFunction;
+(void) setAnimationTimingFunction: (CAMediaTimingFunction *) function ;
+(BOOL) disableActions;
+(void) setDisableActions: (BOOL) flag ;
+(void (^)(void)) completionBlock;
JSExportAs(setCompletionBlock,
+(void) jssetCompletionBlock: (JSValue *) block );
+(id) valueForKey: (NSString *) key ;
+(void) setValue: (id) anObject forKey: (NSString *) key ;
@end
#pragma clang diagnostic pop