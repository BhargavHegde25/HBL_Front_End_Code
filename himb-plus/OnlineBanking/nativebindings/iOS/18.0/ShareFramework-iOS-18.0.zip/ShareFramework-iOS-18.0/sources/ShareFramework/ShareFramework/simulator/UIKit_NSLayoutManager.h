#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_NSLayoutManager_symbols(JSContext*);
@protocol NSLayoutManagerInstanceExports<JSExport, NSSecureCodingInstanceExports_>
@property (assign,nonatomic) NSTextStorage * textStorage;
@property (readonly,nonatomic) NSArray * textContainers;
@property (nonatomic,weak) id delegate;
@property (nonatomic) BOOL showsInvisibleCharacters;
@property (nonatomic) BOOL showsControlCharacters;
@property (nonatomic) BOOL usesFontLeading;
@property (nonatomic) BOOL allowsNonContiguousLayout;
@property (readonly,nonatomic) BOOL hasNonContiguousLayout;
@property () BOOL limitsLayoutForSuspiciousContents;
@property () BOOL usesDefaultHyphenation;
@property (readonly,nonatomic) NSUInteger numberOfGlyphs;
@property (readonly,nonatomic) CGRect extraLineFragmentRect;
@property (readonly,nonatomic) CGRect extraLineFragmentUsedRect;
@property (readonly,nonatomic) NSTextContainer * extraLineFragmentTextContainer;
-(id) jsinit;
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
-(void) addTextContainer: (NSTextContainer *) container ;
-(void) insertTextContainer: (NSTextContainer *) container atIndex: (NSUInteger) index ;
-(void) removeTextContainerAtIndex: (NSUInteger) index ;
-(void) textContainerChangedGeometry: (NSTextContainer *) container ;
-(void) invalidateDisplayForCharacterRange: (NSRange) charRange ;
-(void) invalidateDisplayForGlyphRange: (NSRange) glyphRange ;
-(void) processEditingForTextStorage: (NSTextStorage *) textStorage edited: (NSTextStorageEditActions) editMask range: (NSRange) newCharRange changeInLength: (NSInteger) delta invalidatedRange: (NSRange) invalidatedCharRange ;
-(void) ensureGlyphsForCharacterRange: (NSRange) charRange ;
-(void) ensureGlyphsForGlyphRange: (NSRange) glyphRange ;
-(void) ensureLayoutForCharacterRange: (NSRange) charRange ;
-(void) ensureLayoutForGlyphRange: (NSRange) glyphRange ;
-(void) ensureLayoutForTextContainer: (NSTextContainer *) container ;
-(void) ensureLayoutForBoundingRect: (CGRect) bounds inTextContainer: (NSTextContainer *) container ;
-(BOOL) isValidGlyphIndex: (NSUInteger) glyphIndex ;
-(NSGlyphProperty) propertyForGlyphAtIndex: (NSUInteger) glyphIndex ;
-(NSUInteger) characterIndexForGlyphAtIndex: (NSUInteger) glyphIndex ;
-(NSUInteger) glyphIndexForCharacterAtIndex: (NSUInteger) charIndex ;
-(void) setTextContainer: (NSTextContainer *) container forGlyphRange: (NSRange) glyphRange ;
-(void) setLineFragmentRect: (CGRect) fragmentRect forGlyphRange: (NSRange) glyphRange usedRect: (CGRect) usedRect ;
-(void) setExtraLineFragmentRect: (CGRect) fragmentRect usedRect: (CGRect) usedRect textContainer: (NSTextContainer *) container ;
-(void) setLocation: (CGPoint) location forStartOfGlyphRange: (NSRange) glyphRange ;
-(void) setNotShownAttribute: (BOOL) flag forGlyphAtIndex: (NSUInteger) glyphIndex ;
-(void) setDrawsOutsideLineFragment: (BOOL) flag forGlyphAtIndex: (NSUInteger) glyphIndex ;
-(void) setAttachmentSize: (CGSize) attachmentSize forGlyphRange: (NSRange) glyphRange ;
-(NSUInteger) firstUnlaidCharacterIndex;
-(NSUInteger) firstUnlaidGlyphIndex;
-(CGRect) usedRectForTextContainer: (NSTextContainer *) container ;
-(CGPoint) locationForGlyphAtIndex: (NSUInteger) glyphIndex ;
-(BOOL) notShownAttributeForGlyphAtIndex: (NSUInteger) glyphIndex ;
-(BOOL) drawsOutsideLineFragmentForGlyphAtIndex: (NSUInteger) glyphIndex ;
-(CGSize) attachmentSizeForGlyphAtIndex: (NSUInteger) glyphIndex ;
-(NSRange) truncatedGlyphRangeInLineFragmentForGlyphAtIndex: (NSUInteger) glyphIndex ;
-(NSRange) glyphRangeForTextContainer: (NSTextContainer *) container ;
-(NSRange) rangeOfNominallySpacedGlyphsContainingIndex: (NSUInteger) glyphIndex ;
-(CGRect) boundingRectForGlyphRange: (NSRange) glyphRange inTextContainer: (NSTextContainer *) container ;
-(NSRange) glyphRangeForBoundingRect: (CGRect) bounds inTextContainer: (NSTextContainer *) container ;
-(NSRange) glyphRangeForBoundingRectWithoutAdditionalLayout: (CGRect) bounds inTextContainer: (NSTextContainer *) container ;
-(NSUInteger) glyphIndexForPoint: (CGPoint) point inTextContainer: (NSTextContainer *) container ;
-(CGFloat) fractionOfDistanceThroughGlyphForPoint: (CGPoint) point inTextContainer: (NSTextContainer *) container ;
-(void) drawBackgroundForGlyphRange: (NSRange) glyphsToShow atPoint: (CGPoint) origin ;
-(void) drawGlyphsForGlyphRange: (NSRange) glyphsToShow atPoint: (CGPoint) origin ;
-(void) drawUnderlineForGlyphRange: (NSRange) glyphRange underlineType: (NSUnderlineStyle) underlineVal baselineOffset: (CGFloat) baselineOffset lineFragmentRect: (CGRect) lineRect lineFragmentGlyphRange: (NSRange) lineGlyphRange containerOrigin: (CGPoint) containerOrigin ;
-(void) underlineGlyphRange: (NSRange) glyphRange underlineType: (NSUnderlineStyle) underlineVal lineFragmentRect: (CGRect) lineRect lineFragmentGlyphRange: (NSRange) lineGlyphRange containerOrigin: (CGPoint) containerOrigin ;
-(void) drawStrikethroughForGlyphRange: (NSRange) glyphRange strikethroughType: (NSUnderlineStyle) strikethroughVal baselineOffset: (CGFloat) baselineOffset lineFragmentRect: (CGRect) lineRect lineFragmentGlyphRange: (NSRange) lineGlyphRange containerOrigin: (CGPoint) containerOrigin ;
-(void) strikethroughGlyphRange: (NSRange) glyphRange strikethroughType: (NSUnderlineStyle) strikethroughVal lineFragmentRect: (CGRect) lineRect lineFragmentGlyphRange: (NSRange) lineGlyphRange containerOrigin: (CGPoint) containerOrigin ;
@end
@protocol NSLayoutManagerClassExports<JSExport, NSSecureCodingClassExports_>
@end
@protocol NSLayoutManagerNSLayoutManagerDeprecatedCategoryInstanceExports<JSExport>
@property () CGFloat hyphenationFactor;
@end
@protocol NSLayoutManagerNSLayoutManagerDeprecatedCategoryClassExports<JSExport>
@end
@protocol NSTextLayoutOrientationProviderInstanceExports_<JSExport>
@property (readonly,nonatomic) NSTextLayoutOrientation layoutOrientation;
@end
@protocol NSTextLayoutOrientationProviderClassExports_<JSExport>
@end
@protocol NSLayoutManagerDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(CGFloat) layoutManager: (NSLayoutManager *) layoutManager lineSpacingAfterGlyphAtIndex: (NSUInteger) glyphIndex withProposedLineFragmentRect: (CGRect) rect ;
-(CGFloat) layoutManager: (NSLayoutManager *) layoutManager paragraphSpacingBeforeGlyphAtIndex: (NSUInteger) glyphIndex withProposedLineFragmentRect: (CGRect) rect ;
-(CGFloat) layoutManager: (NSLayoutManager *) layoutManager paragraphSpacingAfterGlyphAtIndex: (NSUInteger) glyphIndex withProposedLineFragmentRect: (CGRect) rect ;
-(NSControlCharacterAction) layoutManager: (NSLayoutManager *) layoutManager shouldUseAction: (NSControlCharacterAction) action forControlCharacterAtIndex: (NSUInteger) charIndex ;
-(BOOL) layoutManager: (NSLayoutManager *) layoutManager shouldBreakLineByWordBeforeCharacterAtIndex: (NSUInteger) charIndex ;
-(BOOL) layoutManager: (NSLayoutManager *) layoutManager shouldBreakLineByHyphenatingBeforeCharacterAtIndex: (NSUInteger) charIndex ;
-(CGRect) layoutManager: (NSLayoutManager *) layoutManager boundingBoxForControlGlyphAtIndex: (NSUInteger) glyphIndex forTextContainer: (NSTextContainer *) textContainer proposedLineFragment: (CGRect) proposedRect glyphPosition: (CGPoint) glyphPosition characterIndex: (NSUInteger) charIndex ;
-(void) layoutManagerDidInvalidateLayout: (NSLayoutManager *) sender ;
-(void) layoutManager: (NSLayoutManager *) layoutManager didCompleteLayoutForTextContainer: (NSTextContainer *) textContainer atEnd: (BOOL) layoutFinishedFlag ;
-(void) layoutManager: (NSLayoutManager *) layoutManager textContainer: (NSTextContainer *) textContainer didChangeGeometryFromSize: (CGSize) oldSize ;
@end
@protocol NSLayoutManagerDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop