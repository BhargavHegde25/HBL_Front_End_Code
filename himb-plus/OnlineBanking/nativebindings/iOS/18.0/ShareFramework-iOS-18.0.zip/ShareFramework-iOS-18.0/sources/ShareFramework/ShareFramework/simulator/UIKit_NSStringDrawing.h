#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_NSStringDrawing_symbols(JSContext*);
@protocol NSStringDrawingContextInstanceExports<JSExport>
@property (nonatomic) CGFloat minimumScaleFactor;
@property (readonly,nonatomic) CGFloat actualScaleFactor;
@property (readonly,nonatomic) CGRect totalBounds;
@end
@protocol NSStringDrawingContextClassExports<JSExport>
@end
@protocol NSStringNSStringDrawingCategoryInstanceExports<JSExport>
-(CGSize) sizeWithAttributes: (NSDictionary *) attrs ;
-(void) drawAtPoint: (CGPoint) point withAttributes: (NSDictionary *) attrs ;
-(void) drawInRect: (CGRect) rect withAttributes: (NSDictionary *) attrs ;
@end
@protocol NSStringNSStringDrawingCategoryClassExports<JSExport>
@end
@protocol NSAttributedStringNSStringDrawingCategoryInstanceExports<JSExport>
-(CGSize) size;
-(void) drawAtPoint: (CGPoint) point ;
-(void) drawInRect: (CGRect) rect ;
@end
@protocol NSAttributedStringNSStringDrawingCategoryClassExports<JSExport>
@end
@protocol NSStringNSExtendedStringDrawingCategoryInstanceExports<JSExport>
-(void) drawWithRect: (CGRect) rect options: (NSStringDrawingOptions) options attributes: (NSDictionary *) attributes context: (NSStringDrawingContext *) context ;
-(CGRect) boundingRectWithSize: (CGSize) size options: (NSStringDrawingOptions) options attributes: (NSDictionary *) attributes context: (NSStringDrawingContext *) context ;
@end
@protocol NSStringNSExtendedStringDrawingCategoryClassExports<JSExport>
@end
@protocol NSAttributedStringNSExtendedStringDrawingCategoryInstanceExports<JSExport>
-(void) drawWithRect: (CGRect) rect options: (NSStringDrawingOptions) options context: (NSStringDrawingContext *) context ;
-(CGRect) boundingRectWithSize: (CGSize) size options: (NSStringDrawingOptions) options context: (NSStringDrawingContext *) context ;
@end
@protocol NSAttributedStringNSExtendedStringDrawingCategoryClassExports<JSExport>
@end
@protocol NSStringDrawingContextNSStringDrawingContextDeprecatedCategoryInstanceExports<JSExport>
@property (nonatomic) CGFloat minimumTrackingAdjustment;
@property (readonly,nonatomic) CGFloat actualTrackingAdjustment;
@end
@protocol NSStringDrawingContextNSStringDrawingContextDeprecatedCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop