#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_NSTextAttachment_symbols(JSContext*);
@protocol NSTextAttachmentInstanceExports<JSExport, NSTextAttachmentLayoutInstanceExports_, NSTextAttachmentContainerInstanceExports_, NSSecureCodingInstanceExports_>
@property (copy,nonatomic) NSData * contents;
@property (copy,nonatomic) NSString * fileType;
@property (nonatomic,strong) UIImage * image;
@property (nonatomic) CGRect bounds;
@property (nonatomic,strong) NSFileWrapper * fileWrapper;
@property () CGFloat lineLayoutPadding;
@property () BOOL allowsTextAttachmentView;
@property (readonly) BOOL usesTextAttachmentView;
JSExportAs(initWithDataOfType,
-(id) jsinitWithData: (NSData *) contentData ofType: (NSString *) uti );
@end
@protocol NSTextAttachmentClassExports<JSExport, NSTextAttachmentLayoutClassExports_, NSTextAttachmentContainerClassExports_, NSSecureCodingClassExports_>
+(id) textAttachmentViewProviderClassForFileType: (NSString *) fileType ;
JSExportAs(registerTextAttachmentViewProviderClassForFileType,
+(void) jsregisterTextAttachmentViewProviderClass: (JSValue *) textAttachmentViewProviderClass forFileType: (NSString *) fileType );
@end
@protocol NSAttributedStringNSAttributedStringAttachmentConveniencesCategoryInstanceExports<JSExport>
@end
@protocol NSAttributedStringNSAttributedStringAttachmentConveniencesCategoryClassExports<JSExport>
+(NSAttributedString *) attributedStringWithAttachment: (NSTextAttachment *) attachment ;
@end
@protocol NSTextAttachmentViewProviderInstanceExports<JSExport>
@property (readonly,weak) NSTextAttachment * textAttachment;
@property (readonly,weak) NSTextLayoutManager * textLayoutManager;
@property (readonly,strong) id location;
@property (strong) UIView * view;
@property () BOOL tracksTextAttachmentViewBounds;
JSExportAs(initWithTextAttachmentParentViewTextLayoutManagerLocation,
-(id) jsinitWithTextAttachment: (NSTextAttachment *) textAttachment parentView: (UIView *) parentView textLayoutManager: (NSTextLayoutManager *) textLayoutManager location: (id) location );
-(void) loadView;
-(CGRect) attachmentBoundsForAttributes: (NSDictionary *) attributes location: (id) location textContainer: (NSTextContainer *) textContainer proposedLineFragment: (CGRect) proposedLineFragment position: (CGPoint) position ;
@end
@protocol NSTextAttachmentViewProviderClassExports<JSExport>
@end
@protocol NSTextAttachmentContainerInstanceExports_<JSExport, NSObjectInstanceExports_>
-(UIImage *) imageForBounds: (CGRect) imageBounds textContainer: (NSTextContainer *) textContainer characterIndex: (NSUInteger) charIndex ;
-(CGRect) attachmentBoundsForTextContainer: (NSTextContainer *) textContainer proposedLineFragment: (CGRect) lineFrag glyphPosition: (CGPoint) position characterIndex: (NSUInteger) charIndex ;
@end
@protocol NSTextAttachmentContainerClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol NSTextAttachmentLayoutInstanceExports_<JSExport, NSObjectInstanceExports_>
-(UIImage *) imageForBounds: (CGRect) bounds attributes: (NSDictionary *) attributes location: (id) location textContainer: (NSTextContainer *) textContainer ;
-(CGRect) attachmentBoundsForAttributes: (NSDictionary *) attributes location: (id) location textContainer: (NSTextContainer *) textContainer proposedLineFragment: (CGRect) proposedLineFragment position: (CGPoint) position ;
-(NSTextAttachmentViewProvider *) viewProviderForParentView: (UIView *) parentView location: (id) location textContainer: (NSTextContainer *) textContainer ;
@end
@protocol NSTextAttachmentLayoutClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop