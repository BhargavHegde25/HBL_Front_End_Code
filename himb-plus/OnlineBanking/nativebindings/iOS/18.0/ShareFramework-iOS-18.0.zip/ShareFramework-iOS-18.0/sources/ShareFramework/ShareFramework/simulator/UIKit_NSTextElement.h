#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_NSTextElement_symbols(JSContext*);
@protocol NSTextElementInstanceExports<JSExport>
@property (weak) NSTextContentManager * textContentManager;
@property (strong) NSTextRange * elementRange;
@property (readonly,copy) NSArray * childElements;
@property (readonly,weak) __kindof NSTextElement * parentElement;
@property (readonly) BOOL isRepresentedElement;
JSExportAs(initWithTextContentManager,
-(id) jsinitWithTextContentManager: (NSTextContentManager *) textContentManager );
@end
@protocol NSTextElementClassExports<JSExport>
@end
@protocol NSTextParagraphInstanceExports<JSExport>
@property (readonly,strong) NSAttributedString * attributedString;
@property (readonly,strong) NSTextRange * paragraphContentRange;
@property (readonly,strong) NSTextRange * paragraphSeparatorRange;
JSExportAs(initWithAttributedString,
-(id) jsinitWithAttributedString: (NSAttributedString *) attributedString );
@end
@protocol NSTextParagraphClassExports<JSExport>
@end
#pragma clang diagnostic pop