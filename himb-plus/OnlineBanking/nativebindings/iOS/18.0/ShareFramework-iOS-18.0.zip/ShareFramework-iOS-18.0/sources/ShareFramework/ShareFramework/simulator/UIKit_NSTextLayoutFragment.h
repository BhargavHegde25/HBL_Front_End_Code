#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_NSTextLayoutFragment_symbols(JSContext*);
@protocol NSTextLayoutFragmentInstanceExports<JSExport, NSSecureCodingInstanceExports_>
@property (readonly,weak) NSTextLayoutManager * textLayoutManager;
@property (readonly,weak) NSTextElement * textElement;
@property (readonly,strong) NSTextRange * rangeInElement;
@property (readonly,copy) NSArray * textLineFragments;
@property (strong) NSOperationQueue * layoutQueue;
@property (readonly) NSTextLayoutFragmentState state;
@property (readonly) CGRect layoutFragmentFrame;
@property (readonly) CGRect renderingSurfaceBounds;
@property (readonly) CGFloat leadingPadding;
@property (readonly) CGFloat trailingPadding;
@property (readonly) CGFloat topMargin;
@property (readonly) CGFloat bottomMargin;
@property (readonly,copy) NSArray * textAttachmentViewProviders;
JSExportAs(initWithTextElementRange,
-(id) jsinitWithTextElement: (NSTextElement *) textElement range: (NSTextRange *) rangeInElement );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
-(NSTextLineFragment *) textLineFragmentForVerticalOffset: (CGFloat) verticalOffset requiresExactMatch: (BOOL) requiresExactMatch ;
-(NSTextLineFragment *) textLineFragmentForTextLocation: (id) textLocation isUpstreamAffinity: (BOOL) isUpstreamAffinity ;
-(void) invalidateLayout;
-(void) drawAtPoint: (CGPoint) point inContext: (id) context ;
-(CGRect) frameForTextAttachmentAtLocation: (id) location ;
@end
@protocol NSTextLayoutFragmentClassExports<JSExport, NSSecureCodingClassExports_>
@end
#pragma clang diagnostic pop