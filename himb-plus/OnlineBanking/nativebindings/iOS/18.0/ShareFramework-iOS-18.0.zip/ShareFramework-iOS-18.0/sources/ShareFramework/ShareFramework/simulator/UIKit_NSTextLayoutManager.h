#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_NSTextLayoutManager_symbols(JSContext*);
@protocol NSTextLayoutManagerInstanceExports<JSExport, NSSecureCodingInstanceExports_, NSTextSelectionDataSourceInstanceExports_>
@property (weak) id delegate;
@property () BOOL usesFontLeading;
@property () BOOL limitsLayoutForSuspiciousContents;
@property () BOOL usesHyphenation;
@property (readonly,weak) NSTextContentManager * textContentManager;
@property (readwrite,strong) NSTextContainer * textContainer;
@property (readonly) CGRect usageBoundsForTextContainer;
@property (readonly,strong) NSTextViewportLayoutController * textViewportLayoutController;
@property (strong) NSOperationQueue * layoutQueue;
@property (strong) NSArray * textSelections;
@property (strong) NSTextSelectionNavigation * textSelectionNavigation;
@property (getter=getJsRenderingAttributesValidator,setter=setJsRenderingAttributesValidator:) JSValue* jsrenderingAttributesValidator;
-(id) jsinit;
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
-(void) replaceTextContentManager: (NSTextContentManager *) textContentManager ;
-(void) ensureLayoutForRange: (NSTextRange *) range ;
-(void) ensureLayoutForBounds: (CGRect) bounds ;
-(void) invalidateLayoutForRange: (NSTextRange *) range ;
-(NSTextLayoutFragment *) textLayoutFragmentForPosition: (CGPoint) position ;
-(NSTextLayoutFragment *) textLayoutFragmentForLocation: (id) location ;
JSExportAs(enumerateTextLayoutFragmentsFromLocationOptionsUsingBlock,
-(id) jsenumerateTextLayoutFragmentsFromLocation: (id) location options: (NSTextLayoutFragmentEnumerationOptions) options usingBlock: (JSValue *) block );
JSExportAs(enumerateRenderingAttributesFromLocationReverseUsingBlock,
-(void) jsenumerateRenderingAttributesFromLocation: (id) location reverse: (BOOL) reverse usingBlock: (JSValue *) block );
-(void) setRenderingAttributes: (NSDictionary *) renderingAttributes forTextRange: (NSTextRange *) textRange ;
-(void) addRenderingAttribute: (NSAttributedStringKey) renderingAttribute value: (id) value forTextRange: (NSTextRange *) textRange ;
-(void) removeRenderingAttribute: (NSAttributedStringKey) renderingAttribute forTextRange: (NSTextRange *) textRange ;
-(void) invalidateRenderingAttributesForTextRange: (NSTextRange *) textRange ;
-(NSDictionary *) renderingAttributesForLink: (id) link atLocation: (id) location ;
JSExportAs(enumerateTextSegmentsInRangeTypeOptionsUsingBlock,
-(void) jsenumerateTextSegmentsInRange: (NSTextRange *) textRange type: (NSTextLayoutManagerSegmentType) type options: (NSTextLayoutManagerSegmentOptions) options usingBlock: (JSValue *) block );
-(void) replaceContentsInRange: (NSTextRange *) range withTextElements: (NSArray *) textElements ;
-(void) replaceContentsInRange: (NSTextRange *) range withAttributedString: (NSAttributedString *) attributedString ;
@end
@protocol NSTextLayoutManagerClassExports<JSExport, NSSecureCodingClassExports_, NSTextSelectionDataSourceClassExports_>
+(NSDictionary *) linkRenderingAttributes;
@end
@protocol NSTextLayoutManagerDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(NSTextLayoutFragment *) textLayoutManager: (NSTextLayoutManager *) textLayoutManager textLayoutFragmentForLocation: (id) location inTextElement: (NSTextElement *) textElement ;
-(BOOL) textLayoutManager: (NSTextLayoutManager *) textLayoutManager shouldBreakLineBeforeLocation: (id) location hyphenating: (BOOL) hyphenating ;
-(NSDictionary *) textLayoutManager: (NSTextLayoutManager *) textLayoutManager renderingAttributesForLink: (id) link atLocation: (id) location defaultAttributes: (NSDictionary *) renderingAttributes ;
@end
@protocol NSTextLayoutManagerDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop