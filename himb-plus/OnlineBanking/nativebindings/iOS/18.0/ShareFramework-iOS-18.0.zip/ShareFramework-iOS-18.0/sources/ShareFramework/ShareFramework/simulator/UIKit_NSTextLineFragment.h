#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_NSTextLineFragment_symbols(JSContext*);
@protocol NSTextLineFragmentInstanceExports<JSExport, NSSecureCodingInstanceExports_>
@property (readonly,strong) NSAttributedString * attributedString;
@property (readonly) NSRange characterRange;
@property (readonly) CGRect typographicBounds;
@property (readonly) CGPoint glyphOrigin;
JSExportAs(initWithAttributedStringRange,
-(id) jsinitWithAttributedString: (NSAttributedString *) attributedString range: (NSRange) range );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) aDecoder );
JSExportAs(initWithStringAttributesRange,
-(id) jsinitWithString: (NSString *) string attributes: (NSDictionary *) attributes range: (NSRange) range );
-(void) drawAtPoint: (CGPoint) point inContext: (id) context ;
-(CGPoint) locationForCharacterAtIndex: (NSInteger) index ;
-(NSInteger) characterIndexForPoint: (CGPoint) point ;
-(CGFloat) fractionOfDistanceThroughGlyphForPoint: (CGPoint) point ;
@end
@protocol NSTextLineFragmentClassExports<JSExport, NSSecureCodingClassExports_>
@end
#pragma clang diagnostic pop