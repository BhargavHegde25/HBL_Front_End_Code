#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_NSTextList_symbols(JSContext*);
@protocol NSTextListInstanceExports<JSExport, NSSecureCodingInstanceExports_, NSCopyingInstanceExports_>
@property (readonly,strong) NSTextListMarkerFormat markerFormat;
@property (readonly) NSTextListOptions listOptions;
@property () NSInteger startingItemNumber;
@property (getter=isOrdered,readonly) BOOL ordered;
JSExportAs(initWithMarkerFormatOptionsStartingItemNumber,
-(id) jsinitWithMarkerFormat: (NSTextListMarkerFormat) markerFormat options: (NSTextListOptions) options startingItemNumber: (NSInteger) startingItemNumber );
JSExportAs(initWithMarkerFormatOptions,
-(id) jsinitWithMarkerFormat: (NSTextListMarkerFormat) markerFormat options: (NSUInteger) options );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
-(NSString *) markerForItemNumber: (NSInteger) itemNumber ;
@end
@protocol NSTextListClassExports<JSExport, NSSecureCodingClassExports_, NSCopyingClassExports_>
@end
#pragma clang diagnostic pop