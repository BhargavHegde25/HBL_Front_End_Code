#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_NSTextListElement_symbols(JSContext*);
@protocol NSTextListElementInstanceExports<JSExport>
@property (readonly,strong) NSTextList * textList;
@property (readonly,strong) NSAttributedString * contents;
@property (readonly,strong) NSDictionary * markerAttributes;
@property (readonly,strong) NSAttributedString * attributedString;
@property (readonly,copy) NSArray * childElements;
@property (readonly,weak) NSTextListElement * parentElement;
JSExportAs(initWithParentElementTextListContentsMarkerAttributesChildElements,
-(id) jsinitWithParentElement: (NSTextListElement *) parent textList: (NSTextList *) textList contents: (NSAttributedString *) contents markerAttributes: (NSDictionary *) markerAttributes childElements: (NSArray *) children );
@end
@protocol NSTextListElementClassExports<JSExport>
+(id) textListElementWithContents: (NSAttributedString *) contents markerAttributes: (NSDictionary *) markerAttributes textList: (NSTextList *) textList childElements: (NSArray *) children ;
+(id) textListElementWithChildElements: (NSArray *) children textList: (NSTextList *) textList nestingLevel: (NSInteger) nestingLevel ;
@end
#pragma clang diagnostic pop