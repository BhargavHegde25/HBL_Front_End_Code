#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_NSTextRange_symbols(JSContext*);
@protocol NSTextRangeInstanceExports<JSExport>
@property (getter=isEmpty,readonly) BOOL empty;
@property (readonly,strong) id location;
@property (readonly,strong) id endLocation;
JSExportAs(initWithLocationEndLocation,
-(id) jsinitWithLocation: (id) location endLocation: (id) endLocation );
JSExportAs(initWithLocation,
-(id) jsinitWithLocation: (id) location );
-(BOOL) isEqualToTextRange: (NSTextRange *) textRange ;
-(BOOL) containsLocation: (id) location ;
-(BOOL) containsRange: (NSTextRange *) textRange ;
-(BOOL) intersectsWithTextRange: (NSTextRange *) textRange ;
-(id) textRangeByIntersectingWithTextRange: (NSTextRange *) textRange ;
-(id) textRangeByFormingUnionWithTextRange: (NSTextRange *) textRange ;
@end
@protocol NSTextRangeClassExports<JSExport>
@end
@protocol NSTextLocationInstanceExports_<JSExport, NSObjectInstanceExports_>
-(NSComparisonResult) compare: (id) location ;
@end
@protocol NSTextLocationClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop