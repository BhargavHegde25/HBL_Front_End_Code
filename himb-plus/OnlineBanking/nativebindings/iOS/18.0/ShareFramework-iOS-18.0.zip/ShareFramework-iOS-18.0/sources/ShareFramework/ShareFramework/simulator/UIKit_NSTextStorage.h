#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_NSTextStorage_symbols(JSContext*);
@protocol NSTextStorageInstanceExports<JSExport, NSSecureCodingInstanceExports_>
@property (readonly,copy,nonatomic) NSArray * layoutManagers;
@property (readonly,nonatomic) NSTextStorageEditActions editedMask;
@property (readonly,nonatomic) NSRange editedRange;
@property (readonly,nonatomic) NSInteger changeInLength;
@property (nonatomic,weak) id delegate;
@property (readonly,nonatomic) BOOL fixesAttributesLazily;
@property (nonatomic,weak) id textStorageObserver;
-(void) addLayoutManager: (NSLayoutManager *) aLayoutManager ;
-(void) removeLayoutManager: (NSLayoutManager *) aLayoutManager ;
-(void) edited: (NSTextStorageEditActions) editedMask range: (NSRange) editedRange changeInLength: (NSInteger) delta ;
-(void) processEditing;
-(void) invalidateAttributesInRange: (NSRange) range ;
-(void) ensureAttributesAreFixedInRange: (NSRange) range ;
@end
@protocol NSTextStorageClassExports<JSExport, NSSecureCodingClassExports_>
@end
@protocol NSTextStorageDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) textStorage: (NSTextStorage *) textStorage willProcessEditing: (NSTextStorageEditActions) editedMask range: (NSRange) editedRange changeInLength: (NSInteger) delta ;
-(void) textStorage: (NSTextStorage *) textStorage didProcessEditing: (NSTextStorageEditActions) editedMask range: (NSRange) editedRange changeInLength: (NSInteger) delta ;
@end
@protocol NSTextStorageDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol NSTextStorageObservingInstanceExports_<JSExport, NSObjectInstanceExports_>
@property (nonatomic,strong) NSTextStorage * textStorage;
-(void) processEditingForTextStorage: (NSTextStorage *) textStorage edited: (NSTextStorageEditActions) editMask range: (NSRange) newCharRange changeInLength: (NSInteger) delta invalidatedRange: (NSRange) invalidatedCharRange ;
JSExportAs(performEditingTransactionForTextStorageUsingBlock,
-(void) jsperformEditingTransactionForTextStorage: (NSTextStorage *) textStorage usingBlock: (JSValue *) transaction );
@end
@protocol NSTextStorageObservingClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop