#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_NSTextViewportLayoutController_symbols(JSContext*);
@protocol NSTextViewportLayoutControllerInstanceExports<JSExport>
@property (weak) id delegate;
@property (readonly,weak) NSTextLayoutManager * textLayoutManager;
@property (readonly) CGRect viewportBounds;
@property (readonly) NSTextRange * viewportRange;
JSExportAs(initWithTextLayoutManager,
-(id) jsinitWithTextLayoutManager: (NSTextLayoutManager *) textLayoutManager );
-(void) layoutViewport;
-(CGFloat) relocateViewportToTextLocation: (id) textLocation ;
-(void) adjustViewportByVerticalOffset: (CGFloat) verticalOffset ;
@end
@protocol NSTextViewportLayoutControllerClassExports<JSExport>
@end
@protocol NSTextViewportLayoutControllerDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(CGRect) viewportBoundsForTextViewportLayoutController: (NSTextViewportLayoutController *) textViewportLayoutController ;
-(void) textViewportLayoutController: (NSTextViewportLayoutController *) textViewportLayoutController configureRenderingSurfaceForTextLayoutFragment: (NSTextLayoutFragment *) textLayoutFragment ;
-(void) textViewportLayoutControllerWillLayout: (NSTextViewportLayoutController *) textViewportLayoutController ;
-(void) textViewportLayoutControllerDidLayout: (NSTextViewportLayoutController *) textViewportLayoutController ;
@end
@protocol NSTextViewportLayoutControllerDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop