#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIAction_symbols(JSContext*);
@protocol UIActionInstanceExports<JSExport, UIMenuLeafInstanceExports_>
@property (copy,nonatomic) NSString * title;
@property (copy,nonatomic) UIImage * image;
@property (copy,nonatomic) NSString * discoverabilityTitle;
@property (readonly,nonatomic) UIActionIdentifier identifier;
@property (nonatomic) UIMenuElementAttributes attributes;
@property (nonatomic) UIMenuElementState state;
@property (readonly,nonatomic) id sender;
@end
@protocol UIActionClassExports<JSExport, UIMenuLeafClassExports_>
JSExportAs(actionWithHandler,
+(id) jsactionWithHandler: (JSValue *) handler );
JSExportAs(actionWithTitleImageIdentifierHandler,
+(id) jsactionWithTitle: (NSString *) title image: (UIImage *) image identifier: (UIActionIdentifier) identifier handler: (JSValue *) handler );
@end
@protocol UIActionUICaptureTextFromCameraSupportingCategoryInstanceExports<JSExport>
@end
@protocol UIActionUICaptureTextFromCameraSupportingCategoryClassExports<JSExport>
+(id) captureTextFromCameraActionForResponder: (UIResponder *) responder identifier: (UIActionIdentifier) identifier ;
@end
#pragma clang diagnostic pop