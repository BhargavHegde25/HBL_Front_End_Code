#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIActionSheet_symbols(JSContext*);
@protocol UIActionSheetInstanceExports<JSExport>
@property (nonatomic,weak) id delegate;
@property (copy,nonatomic) NSString * title;
@property (nonatomic) UIActionSheetStyle actionSheetStyle;
@property (readonly,nonatomic) NSInteger numberOfButtons;
@property (nonatomic) NSInteger cancelButtonIndex;
@property (nonatomic) NSInteger destructiveButtonIndex;
@property (readonly,nonatomic) NSInteger firstOtherButtonIndex;
@property (getter=isVisible,readonly,nonatomic) BOOL visible;
JSExportAs(initWithTitleDelegateCancelButtonTitleDestructiveButtonTitleOtherButtonTitles,
-(id) jsinitWithTitle: (NSString *) title delegate: (id) delegate cancelButtonTitle: (NSString *) cancelButtonTitle destructiveButtonTitle: (NSString *) destructiveButtonTitle otherButtonTitles: (NSString *) otherButtonTitles arguments: (NSArray *) args );
-(NSInteger) addButtonWithTitle: (NSString *) title ;
-(NSString *) buttonTitleAtIndex: (NSInteger) buttonIndex ;
-(void) showFromToolbar: (UIToolbar *) view ;
-(void) showFromTabBar: (UITabBar *) view ;
-(void) showFromBarButtonItem: (UIBarButtonItem *) item animated: (BOOL) animated ;
-(void) showFromRect: (CGRect) rect inView: (UIView *) view animated: (BOOL) animated ;
-(void) showInView: (UIView *) view ;
-(void) dismissWithClickedButtonIndex: (NSInteger) buttonIndex animated: (BOOL) animated ;
@end
@protocol UIActionSheetClassExports<JSExport>
@end
@protocol UIActionSheetDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) actionSheet: (UIActionSheet *) actionSheet clickedButtonAtIndex: (NSInteger) buttonIndex ;
-(void) actionSheetCancel: (UIActionSheet *) actionSheet ;
-(void) willPresentActionSheet: (UIActionSheet *) actionSheet ;
-(void) didPresentActionSheet: (UIActionSheet *) actionSheet ;
-(void) actionSheet: (UIActionSheet *) actionSheet willDismissWithButtonIndex: (NSInteger) buttonIndex ;
-(void) actionSheet: (UIActionSheet *) actionSheet didDismissWithButtonIndex: (NSInteger) buttonIndex ;
@end
@protocol UIActionSheetDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop