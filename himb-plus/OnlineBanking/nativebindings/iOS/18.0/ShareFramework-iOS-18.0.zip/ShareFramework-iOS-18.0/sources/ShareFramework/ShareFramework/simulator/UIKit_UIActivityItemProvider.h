#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIActivityItemProvider_symbols(JSContext*);
@protocol UIActivityItemProviderInstanceExports<JSExport, UIActivityItemSourceInstanceExports_>
@property (readonly,nonatomic,strong) id placeholderItem;
@property (readonly,copy,nonatomic) UIActivityType activityType;
@property (readonly,nonatomic) id item;
JSExportAs(initWithPlaceholderItem,
-(id) jsinitWithPlaceholderItem: (id) placeholderItem );
@end
@protocol UIActivityItemProviderClassExports<JSExport, UIActivityItemSourceClassExports_>
@end
@protocol UIActivityItemSourceInstanceExports_<JSExport, NSObjectInstanceExports_>
-(id) activityViewControllerPlaceholderItem: (UIActivityViewController *) activityViewController ;
-(id) activityViewController: (UIActivityViewController *) activityViewController itemForActivityType: (UIActivityType) activityType ;
-(NSString *) activityViewController: (UIActivityViewController *) activityViewController subjectForActivityType: (UIActivityType) activityType ;
-(NSString *) activityViewController: (UIActivityViewController *) activityViewController dataTypeIdentifierForActivityType: (UIActivityType) activityType ;
-(UIImage *) activityViewController: (UIActivityViewController *) activityViewController thumbnailImageForActivityType: (UIActivityType) activityType suggestedSize: (CGSize) size ;
-(LPLinkMetadata *) activityViewControllerLinkMetadata: (UIActivityViewController *) activityViewController ;
@end
@protocol UIActivityItemSourceClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop