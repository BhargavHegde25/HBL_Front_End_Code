#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIActivityItemsConfigurationReading_symbols(JSContext*);
@protocol UIActivityItemsConfigurationReadingInstanceExports_<JSExport, NSObjectInstanceExports_>
@property (readonly,copy,nonatomic) NSArray * itemProvidersForActivityItemsConfiguration;
@property (readonly,copy,nonatomic) NSArray * applicationActivitiesForActivityItemsConfiguration;
-(BOOL) activityItemsConfigurationSupportsInteraction: (UIActivityItemsConfigurationInteraction) interaction ;
-(id) activityItemsConfigurationMetadataForKey: (UIActivityItemsConfigurationMetadataKey) key ;
-(id) activityItemsConfigurationMetadataForItemAtIndex: (NSInteger) index key: (UIActivityItemsConfigurationMetadataKey) key ;
-(NSItemProvider *) activityItemsConfigurationPreviewForItemAtIndex: (NSInteger) index intent: (UIActivityItemsConfigurationPreviewIntent) intent suggestedSize: (CGSize) suggestedSize ;
@end
@protocol UIActivityItemsConfigurationReadingClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UIActivityItemsConfigurationProvidingInstanceExports_<JSExport, NSObjectInstanceExports_>
@property (readonly,nonatomic,strong) id activityItemsConfiguration;
@end
@protocol UIActivityItemsConfigurationProvidingClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop