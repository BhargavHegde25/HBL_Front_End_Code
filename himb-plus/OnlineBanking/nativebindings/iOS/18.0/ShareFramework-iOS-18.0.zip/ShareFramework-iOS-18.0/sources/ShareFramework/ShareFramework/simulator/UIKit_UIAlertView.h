#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIAlertView_symbols(JSContext*);
@protocol UIAlertViewInstanceExports<JSExport>
@property (nonatomic,weak) id delegate;
@property (copy,nonatomic) NSString * title;
@property (copy,nonatomic) NSString * message;
@property (readonly,nonatomic) NSInteger numberOfButtons;
@property (nonatomic) NSInteger cancelButtonIndex;
@property (readonly,nonatomic) NSInteger firstOtherButtonIndex;
@property (getter=isVisible,readonly,nonatomic) BOOL visible;
@property (assign,nonatomic) UIAlertViewStyle alertViewStyle;
JSExportAs(initWithTitleMessageDelegateCancelButtonTitleOtherButtonTitles,
-(id) jsinitWithTitle: (NSString *) title message: (NSString *) message delegate: (id) delegate cancelButtonTitle: (NSString *) cancelButtonTitle otherButtonTitles: (NSString *) otherButtonTitles arguments: (NSArray *) args );
JSExportAs(initWithFrame,
-(id) jsinitWithFrame: (CGRect) frame );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
-(NSInteger) addButtonWithTitle: (NSString *) title ;
-(NSString *) buttonTitleAtIndex: (NSInteger) buttonIndex ;
-(void) show;
-(void) dismissWithClickedButtonIndex: (NSInteger) buttonIndex animated: (BOOL) animated ;
-(UITextField *) textFieldAtIndex: (NSInteger) textFieldIndex ;
@end
@protocol UIAlertViewClassExports<JSExport>
@end
@protocol UIAlertViewDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) alertView: (UIAlertView *) alertView clickedButtonAtIndex: (NSInteger) buttonIndex ;
-(void) alertViewCancel: (UIAlertView *) alertView ;
-(void) willPresentAlertView: (UIAlertView *) alertView ;
-(void) didPresentAlertView: (UIAlertView *) alertView ;
-(void) alertView: (UIAlertView *) alertView willDismissWithButtonIndex: (NSInteger) buttonIndex ;
-(void) alertView: (UIAlertView *) alertView didDismissWithButtonIndex: (NSInteger) buttonIndex ;
-(BOOL) alertViewShouldEnableFirstOtherButton: (UIAlertView *) alertView ;
@end
@protocol UIAlertViewDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop