#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIBandSelectionInteraction_symbols(JSContext*);
@protocol UIBandSelectionInteractionInstanceExports<JSExport, UIInteractionInstanceExports_>
@property (getter=isEnabled,nonatomic) BOOL enabled;
@property (readonly,nonatomic) UIBandSelectionInteractionState state;
@property (readonly,nonatomic) CGRect selectionRect;
@property (readonly,nonatomic) UIKeyModifierFlags initialModifierFlags;
@property (getter=getJsShouldBeginHandler,setter=setJsShouldBeginHandler:) JSValue* jsshouldBeginHandler;
JSExportAs(initWithSelectionHandler,
-(id) jsinitWithSelectionHandler: (JSValue *) selectionHandler );
@end
@protocol UIBandSelectionInteractionClassExports<JSExport, UIInteractionClassExports_>
@end
#pragma clang diagnostic pop