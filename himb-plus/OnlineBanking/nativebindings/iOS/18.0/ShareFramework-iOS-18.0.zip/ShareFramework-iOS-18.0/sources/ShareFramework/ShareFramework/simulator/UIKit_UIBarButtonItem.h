#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIBarButtonItem_symbols(JSContext*);
@protocol UIBarButtonItemInstanceExports<JSExport, NSCodingInstanceExports_>
@property (assign,readwrite,nonatomic) UIBarButtonItemStyle style;
@property (assign,readwrite,nonatomic) CGFloat width;
@property (readwrite,copy,nonatomic) NSSet * possibleTitles;
@property (readwrite,nonatomic,strong) __kindof UIView * customView;
@property (getter=getJsAction,setter=setJsAction:) NSString* jsaction;
@property (readwrite,nonatomic,weak) id target;
@property (readwrite,copy,nonatomic) UIAction * primaryAction;
@property (readwrite,copy,nonatomic) UIMenu * menu;
@property (nonatomic) UIContextMenuConfigurationElementOrder preferredMenuElementOrder;
@property (assign,readwrite,nonatomic) BOOL changesSelectionAsPrimaryAction;
@property (getter=isSelected,assign,readwrite,nonatomic) BOOL selected;
@property (getter=isHidden,assign,readwrite,nonatomic) BOOL hidden;
@property (getter=isSymbolAnimationEnabled,assign,readwrite,nonatomic) BOOL symbolAnimationEnabled;
@property (readwrite,copy,nonatomic) UIMenuElement * menuRepresentation;
@property (nonatomic,strong) UIColor * tintColor;
-(id) jsinit;
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
JSExportAs(initWithImageStyleTargetAction,
-(id) jsinitWithImage: (UIImage *) image style: (UIBarButtonItemStyle) style target: (id) target action: (NSString *) action );
JSExportAs(initWithImageLandscapeImagePhoneStyleTargetAction,
-(id) jsinitWithImage: (UIImage *) image landscapeImagePhone: (UIImage *) landscapeImagePhone style: (UIBarButtonItemStyle) style target: (id) target action: (NSString *) action );
JSExportAs(initWithTitleStyleTargetAction,
-(id) jsinitWithTitle: (NSString *) title style: (UIBarButtonItemStyle) style target: (id) target action: (NSString *) action );
JSExportAs(initWithBarButtonSystemItemTargetAction,
-(id) jsinitWithBarButtonSystemItem: (UIBarButtonSystemItem) systemItem target: (id) target action: (NSString *) action );
JSExportAs(initWithCustomView,
-(id) jsinitWithCustomView: (UIView *) customView );
JSExportAs(initWithBarButtonSystemItemPrimaryAction,
-(id) jsinitWithBarButtonSystemItem: (UIBarButtonSystemItem) systemItem primaryAction: (UIAction *) primaryAction );
JSExportAs(initWithPrimaryAction,
-(id) jsinitWithPrimaryAction: (UIAction *) primaryAction );
JSExportAs(initWithBarButtonSystemItemMenu,
-(id) jsinitWithBarButtonSystemItem: (UIBarButtonSystemItem) systemItem menu: (UIMenu *) menu );
JSExportAs(initWithTitleMenu,
-(id) jsinitWithTitle: (NSString *) title menu: (UIMenu *) menu );
JSExportAs(initWithImageMenu,
-(id) jsinitWithImage: (UIImage *) image menu: (UIMenu *) menu );
JSExportAs(initWithPrimaryActionMenu,
-(id) jsinitWithPrimaryAction: (UIAction *) primaryAction menu: (UIMenu *) menu );
JSExportAs(initWithBarButtonSystemItemPrimaryActionMenu,
-(id) jsinitWithBarButtonSystemItem: (UIBarButtonSystemItem) systemItem primaryAction: (UIAction *) primaryAction menu: (UIMenu *) menu );
JSExportAs(initWithTitleImageTargetActionMenu,
-(id) jsinitWithTitle: (NSString *) title image: (UIImage *) image target: (id) target action: (NSString *) action menu: (UIMenu *) menu );
-(UIBarButtonItemGroup *) creatingFixedGroup;
-(UIBarButtonItemGroup *) creatingMovableGroupWithCustomizationIdentifier: (NSString *) customizationIdentifier ;
-(UIBarButtonItemGroup *) creatingOptionalGroupWithCustomizationIdentifier: (NSString *) customizationIdentifier inDefaultCustomization: (BOOL) inDefaultCustomization ;
-(void) setBackgroundImage: (UIImage *) backgroundImage forState: (UIControlState) state barMetrics: (UIBarMetrics) barMetrics ;
-(UIImage *) backgroundImageForState: (UIControlState) state barMetrics: (UIBarMetrics) barMetrics ;
-(void) setBackgroundImage: (UIImage *) backgroundImage forState: (UIControlState) state style: (UIBarButtonItemStyle) style barMetrics: (UIBarMetrics) barMetrics ;
-(UIImage *) backgroundImageForState: (UIControlState) state style: (UIBarButtonItemStyle) style barMetrics: (UIBarMetrics) barMetrics ;
-(void) setBackgroundVerticalPositionAdjustment: (CGFloat) adjustment forBarMetrics: (UIBarMetrics) barMetrics ;
-(CGFloat) backgroundVerticalPositionAdjustmentForBarMetrics: (UIBarMetrics) barMetrics ;
-(void) setTitlePositionAdjustment: (UIOffset) adjustment forBarMetrics: (UIBarMetrics) barMetrics ;
-(UIOffset) titlePositionAdjustmentForBarMetrics: (UIBarMetrics) barMetrics ;
-(void) setBackButtonBackgroundImage: (UIImage *) backgroundImage forState: (UIControlState) state barMetrics: (UIBarMetrics) barMetrics ;
-(UIImage *) backButtonBackgroundImageForState: (UIControlState) state barMetrics: (UIBarMetrics) barMetrics ;
-(void) setBackButtonTitlePositionAdjustment: (UIOffset) adjustment forBarMetrics: (UIBarMetrics) barMetrics ;
-(UIOffset) backButtonTitlePositionAdjustmentForBarMetrics: (UIBarMetrics) barMetrics ;
-(void) setBackButtonBackgroundVerticalPositionAdjustment: (CGFloat) adjustment forBarMetrics: (UIBarMetrics) barMetrics ;
-(CGFloat) backButtonBackgroundVerticalPositionAdjustmentForBarMetrics: (UIBarMetrics) barMetrics ;
@end
@protocol UIBarButtonItemClassExports<JSExport, NSCodingClassExports_>
+(id) fixedSpaceItemOfWidth: (CGFloat) width ;
+(id) flexibleSpaceItem;
@end
@protocol UIBarButtonItemSpringLoadingCategoryInstanceExports<JSExport, UISpringLoadedInteractionSupportingInstanceExports_>
@end
@protocol UIBarButtonItemSpringLoadingCategoryClassExports<JSExport, UISpringLoadedInteractionSupportingClassExports_>
@end
@protocol UIBarButtonItemAnonCategoryInstanceExports<JSExport>
-(void) addSymbolEffect: (NSSymbolEffect *) symbolEffect ;
-(void) addSymbolEffect: (NSSymbolEffect *) symbolEffect options: (NSSymbolEffectOptions *) options ;
-(void) addSymbolEffect: (NSSymbolEffect *) symbolEffect options: (NSSymbolEffectOptions *) options animated: (BOOL) animated ;
-(void) removeSymbolEffectOfType: (NSSymbolEffect *) symbolEffect ;
-(void) removeSymbolEffectOfType: (NSSymbolEffect *) symbolEffect options: (NSSymbolEffectOptions *) options ;
-(void) removeSymbolEffectOfType: (NSSymbolEffect *) symbolEffect options: (NSSymbolEffectOptions *) options animated: (BOOL) animated ;
-(void) removeAllSymbolEffects;
-(void) removeAllSymbolEffectsWithOptions: (NSSymbolEffectOptions *) options ;
-(void) removeAllSymbolEffectsWithOptions: (NSSymbolEffectOptions *) options animated: (BOOL) animated ;
-(void) setSymbolImage: (UIImage *) symbolImage withContentTransition: (NSSymbolContentTransition *) transition ;
-(void) setSymbolImage: (UIImage *) symbolImage withContentTransition: (NSSymbolContentTransition *) transition options: (NSSymbolEffectOptions *) options ;
@end
@protocol UIBarButtonItemAnonCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop