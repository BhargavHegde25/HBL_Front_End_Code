#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIBarButtonItemGroup_symbols(JSContext*);
@protocol UIBarButtonItemGroupInstanceExports<JSExport, NSCodingInstanceExports_>
@property (readwrite,copy,nonatomic) NSArray * barButtonItems;
@property (readwrite,nonatomic,strong) UIBarButtonItem * representativeItem;
@property (getter=isDisplayingRepresentativeItem,readonly,assign,nonatomic) BOOL displayingRepresentativeItem;
@property (assign,readwrite,nonatomic) BOOL alwaysAvailable;
@property (readwrite,copy,nonatomic) UIMenuElement * menuRepresentation;
@property (getter=isHidden,assign,readwrite,nonatomic) BOOL hidden;
JSExportAs(initWithBarButtonItemsRepresentativeItem,
-(id) jsinitWithBarButtonItems: (NSArray *) barButtonItems representativeItem: (UIBarButtonItem *) representativeItem );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
@end
@protocol UIBarButtonItemGroupClassExports<JSExport, NSCodingClassExports_>
+(UIBarButtonItemGroup *) fixedGroupWithRepresentativeItem: (UIBarButtonItem *) representativeItem items: (NSArray *) items ;
+(UIBarButtonItemGroup *) movableGroupWithCustomizationIdentifier: (NSString *) customizationIdentifier representativeItem: (UIBarButtonItem *) representativeItem items: (NSArray *) items ;
+(UIBarButtonItemGroup *) optionalGroupWithCustomizationIdentifier: (NSString *) customizationIdentifier inDefaultCustomization: (BOOL) inDefaultCustomization representativeItem: (UIBarButtonItem *) representativeItem items: (NSArray *) items ;
@end
@protocol UIBarButtonItemUIBarButtonItemGroupCategoryInstanceExports<JSExport>
@property (readonly,nonatomic,weak) UIBarButtonItemGroup * buttonGroup;
@end
@protocol UIBarButtonItemUIBarButtonItemGroupCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop