#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIBehavioralStyle_symbols(JSContext*);
@protocol UIButtonUIBehavioralStyleCategoryInstanceExports<JSExport>
@property (readonly,nonatomic) UIBehavioralStyle behavioralStyle;
@property (nonatomic) UIBehavioralStyle preferredBehavioralStyle;
@end
@protocol UIButtonUIBehavioralStyleCategoryClassExports<JSExport>
@end
@protocol UISliderUIBehavioralStyleCategoryInstanceExports<JSExport>
@property (readonly,nonatomic) UIBehavioralStyle behavioralStyle;
@property (nonatomic) UIBehavioralStyle preferredBehavioralStyle;
@end
@protocol UISliderUIBehavioralStyleCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop