#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIButton_symbols(JSContext*);
@protocol UIButtonInstanceExports<JSExport, NSCodingInstanceExports_>
@property (readwrite,copy,nonatomic) UIButtonConfiguration * configuration;
@property (getter=getJsConfigurationUpdateHandler,setter=setJsConfigurationUpdateHandler:) JSValue* jsconfigurationUpdateHandler;
@property (assign,readwrite,nonatomic) BOOL automaticallyUpdatesConfiguration;
@property (nonatomic,strong) UIColor * tintColor;
@property (readonly,nonatomic) UIButtonType buttonType;
@property (getter=isHovered,readonly,assign,nonatomic) BOOL hovered;
@property (getter=isHeld,readonly,assign,nonatomic) BOOL held;
@property (nonatomic) UIButtonRole role;
@property (getter=isPointerInteractionEnabled,assign,readwrite,nonatomic) BOOL pointerInteractionEnabled;
@property (getter=getJsPointerStyleProvider,setter=setJsPointerStyleProvider:) JSValue* jspointerStyleProvider;
@property (readwrite,copy,nonatomic) UIMenu * menu;
@property (nonatomic) UIContextMenuConfigurationElementOrder preferredMenuElementOrder;
@property (assign,readwrite,nonatomic) BOOL changesSelectionAsPrimaryAction;
@property (readonly,nonatomic,strong) NSString * currentTitle;
@property (readonly,nonatomic,strong) UIColor * currentTitleColor;
@property (readonly,nonatomic,strong) UIColor * currentTitleShadowColor;
@property (readonly,nonatomic,strong) UIImage * currentImage;
@property (readonly,nonatomic,strong) UIImage * currentBackgroundImage;
@property (readonly,nonatomic,strong) UIImageSymbolConfiguration * currentPreferredSymbolConfiguration;
@property (readonly,nonatomic,strong) NSAttributedString * currentAttributedTitle;
@property (readonly,nonatomic,strong) UILabel * titleLabel;
@property (readonly,nonatomic,strong) UIImageView * imageView;
@property (readonly,nonatomic,strong) UILabel * subtitleLabel;
JSExportAs(initWithFrame,
-(id) jsinitWithFrame: (CGRect) frame );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
JSExportAs(initWithFramePrimaryAction,
-(id) jsinitWithFrame: (CGRect) frame primaryAction: (UIAction *) primaryAction );
-(void) setNeedsUpdateConfiguration;
-(void) updateConfiguration;
-(void) setTitle: (NSString *) title forState: (UIControlState) state ;
-(void) setTitleColor: (UIColor *) color forState: (UIControlState) state ;
-(void) setTitleShadowColor: (UIColor *) color forState: (UIControlState) state ;
-(void) setImage: (UIImage *) image forState: (UIControlState) state ;
-(void) setBackgroundImage: (UIImage *) image forState: (UIControlState) state ;
-(void) setPreferredSymbolConfiguration: (UIImageSymbolConfiguration *) configuration forImageInState: (UIControlState) state ;
-(void) setAttributedTitle: (NSAttributedString *) title forState: (UIControlState) state ;
-(NSString *) titleForState: (UIControlState) state ;
-(UIColor *) titleColorForState: (UIControlState) state ;
-(UIColor *) titleShadowColorForState: (UIControlState) state ;
-(UIImage *) imageForState: (UIControlState) state ;
-(UIImage *) backgroundImageForState: (UIControlState) state ;
-(UIImageSymbolConfiguration *) preferredSymbolConfigurationForImageInState: (UIControlState) state ;
-(NSAttributedString *) attributedTitleForState: (UIControlState) state ;
@end
@protocol UIButtonClassExports<JSExport, NSCodingClassExports_>
+(id) buttonWithType: (UIButtonType) buttonType ;
JSExportAs(systemButtonWithImageTargetAction,
+(id) jssystemButtonWithImage: (UIImage *) image target: (id) target action: (NSString *) action );
+(id) systemButtonWithPrimaryAction: (UIAction *) primaryAction ;
+(id) buttonWithType: (UIButtonType) buttonType primaryAction: (UIAction *) primaryAction ;
+(id) buttonWithConfiguration: (UIButtonConfiguration *) configuration primaryAction: (UIAction *) primaryAction ;
@end
@protocol UIButtonAnonCategoryInstanceExports<JSExport>
@property (nonatomic,strong) UIFont * font;
@property (nonatomic) NSLineBreakMode lineBreakMode;
@property (nonatomic) CGSize titleShadowOffset;
@property (nonatomic) UIEdgeInsets contentEdgeInsets;
@property (nonatomic) UIEdgeInsets titleEdgeInsets;
@property (nonatomic) UIEdgeInsets imageEdgeInsets;
@property (nonatomic) BOOL reversesTitleShadowWhenHighlighted;
@property (nonatomic) BOOL adjustsImageWhenHighlighted;
@property (nonatomic) BOOL adjustsImageWhenDisabled;
@property (nonatomic) BOOL showsTouchWhenHighlighted;
-(CGRect) backgroundRectForBounds: (CGRect) bounds ;
-(CGRect) contentRectForBounds: (CGRect) bounds ;
-(CGRect) titleRectForContentRect: (CGRect) contentRect ;
-(CGRect) imageRectForContentRect: (CGRect) contentRect ;
@end
@protocol UIButtonAnonCategoryClassExports<JSExport>
@end
@protocol UIButtonSpringLoadingCategoryInstanceExports<JSExport, UISpringLoadedInteractionSupportingInstanceExports_>
@end
@protocol UIButtonSpringLoadingCategoryClassExports<JSExport, UISpringLoadedInteractionSupportingClassExports_>
@end
#pragma clang diagnostic pop