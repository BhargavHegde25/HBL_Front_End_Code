#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIButtonConfiguration_symbols(JSContext*);
@protocol UIButtonConfigurationInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readwrite,nonatomic,strong) UIBackgroundConfiguration * background;
@property (assign,readwrite,nonatomic) UIButtonConfigurationCornerStyle cornerStyle;
@property (assign,readwrite,nonatomic) UIButtonConfigurationSize buttonSize;
@property (assign,readwrite,nonatomic) UIButtonConfigurationMacIdiomStyle macIdiomStyle;
@property (readwrite,nonatomic,strong) UIColor * baseForegroundColor;
@property (readwrite,nonatomic,strong) UIColor * baseBackgroundColor;
@property (readwrite,nonatomic,strong) UIImage * image;
@property (getter=getJsImageColorTransformer,setter=setJsImageColorTransformer:) JSValue* jsimageColorTransformer;
@property (readwrite,copy,nonatomic) UIImageSymbolConfiguration * preferredSymbolConfigurationForImage;
@property (assign,readwrite,nonatomic) BOOL showsActivityIndicator;
@property (getter=getJsActivityIndicatorColorTransformer,setter=setJsActivityIndicatorColorTransformer:) JSValue* jsactivityIndicatorColorTransformer;
@property (readwrite,copy,nonatomic) NSString * title;
@property (readwrite,copy,nonatomic) NSAttributedString * attributedTitle;
@property (getter=getJsTitleTextAttributesTransformer,setter=setJsTitleTextAttributesTransformer:) JSValue* jstitleTextAttributesTransformer;
@property (assign,readwrite,nonatomic) NSLineBreakMode titleLineBreakMode;
@property (readwrite,copy,nonatomic) NSString * subtitle;
@property (readwrite,copy,nonatomic) NSAttributedString * attributedSubtitle;
@property (getter=getJsSubtitleTextAttributesTransformer,setter=setJsSubtitleTextAttributesTransformer:) JSValue* jssubtitleTextAttributesTransformer;
@property (assign,readwrite,nonatomic) NSLineBreakMode subtitleLineBreakMode;
@property (assign,readwrite,nonatomic) UIButtonConfigurationIndicator indicator;
@property (getter=getJsIndicatorColorTransformer,setter=setJsIndicatorColorTransformer:) JSValue* jsindicatorColorTransformer;
@property (assign,readwrite,nonatomic) NSDirectionalEdgeInsets contentInsets;
@property (assign,readwrite,nonatomic) NSDirectionalRectEdge imagePlacement;
@property (assign,readwrite,nonatomic) CGFloat imagePadding;
@property (assign,readwrite,nonatomic) CGFloat titlePadding;
@property (assign,readwrite,nonatomic) UIButtonConfigurationTitleAlignment titleAlignment;
@property (assign,readwrite,nonatomic) BOOL automaticallyUpdateForSelection;
-(id) updatedConfigurationForButton: (UIButton *) button ;
-(void) setDefaultContentInsets;
@end
@protocol UIButtonConfigurationClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
+(id) plainButtonConfiguration;
+(id) tintedButtonConfiguration;
+(id) grayButtonConfiguration;
+(id) filledButtonConfiguration;
+(id) borderlessButtonConfiguration;
+(id) borderedButtonConfiguration;
+(id) borderedTintedButtonConfiguration;
+(id) borderedProminentButtonConfiguration;
@end
#pragma clang diagnostic pop