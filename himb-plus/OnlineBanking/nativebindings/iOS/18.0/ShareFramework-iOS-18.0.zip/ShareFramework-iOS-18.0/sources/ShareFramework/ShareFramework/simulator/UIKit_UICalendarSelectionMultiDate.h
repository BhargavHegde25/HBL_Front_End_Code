#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UICalendarSelectionMultiDate_symbols(JSContext*);
@protocol UICalendarSelectionMultiDateInstanceExports<JSExport>
@property (copy,nonatomic) NSArray * selectedDates;
@property (readonly,nonatomic,weak) id delegate;
-(void) setSelectedDates: (NSArray *) selectedDates animated: (BOOL) animated ;
JSExportAs(initWithDelegate,
-(id) jsinitWithDelegate: (id) delegate );
@end
@protocol UICalendarSelectionMultiDateClassExports<JSExport>
@end
@protocol UICalendarSelectionMultiDateDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) multiDateSelection: (UICalendarSelectionMultiDate *) selection didSelectDate: (NSDateComponents *) dateComponents ;
-(void) multiDateSelection: (UICalendarSelectionMultiDate *) selection didDeselectDate: (NSDateComponents *) dateComponents ;
-(BOOL) multiDateSelection: (UICalendarSelectionMultiDate *) selection canSelectDate: (NSDateComponents *) dateComponents ;
-(BOOL) multiDateSelection: (UICalendarSelectionMultiDate *) selection canDeselectDate: (NSDateComponents *) dateComponents ;
@end
@protocol UICalendarSelectionMultiDateDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop