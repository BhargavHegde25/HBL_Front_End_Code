#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UICalendarSelectionSingleDate_symbols(JSContext*);
@protocol UICalendarSelectionSingleDateInstanceExports<JSExport>
@property (readonly,nonatomic,weak) id delegate;
@property (copy,nonatomic) NSDateComponents * selectedDate;
-(void) setSelectedDate: (NSDateComponents *) selectedDate animated: (BOOL) animated ;
JSExportAs(initWithDelegate,
-(id) jsinitWithDelegate: (id) delegate );
@end
@protocol UICalendarSelectionSingleDateClassExports<JSExport>
@end
@protocol UICalendarSelectionSingleDateDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) dateSelection: (UICalendarSelectionSingleDate *) selection didSelectDate: (NSDateComponents *) dateComponents ;
-(BOOL) dateSelection: (UICalendarSelectionSingleDate *) selection canSelectDate: (NSDateComponents *) dateComponents ;
@end
@protocol UICalendarSelectionSingleDateDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop