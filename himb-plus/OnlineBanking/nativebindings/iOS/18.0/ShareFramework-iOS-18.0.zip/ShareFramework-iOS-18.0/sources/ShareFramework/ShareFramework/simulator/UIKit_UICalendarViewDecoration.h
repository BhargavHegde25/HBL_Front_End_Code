#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UICalendarViewDecoration_symbols(JSContext*);
@protocol UICalendarViewDecorationInstanceExports<JSExport>
-(id) jsinit;
JSExportAs(initWithImageColorSize,
-(id) jsinitWithImage: (UIImage *) image color: (UIColor *) color size: (UICalendarViewDecorationSize) size );
JSExportAs(initWithCustomViewProvider,
-(id) jsinitWithCustomViewProvider: (JSValue *) customViewProvider );
@end
@protocol UICalendarViewDecorationClassExports<JSExport>
+(id) decorationWithColor: (UIColor *) color size: (UICalendarViewDecorationSize) size ;
+(id) decorationWithImage: (UIImage *) image ;
+(id) decorationWithImage: (UIImage *) image color: (UIColor *) color size: (UICalendarViewDecorationSize) size ;
JSExportAs(decorationWithCustomViewProvider,
+(id) jsdecorationWithCustomViewProvider: (JSValue *) customViewProvider );
@end
#pragma clang diagnostic pop