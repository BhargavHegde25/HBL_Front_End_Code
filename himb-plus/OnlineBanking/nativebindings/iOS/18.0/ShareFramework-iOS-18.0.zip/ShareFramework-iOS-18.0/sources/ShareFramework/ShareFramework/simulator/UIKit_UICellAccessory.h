#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UICellAccessory_symbols(JSContext*);
@protocol UICellAccessoryInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (nonatomic) UICellAccessoryDisplayedState displayedState;
@property (getter=isHidden,nonatomic) BOOL hidden;
@property (nonatomic) CGFloat reservedLayoutWidth;
@property (nonatomic,strong) UIColor * tintColor;
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
-(id) jsinit;
@end
@protocol UICellAccessoryClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
@end
@protocol UICellAccessoryDisclosureIndicatorInstanceExports<JSExport>
@end
@protocol UICellAccessoryDisclosureIndicatorClassExports<JSExport>
@end
@protocol UICellAccessoryDetailInstanceExports<JSExport>
@property (getter=getJsActionHandler,setter=setJsActionHandler:) JSValue* jsactionHandler;
@end
@protocol UICellAccessoryDetailClassExports<JSExport>
@end
@protocol UICellAccessoryCheckmarkInstanceExports<JSExport>
@end
@protocol UICellAccessoryCheckmarkClassExports<JSExport>
@end
@protocol UICellAccessoryDeleteInstanceExports<JSExport>
@property (nonatomic,strong) UIColor * backgroundColor;
@property (getter=getJsActionHandler,setter=setJsActionHandler:) JSValue* jsactionHandler;
@end
@protocol UICellAccessoryDeleteClassExports<JSExport>
@end
@protocol UICellAccessoryInsertInstanceExports<JSExport>
@property (nonatomic,strong) UIColor * backgroundColor;
@property (getter=getJsActionHandler,setter=setJsActionHandler:) JSValue* jsactionHandler;
@end
@protocol UICellAccessoryInsertClassExports<JSExport>
@end
@protocol UICellAccessoryReorderInstanceExports<JSExport>
@property (nonatomic) BOOL showsVerticalSeparator;
@end
@protocol UICellAccessoryReorderClassExports<JSExport>
@end
@protocol UICellAccessoryMultiselectInstanceExports<JSExport>
@property (nonatomic,strong) UIColor * backgroundColor;
@end
@protocol UICellAccessoryMultiselectClassExports<JSExport>
@end
@protocol UICellAccessoryOutlineDisclosureInstanceExports<JSExport>
@property (nonatomic) UICellAccessoryOutlineDisclosureStyle style;
@property (getter=getJsActionHandler,setter=setJsActionHandler:) JSValue* jsactionHandler;
@end
@protocol UICellAccessoryOutlineDisclosureClassExports<JSExport>
@end
@protocol UICellAccessoryPopUpMenuInstanceExports<JSExport>
@property (readonly,copy,nonatomic) UIMenu * menu;
@property (getter=getJsSelectedElementDidChangeHandler,setter=setJsSelectedElementDidChangeHandler:) JSValue* jsselectedElementDidChangeHandler;
JSExportAs(initWithMenu,
-(id) jsinitWithMenu: (UIMenu *) menu );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
@end
@protocol UICellAccessoryPopUpMenuClassExports<JSExport>
@end
@protocol UICellAccessoryLabelInstanceExports<JSExport>
@property (readonly,copy,nonatomic) NSString * text;
@property (nonatomic,strong) UIFont * font;
@property (nonatomic) BOOL adjustsFontForContentSizeCategory;
JSExportAs(initWithText,
-(id) jsinitWithText: (NSString *) text );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
@end
@protocol UICellAccessoryLabelClassExports<JSExport>
@end
@protocol UICellAccessoryCustomViewInstanceExports<JSExport>
@property (readonly,nonatomic,strong) UIView * customView;
@property (readonly,nonatomic) UICellAccessoryPlacement placement;
@property (nonatomic) BOOL maintainsFixedSize;
@property (getter=getJsPosition,setter=setJsPosition:) JSValue* jsposition;
JSExportAs(initWithCustomViewPlacement,
-(id) jsinitWithCustomView: (UIView *) customView placement: (UICellAccessoryPlacement) placement );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
@end
@protocol UICellAccessoryCustomViewClassExports<JSExport>
@end
#pragma clang diagnostic pop