#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UICloudSharingController_symbols(JSContext*);
@protocol UICloudSharingControllerInstanceExports<JSExport>
@property (nonatomic,weak) id delegate;
@property (readonly,nonatomic,strong) CKShare * share;
@property (nonatomic) UICloudSharingPermissionOptions availablePermissions;
JSExportAs(initWithPreparationHandler,
-(id) jsinitWithPreparationHandler: (JSValue *) preparationHandler );
JSExportAs(initWithShareContainer,
-(id) jsinitWithShare: (CKShare *) share container: (CKContainer *) container );
-(id) activityItemSource;
@end
@protocol UICloudSharingControllerClassExports<JSExport>
@end
@protocol UICloudSharingControllerDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) cloudSharingController: (UICloudSharingController *) csc failedToSaveShareWithError: (NSError *) error ;
-(NSString *) itemTitleForCloudSharingController: (UICloudSharingController *) csc ;
-(NSData *) itemThumbnailDataForCloudSharingController: (UICloudSharingController *) csc ;
-(NSString *) itemTypeForCloudSharingController: (UICloudSharingController *) csc ;
-(void) cloudSharingControllerDidSaveShare: (UICloudSharingController *) csc ;
-(void) cloudSharingControllerDidStopSharing: (UICloudSharingController *) csc ;
@end
@protocol UICloudSharingControllerDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop