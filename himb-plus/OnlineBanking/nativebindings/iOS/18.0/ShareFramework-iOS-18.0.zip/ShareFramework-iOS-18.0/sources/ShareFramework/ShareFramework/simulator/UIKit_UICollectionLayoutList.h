#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UICollectionLayoutList_symbols(JSContext*);
@protocol UICollectionLayoutListConfigurationInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (readonly,nonatomic) UICollectionLayoutListAppearance appearance;
@property (nonatomic) BOOL showsSeparators;
@property (copy,nonatomic) UIListSeparatorConfiguration * separatorConfiguration;
@property (getter=getJsItemSeparatorHandler,setter=setJsItemSeparatorHandler:) JSValue* jsitemSeparatorHandler;
@property (nonatomic,strong) UIColor * backgroundColor;
@property (getter=getJsLeadingSwipeActionsConfigurationProvider,setter=setJsLeadingSwipeActionsConfigurationProvider:) JSValue* jsleadingSwipeActionsConfigurationProvider;
@property (getter=getJsTrailingSwipeActionsConfigurationProvider,setter=setJsTrailingSwipeActionsConfigurationProvider:) JSValue* jstrailingSwipeActionsConfigurationProvider;
@property (nonatomic) UICollectionLayoutListHeaderMode headerMode;
@property (nonatomic) UICollectionLayoutListFooterMode footerMode;
@property (nonatomic) CGFloat headerTopPadding;
JSExportAs(initWithAppearance,
-(id) jsinitWithAppearance: (UICollectionLayoutListAppearance) appearance );
@end
@protocol UICollectionLayoutListConfigurationClassExports<JSExport, NSCopyingClassExports_>
@end
@protocol NSCollectionLayoutSectionUICollectionLayoutListSectionCategoryInstanceExports<JSExport>
@end
@protocol NSCollectionLayoutSectionUICollectionLayoutListSectionCategoryClassExports<JSExport>
+(id) sectionWithListConfiguration: (UICollectionLayoutListConfiguration *) configuration layoutEnvironment: (id) layoutEnvironment ;
@end
@protocol UICollectionViewCompositionalLayoutUICollectionLayoutListSectionCategoryInstanceExports<JSExport>
@end
@protocol UICollectionViewCompositionalLayoutUICollectionLayoutListSectionCategoryClassExports<JSExport>
+(id) layoutWithListConfiguration: (UICollectionLayoutListConfiguration *) configuration ;
@end
#pragma clang diagnostic pop