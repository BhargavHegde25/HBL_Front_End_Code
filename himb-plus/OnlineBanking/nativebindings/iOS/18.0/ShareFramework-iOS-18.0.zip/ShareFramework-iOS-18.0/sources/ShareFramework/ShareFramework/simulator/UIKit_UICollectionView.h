#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UICollectionView_symbols(JSContext*);
@protocol UICollectionViewFocusUpdateContextInstanceExports<JSExport>
@property (readonly,nonatomic,strong) NSIndexPath * previouslyFocusedIndexPath;
@property (readonly,nonatomic,strong) NSIndexPath * nextFocusedIndexPath;
@end
@protocol UICollectionViewFocusUpdateContextClassExports<JSExport>
@end
@protocol UICollectionViewInstanceExports<JSExport, UIDataSourceTranslatingInstanceExports_>
@property (nonatomic,strong) UICollectionViewLayout * collectionViewLayout;
@property (nonatomic,weak) id delegate;
@property (nonatomic,weak) id dataSource;
@property (nonatomic,weak) id prefetchDataSource;
@property (getter=isPrefetchingEnabled,nonatomic) BOOL prefetchingEnabled;
@property (nonatomic,weak) id dragDelegate;
@property (nonatomic,weak) id dropDelegate;
@property (nonatomic) BOOL dragInteractionEnabled;
@property (readonly,nonatomic) UIContextMenuInteraction * contextMenuInteraction;
@property (nonatomic) UICollectionViewReorderingCadence reorderingCadence;
@property (nonatomic) UICollectionViewSelfSizingInvalidation selfSizingInvalidation;
@property (nonatomic,strong) UIView * backgroundView;
@property (nonatomic) BOOL allowsSelection;
@property (nonatomic) BOOL allowsMultipleSelection;
@property (readonly,nonatomic) NSArray * indexPathsForSelectedItems;
@property (readonly,nonatomic) BOOL hasUncommittedUpdates;
@property (readonly,nonatomic) NSInteger numberOfSections;
@property (readonly,nonatomic) NSArray * visibleCells;
@property (readonly,nonatomic) NSArray * indexPathsForVisibleItems;
@property (nonatomic) BOOL remembersLastFocusedIndexPath;
@property (nonatomic) BOOL selectionFollowsFocus;
@property (nonatomic) BOOL allowsFocus;
@property (nonatomic) BOOL allowsFocusDuringEditing;
@property (readonly,nonatomic) BOOL hasActiveDrag;
@property (readonly,nonatomic) BOOL hasActiveDrop;
@property (getter=isEditing,nonatomic) BOOL editing;
@property (nonatomic) BOOL allowsSelectionDuringEditing;
@property (nonatomic) BOOL allowsMultipleSelectionDuringEditing;
JSExportAs(initWithFrameCollectionViewLayout,
-(id) jsinitWithFrame: (CGRect) frame collectionViewLayout: (UICollectionViewLayout *) layout );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
JSExportAs(registerClassForCellWithReuseIdentifier,
-(void) jsregisterClass: (JSValue *) cellClass forCellWithReuseIdentifier: (NSString *) identifier );
-(void) registerNib: (UINib *) nib forCellWithReuseIdentifier: (NSString *) identifier ;
JSExportAs(registerClassForSupplementaryViewOfKindWithReuseIdentifier,
-(void) jsregisterClass: (JSValue *) viewClass forSupplementaryViewOfKind: (NSString *) elementKind withReuseIdentifier: (NSString *) identifier );
-(void) registerNib: (UINib *) nib forSupplementaryViewOfKind: (NSString *) kind withReuseIdentifier: (NSString *) identifier ;
-(__kindof UICollectionViewCell *) dequeueReusableCellWithReuseIdentifier: (NSString *) identifier forIndexPath: (NSIndexPath *) indexPath ;
-(__kindof UICollectionReusableView *) dequeueReusableSupplementaryViewOfKind: (NSString *) elementKind withReuseIdentifier: (NSString *) identifier forIndexPath: (NSIndexPath *) indexPath ;
-(__kindof UICollectionViewCell *) dequeueConfiguredReusableCellWithRegistration: (UICollectionViewCellRegistration *) registration forIndexPath: (NSIndexPath *) indexPath item: (id) item ;
-(__kindof UICollectionReusableView *) dequeueConfiguredReusableSupplementaryViewWithRegistration: (UICollectionViewSupplementaryRegistration *) registration forIndexPath: (NSIndexPath *) indexPath ;
-(void) selectItemAtIndexPath: (NSIndexPath *) indexPath animated: (BOOL) animated scrollPosition: (UICollectionViewScrollPosition) scrollPosition ;
-(void) deselectItemAtIndexPath: (NSIndexPath *) indexPath animated: (BOOL) animated ;
-(void) reloadData;
-(void) setCollectionViewLayout: (UICollectionViewLayout *) layout animated: (BOOL) animated ;
JSExportAs(setCollectionViewLayoutAnimatedCompletion,
-(void) jssetCollectionViewLayout: (UICollectionViewLayout *) layout animated: (BOOL) animated completion: (JSValue *) completion );
JSExportAs(startInteractiveTransitionToCollectionViewLayoutCompletion,
-(UICollectionViewTransitionLayout *) jsstartInteractiveTransitionToCollectionViewLayout: (UICollectionViewLayout *) layout completion: (JSValue *) completion );
-(void) finishInteractiveTransition;
-(void) cancelInteractiveTransition;
-(NSInteger) numberOfItemsInSection: (NSInteger) section ;
-(UICollectionViewLayoutAttributes *) layoutAttributesForItemAtIndexPath: (NSIndexPath *) indexPath ;
-(UICollectionViewLayoutAttributes *) layoutAttributesForSupplementaryElementOfKind: (NSString *) kind atIndexPath: (NSIndexPath *) indexPath ;
-(NSIndexPath *) indexPathForItemAtPoint: (CGPoint) point ;
-(NSIndexPath *) indexPathForCell: (UICollectionViewCell *) cell ;
-(__kindof UICollectionViewCell *) cellForItemAtIndexPath: (NSIndexPath *) indexPath ;
-(UICollectionReusableView *) supplementaryViewForElementKind: (NSString *) elementKind atIndexPath: (NSIndexPath *) indexPath ;
-(NSArray *) visibleSupplementaryViewsOfKind: (NSString *) elementKind ;
-(NSArray *) indexPathsForVisibleSupplementaryElementsOfKind: (NSString *) elementKind ;
-(void) scrollToItemAtIndexPath: (NSIndexPath *) indexPath atScrollPosition: (UICollectionViewScrollPosition) scrollPosition animated: (BOOL) animated ;
-(void) insertSections: (NSIndexSet *) sections ;
-(void) deleteSections: (NSIndexSet *) sections ;
-(void) moveSection: (NSInteger) section toSection: (NSInteger) newSection ;
-(void) reloadSections: (NSIndexSet *) sections ;
-(void) insertItemsAtIndexPaths: (NSArray *) indexPaths ;
-(void) deleteItemsAtIndexPaths: (NSArray *) indexPaths ;
-(void) moveItemAtIndexPath: (NSIndexPath *) indexPath toIndexPath: (NSIndexPath *) newIndexPath ;
-(void) reloadItemsAtIndexPaths: (NSArray *) indexPaths ;
-(void) reconfigureItemsAtIndexPaths: (NSArray *) indexPaths ;
JSExportAs(performBatchUpdatesCompletion,
-(void) jsperformBatchUpdates: (JSValue *) updates completion: (JSValue *) completion );
-(BOOL) beginInteractiveMovementForItemAtIndexPath: (NSIndexPath *) indexPath ;
-(void) updateInteractiveMovementTargetPosition: (CGPoint) targetPosition ;
-(void) endInteractiveMovement;
-(void) cancelInteractiveMovement;
@end
@protocol UICollectionViewClassExports<JSExport, UIDataSourceTranslatingClassExports_>
@end
@protocol UICollectionViewUIDragAndDropCategoryInstanceExports<JSExport, UISpringLoadedInteractionSupportingInstanceExports_>
@end
@protocol UICollectionViewUIDragAndDropCategoryClassExports<JSExport, UISpringLoadedInteractionSupportingClassExports_>
@end
@protocol UICollectionViewDropProposalInstanceExports<JSExport>
@property (readonly,nonatomic) UICollectionViewDropIntent intent;
JSExportAs(initWithDropOperationIntent,
-(id) jsinitWithDropOperation: (UIDropOperation) operation intent: (UICollectionViewDropIntent) intent );
@end
@protocol UICollectionViewDropProposalClassExports<JSExport>
@end
@protocol UICollectionViewPlaceholderInstanceExports<JSExport>
@property (getter=getJsCellUpdateHandler,setter=setJsCellUpdateHandler:) JSValue* jscellUpdateHandler;
JSExportAs(initWithInsertionIndexPathReuseIdentifier,
-(id) jsinitWithInsertionIndexPath: (NSIndexPath *) insertionIndexPath reuseIdentifier: (NSString *) reuseIdentifier );
@end
@protocol UICollectionViewPlaceholderClassExports<JSExport>
@end
@protocol UICollectionViewDropPlaceholderInstanceExports<JSExport>
@property (getter=getJsPreviewParametersProvider,setter=setJsPreviewParametersProvider:) JSValue* jspreviewParametersProvider;
@end
@protocol UICollectionViewDropPlaceholderClassExports<JSExport>
@end
@protocol UICollectionViewDataSourceInstanceExports_<JSExport, NSObjectInstanceExports_>
-(NSInteger) collectionView: (UICollectionView *) collectionView numberOfItemsInSection: (NSInteger) section ;
-(__kindof UICollectionViewCell *) collectionView: (UICollectionView *) collectionView cellForItemAtIndexPath: (NSIndexPath *) indexPath ;
-(NSInteger) numberOfSectionsInCollectionView: (UICollectionView *) collectionView ;
-(UICollectionReusableView *) collectionView: (UICollectionView *) collectionView viewForSupplementaryElementOfKind: (NSString *) kind atIndexPath: (NSIndexPath *) indexPath ;
-(BOOL) collectionView: (UICollectionView *) collectionView canMoveItemAtIndexPath: (NSIndexPath *) indexPath ;
-(void) collectionView: (UICollectionView *) collectionView moveItemAtIndexPath: (NSIndexPath *) sourceIndexPath toIndexPath: (NSIndexPath *) destinationIndexPath ;
-(NSArray *) indexTitlesForCollectionView: (UICollectionView *) collectionView ;
-(NSIndexPath *) collectionView: (UICollectionView *) collectionView indexPathForIndexTitle: (NSString *) title atIndex: (NSInteger) index ;
@end
@protocol UICollectionViewDataSourceClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UICollectionViewDataSourcePrefetchingInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) collectionView: (UICollectionView *) collectionView prefetchItemsAtIndexPaths: (NSArray *) indexPaths ;
-(void) collectionView: (UICollectionView *) collectionView cancelPrefetchingForItemsAtIndexPaths: (NSArray *) indexPaths ;
@end
@protocol UICollectionViewDataSourcePrefetchingClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UICollectionViewDelegateInstanceExports_<JSExport, UIScrollViewDelegateInstanceExports_>
-(BOOL) collectionView: (UICollectionView *) collectionView shouldHighlightItemAtIndexPath: (NSIndexPath *) indexPath ;
-(void) collectionView: (UICollectionView *) collectionView didHighlightItemAtIndexPath: (NSIndexPath *) indexPath ;
-(void) collectionView: (UICollectionView *) collectionView didUnhighlightItemAtIndexPath: (NSIndexPath *) indexPath ;
-(BOOL) collectionView: (UICollectionView *) collectionView shouldSelectItemAtIndexPath: (NSIndexPath *) indexPath ;
-(BOOL) collectionView: (UICollectionView *) collectionView shouldDeselectItemAtIndexPath: (NSIndexPath *) indexPath ;
-(void) collectionView: (UICollectionView *) collectionView didSelectItemAtIndexPath: (NSIndexPath *) indexPath ;
-(void) collectionView: (UICollectionView *) collectionView didDeselectItemAtIndexPath: (NSIndexPath *) indexPath ;
-(BOOL) collectionView: (UICollectionView *) collectionView canPerformPrimaryActionForItemAtIndexPath: (NSIndexPath *) indexPath ;
-(void) collectionView: (UICollectionView *) collectionView performPrimaryActionForItemAtIndexPath: (NSIndexPath *) indexPath ;
-(void) collectionView: (UICollectionView *) collectionView willDisplayCell: (UICollectionViewCell *) cell forItemAtIndexPath: (NSIndexPath *) indexPath ;
-(void) collectionView: (UICollectionView *) collectionView willDisplaySupplementaryView: (UICollectionReusableView *) view forElementKind: (NSString *) elementKind atIndexPath: (NSIndexPath *) indexPath ;
-(void) collectionView: (UICollectionView *) collectionView didEndDisplayingCell: (UICollectionViewCell *) cell forItemAtIndexPath: (NSIndexPath *) indexPath ;
-(void) collectionView: (UICollectionView *) collectionView didEndDisplayingSupplementaryView: (UICollectionReusableView *) view forElementOfKind: (NSString *) elementKind atIndexPath: (NSIndexPath *) indexPath ;
-(BOOL) collectionView: (UICollectionView *) collectionView shouldShowMenuForItemAtIndexPath: (NSIndexPath *) indexPath ;
JSExportAs(collectionViewCanPerformActionForItemAtIndexPathWithSender,
-(BOOL) jscollectionView: (UICollectionView *) collectionView canPerformAction: (NSString *) action forItemAtIndexPath: (NSIndexPath *) indexPath withSender: (id) sender );
JSExportAs(collectionViewPerformActionForItemAtIndexPathWithSender,
-(void) jscollectionView: (UICollectionView *) collectionView performAction: (NSString *) action forItemAtIndexPath: (NSIndexPath *) indexPath withSender: (id) sender );
-(UICollectionViewTransitionLayout *) collectionView: (UICollectionView *) collectionView transitionLayoutForOldLayout: (UICollectionViewLayout *) fromLayout newLayout: (UICollectionViewLayout *) toLayout ;
-(BOOL) collectionView: (UICollectionView *) collectionView canFocusItemAtIndexPath: (NSIndexPath *) indexPath ;
-(BOOL) collectionView: (UICollectionView *) collectionView shouldUpdateFocusInContext: (UICollectionViewFocusUpdateContext *) context ;
-(void) collectionView: (UICollectionView *) collectionView didUpdateFocusInContext: (UICollectionViewFocusUpdateContext *) context withAnimationCoordinator: (UIFocusAnimationCoordinator *) coordinator ;
-(NSIndexPath *) indexPathForPreferredFocusedViewInCollectionView: (UICollectionView *) collectionView ;
-(BOOL) collectionView: (UICollectionView *) collectionView selectionFollowsFocusForItemAtIndexPath: (NSIndexPath *) indexPath ;
-(NSIndexPath *) collectionView: (UICollectionView *) collectionView targetIndexPathForMoveOfItemFromOriginalIndexPath: (NSIndexPath *) originalIndexPath atCurrentIndexPath: (NSIndexPath *) currentIndexPath toProposedIndexPath: (NSIndexPath *) proposedIndexPath ;
-(NSIndexPath *) collectionView: (UICollectionView *) collectionView targetIndexPathForMoveFromItemAtIndexPath: (NSIndexPath *) currentIndexPath toProposedIndexPath: (NSIndexPath *) proposedIndexPath ;
-(CGPoint) collectionView: (UICollectionView *) collectionView targetContentOffsetForProposedContentOffset: (CGPoint) proposedContentOffset ;
-(BOOL) collectionView: (UICollectionView *) collectionView canEditItemAtIndexPath: (NSIndexPath *) indexPath ;
-(BOOL) collectionView: (UICollectionView *) collectionView shouldSpringLoadItemAtIndexPath: (NSIndexPath *) indexPath withContext: (id) context ;
-(BOOL) collectionView: (UICollectionView *) collectionView shouldBeginMultipleSelectionInteractionAtIndexPath: (NSIndexPath *) indexPath ;
-(void) collectionView: (UICollectionView *) collectionView didBeginMultipleSelectionInteractionAtIndexPath: (NSIndexPath *) indexPath ;
-(void) collectionViewDidEndMultipleSelectionInteraction: (UICollectionView *) collectionView ;
-(UIContextMenuConfiguration *) collectionView: (UICollectionView *) collectionView contextMenuConfigurationForItemsAtIndexPaths: (NSArray *) indexPaths point: (CGPoint) point ;
-(UITargetedPreview *) collectionView: (UICollectionView *) collectionView contextMenuConfiguration: (UIContextMenuConfiguration *) configuration highlightPreviewForItemAtIndexPath: (NSIndexPath *) indexPath ;
-(UITargetedPreview *) collectionView: (UICollectionView *) collectionView contextMenuConfiguration: (UIContextMenuConfiguration *) configuration dismissalPreviewForItemAtIndexPath: (NSIndexPath *) indexPath ;
-(void) collectionView: (UICollectionView *) collectionView willPerformPreviewActionForMenuWithConfiguration: (UIContextMenuConfiguration *) configuration animator: (id) animator ;
-(void) collectionView: (UICollectionView *) collectionView willDisplayContextMenuWithConfiguration: (UIContextMenuConfiguration *) configuration animator: (id) animator ;
-(void) collectionView: (UICollectionView *) collectionView willEndContextMenuInteractionWithConfiguration: (UIContextMenuConfiguration *) configuration animator: (id) animator ;
-(UIWindowSceneActivationConfiguration *) collectionView: (UICollectionView *) collectionView sceneActivationConfigurationForItemAtIndexPath: (NSIndexPath *) indexPath point: (CGPoint) point ;
-(UIContextMenuConfiguration *) collectionView: (UICollectionView *) collectionView contextMenuConfigurationForItemAtIndexPath: (NSIndexPath *) indexPath point: (CGPoint) point ;
-(UITargetedPreview *) collectionView: (UICollectionView *) collectionView previewForHighlightingContextMenuWithConfiguration: (UIContextMenuConfiguration *) configuration ;
-(UITargetedPreview *) collectionView: (UICollectionView *) collectionView previewForDismissingContextMenuWithConfiguration: (UIContextMenuConfiguration *) configuration ;
@end
@protocol UICollectionViewDelegateClassExports_<JSExport, UIScrollViewDelegateClassExports_>
@end
@protocol UICollectionViewDragDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(NSArray *) collectionView: (UICollectionView *) collectionView itemsForBeginningDragSession: (id) session atIndexPath: (NSIndexPath *) indexPath ;
-(NSArray *) collectionView: (UICollectionView *) collectionView itemsForAddingToDragSession: (id) session atIndexPath: (NSIndexPath *) indexPath point: (CGPoint) point ;
-(UIDragPreviewParameters *) collectionView: (UICollectionView *) collectionView dragPreviewParametersForItemAtIndexPath: (NSIndexPath *) indexPath ;
-(void) collectionView: (UICollectionView *) collectionView dragSessionWillBegin: (id) session ;
-(void) collectionView: (UICollectionView *) collectionView dragSessionDidEnd: (id) session ;
-(BOOL) collectionView: (UICollectionView *) collectionView dragSessionAllowsMoveOperation: (id) session ;
-(BOOL) collectionView: (UICollectionView *) collectionView dragSessionIsRestrictedToDraggingApplication: (id) session ;
@end
@protocol UICollectionViewDragDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UICollectionViewDropDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) collectionView: (UICollectionView *) collectionView performDropWithCoordinator: (id) coordinator ;
-(BOOL) collectionView: (UICollectionView *) collectionView canHandleDropSession: (id) session ;
-(void) collectionView: (UICollectionView *) collectionView dropSessionDidEnter: (id) session ;
-(UICollectionViewDropProposal *) collectionView: (UICollectionView *) collectionView dropSessionDidUpdate: (id) session withDestinationIndexPath: (NSIndexPath *) destinationIndexPath ;
-(void) collectionView: (UICollectionView *) collectionView dropSessionDidExit: (id) session ;
-(void) collectionView: (UICollectionView *) collectionView dropSessionDidEnd: (id) session ;
-(UIDragPreviewParameters *) collectionView: (UICollectionView *) collectionView dropPreviewParametersForItemAtIndexPath: (NSIndexPath *) indexPath ;
@end
@protocol UICollectionViewDropDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UICollectionViewDropCoordinatorInstanceExports_<JSExport, NSObjectInstanceExports_>
@property (readonly,nonatomic) NSArray * items;
@property (readonly,nonatomic) NSIndexPath * destinationIndexPath;
@property (readonly,nonatomic) UICollectionViewDropProposal * proposal;
@property (readonly,nonatomic) id session;
-(id) dropItem: (UIDragItem *) dragItem toPlaceholder: (UICollectionViewDropPlaceholder *) placeholder ;
-(id) dropItem: (UIDragItem *) dragItem toItemAtIndexPath: (NSIndexPath *) indexPath ;
-(id) dropItem: (UIDragItem *) dragItem intoItemAtIndexPath: (NSIndexPath *) indexPath rect: (CGRect) rect ;
-(id) dropItem: (UIDragItem *) dragItem toTarget: (UIDragPreviewTarget *) target ;
@end
@protocol UICollectionViewDropCoordinatorClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UICollectionViewDropItemInstanceExports_<JSExport, NSObjectInstanceExports_>
@property (readonly,nonatomic) UIDragItem * dragItem;
@property (readonly,nonatomic) NSIndexPath * sourceIndexPath;
@property (readonly,nonatomic) CGSize previewSize;
@end
@protocol UICollectionViewDropItemClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UICollectionViewDropPlaceholderContextInstanceExports_<JSExport, UIDragAnimatingInstanceExports_>
@property (readonly,nonatomic) UIDragItem * dragItem;
JSExportAs(commitInsertionWithDataSourceUpdates,
-(BOOL) jscommitInsertionWithDataSourceUpdates: (JSValue *) dataSourceUpdates );
-(BOOL) deletePlaceholder;
-(void) setNeedsCellUpdate;
@end
@protocol UICollectionViewDropPlaceholderContextClassExports_<JSExport, UIDragAnimatingClassExports_>
@end
#pragma clang diagnostic pop