#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UICollectionViewCompositionalLayout_symbols(JSContext*);
@protocol UICollectionViewCompositionalLayoutConfigurationInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (nonatomic) UICollectionViewScrollDirection scrollDirection;
@property (nonatomic) CGFloat interSectionSpacing;
@property (copy,nonatomic) NSArray * boundarySupplementaryItems;
@property (nonatomic) UIContentInsetsReference contentInsetsReference;
@end
@protocol UICollectionViewCompositionalLayoutConfigurationClassExports<JSExport, NSCopyingClassExports_>
@end
@protocol UICollectionViewCompositionalLayoutInstanceExports<JSExport>
@property (copy,nonatomic) UICollectionViewCompositionalLayoutConfiguration * configuration;
JSExportAs(initWithSection,
-(id) jsinitWithSection: (NSCollectionLayoutSection *) section );
JSExportAs(initWithSectionConfiguration,
-(id) jsinitWithSection: (NSCollectionLayoutSection *) section configuration: (UICollectionViewCompositionalLayoutConfiguration *) configuration );
JSExportAs(initWithSectionProvider,
-(id) jsinitWithSectionProvider: (JSValue *) sectionProvider );
JSExportAs(initWithSectionProviderConfiguration,
-(id) jsinitWithSectionProvider: (JSValue *) sectionProvider configuration: (UICollectionViewCompositionalLayoutConfiguration *) configuration );
@end
@protocol UICollectionViewCompositionalLayoutClassExports<JSExport>
@end
@protocol UICollectionLayoutSectionOrthogonalScrollingPropertiesInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (nonatomic) UICollectionLayoutSectionOrthogonalScrollingBounce bounce;
@end
@protocol UICollectionLayoutSectionOrthogonalScrollingPropertiesClassExports<JSExport, NSCopyingClassExports_>
@end
@protocol NSCollectionLayoutSectionInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (nonatomic) NSDirectionalEdgeInsets contentInsets;
@property (nonatomic) CGFloat interGroupSpacing;
@property (nonatomic) UIContentInsetsReference contentInsetsReference;
@property (nonatomic) UIContentInsetsReference supplementaryContentInsetsReference;
@property (nonatomic) UICollectionLayoutSectionOrthogonalScrollingBehavior orthogonalScrollingBehavior;
@property (readonly,nonatomic) UICollectionLayoutSectionOrthogonalScrollingProperties * orthogonalScrollingProperties;
@property (copy,nonatomic) NSArray * boundarySupplementaryItems;
@property (getter=getJsVisibleItemsInvalidationHandler,setter=setJsVisibleItemsInvalidationHandler:) JSValue* jsvisibleItemsInvalidationHandler;
@property (copy,nonatomic) NSArray * decorationItems;
@end
@protocol NSCollectionLayoutSectionClassExports<JSExport, NSCopyingClassExports_>
+(id) sectionWithGroup: (NSCollectionLayoutGroup *) group ;
@end
@protocol NSCollectionLayoutItemInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (nonatomic) NSDirectionalEdgeInsets contentInsets;
@property (copy,nonatomic) NSCollectionLayoutEdgeSpacing * edgeSpacing;
@property (readonly,nonatomic) NSCollectionLayoutSize * layoutSize;
@property (readonly,nonatomic) NSArray * supplementaryItems;
@end
@protocol NSCollectionLayoutItemClassExports<JSExport, NSCopyingClassExports_>
+(id) itemWithLayoutSize: (NSCollectionLayoutSize *) layoutSize ;
+(id) itemWithLayoutSize: (NSCollectionLayoutSize *) layoutSize supplementaryItems: (NSArray *) supplementaryItems ;
@end
@protocol NSCollectionLayoutGroupCustomItemInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (readonly,nonatomic) CGRect frame;
@property (readonly,nonatomic) NSInteger zIndex;
@end
@protocol NSCollectionLayoutGroupCustomItemClassExports<JSExport, NSCopyingClassExports_>
+(id) customItemWithFrame: (CGRect) frame ;
+(id) customItemWithFrame: (CGRect) frame zIndex: (NSInteger) zIndex ;
@end
@protocol NSCollectionLayoutGroupInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (copy,nonatomic) NSArray * supplementaryItems;
@property (copy,nonatomic) NSCollectionLayoutSpacing * interItemSpacing;
@property (readonly,nonatomic) NSArray * subitems;
-(NSString *) visualDescription;
@end
@protocol NSCollectionLayoutGroupClassExports<JSExport, NSCopyingClassExports_>
+(id) horizontalGroupWithLayoutSize: (NSCollectionLayoutSize *) layoutSize repeatingSubitem: (NSCollectionLayoutItem *) subitem count: (NSInteger) count ;
+(id) horizontalGroupWithLayoutSize: (NSCollectionLayoutSize *) layoutSize subitems: (NSArray *) subitems ;
+(id) verticalGroupWithLayoutSize: (NSCollectionLayoutSize *) layoutSize repeatingSubitem: (NSCollectionLayoutItem *) subitem count: (NSInteger) count ;
+(id) verticalGroupWithLayoutSize: (NSCollectionLayoutSize *) layoutSize subitems: (NSArray *) subitems ;
JSExportAs(customGroupWithLayoutSizeItemProvider,
+(id) jscustomGroupWithLayoutSize: (NSCollectionLayoutSize *) layoutSize itemProvider: (JSValue *) itemProvider );
@end
@protocol NSCollectionLayoutDimensionInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (readonly,nonatomic) BOOL isFractionalWidth;
@property (readonly,nonatomic) BOOL isFractionalHeight;
@property (readonly,nonatomic) BOOL isAbsolute;
@property (readonly,nonatomic) BOOL isEstimated;
@property (readonly,nonatomic) BOOL isUniformAcrossSiblings;
@property (readonly,nonatomic) CGFloat dimension;
@end
@protocol NSCollectionLayoutDimensionClassExports<JSExport, NSCopyingClassExports_>
+(id) fractionalWidthDimension: (CGFloat) fractionalWidth ;
+(id) fractionalHeightDimension: (CGFloat) fractionalHeight ;
+(id) absoluteDimension: (CGFloat) absoluteDimension ;
+(id) estimatedDimension: (CGFloat) estimatedDimension ;
+(id) uniformAcrossSiblingsWithEstimate: (CGFloat) estimatedDimension ;
@end
@protocol NSCollectionLayoutSizeInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (readonly,nonatomic) NSCollectionLayoutDimension * widthDimension;
@property (readonly,nonatomic) NSCollectionLayoutDimension * heightDimension;
@end
@protocol NSCollectionLayoutSizeClassExports<JSExport, NSCopyingClassExports_>
+(id) sizeWithWidthDimension: (NSCollectionLayoutDimension *) width heightDimension: (NSCollectionLayoutDimension *) height ;
@end
@protocol NSCollectionLayoutSpacingInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (readonly,nonatomic) CGFloat spacing;
@property (readonly,nonatomic) BOOL isFlexibleSpacing;
@property (readonly,nonatomic) BOOL isFixedSpacing;
@end
@protocol NSCollectionLayoutSpacingClassExports<JSExport, NSCopyingClassExports_>
+(id) flexibleSpacing: (CGFloat) flexibleSpacing ;
+(id) fixedSpacing: (CGFloat) fixedSpacing ;
@end
@protocol NSCollectionLayoutEdgeSpacingInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (readonly,nonatomic) NSCollectionLayoutSpacing * leading;
@property (readonly,nonatomic) NSCollectionLayoutSpacing * top;
@property (readonly,nonatomic) NSCollectionLayoutSpacing * trailing;
@property (readonly,nonatomic) NSCollectionLayoutSpacing * bottom;
@end
@protocol NSCollectionLayoutEdgeSpacingClassExports<JSExport, NSCopyingClassExports_>
+(id) spacingForLeading: (NSCollectionLayoutSpacing *) leading top: (NSCollectionLayoutSpacing *) top trailing: (NSCollectionLayoutSpacing *) trailing bottom: (NSCollectionLayoutSpacing *) bottom ;
@end
@protocol NSCollectionLayoutSupplementaryItemInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (nonatomic) NSInteger zIndex;
@property (readonly,nonatomic) NSString * elementKind;
@property (readonly,nonatomic) NSCollectionLayoutAnchor * containerAnchor;
@property (readonly,nonatomic) NSCollectionLayoutAnchor * itemAnchor;
@end
@protocol NSCollectionLayoutSupplementaryItemClassExports<JSExport, NSCopyingClassExports_>
+(id) supplementaryItemWithLayoutSize: (NSCollectionLayoutSize *) layoutSize elementKind: (NSString *) elementKind containerAnchor: (NSCollectionLayoutAnchor *) containerAnchor ;
+(id) supplementaryItemWithLayoutSize: (NSCollectionLayoutSize *) layoutSize elementKind: (NSString *) elementKind containerAnchor: (NSCollectionLayoutAnchor *) containerAnchor itemAnchor: (NSCollectionLayoutAnchor *) itemAnchor ;
@end
@protocol NSCollectionLayoutBoundarySupplementaryItemInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (nonatomic) BOOL extendsBoundary;
@property (nonatomic) BOOL pinToVisibleBounds;
@property (readonly,nonatomic) NSRectAlignment alignment;
@property (readonly,nonatomic) CGPoint offset;
@end
@protocol NSCollectionLayoutBoundarySupplementaryItemClassExports<JSExport, NSCopyingClassExports_>
+(id) boundarySupplementaryItemWithLayoutSize: (NSCollectionLayoutSize *) layoutSize elementKind: (NSString *) elementKind alignment: (NSRectAlignment) alignment ;
+(id) boundarySupplementaryItemWithLayoutSize: (NSCollectionLayoutSize *) layoutSize elementKind: (NSString *) elementKind alignment: (NSRectAlignment) alignment absoluteOffset: (CGPoint) absoluteOffset ;
@end
@protocol NSCollectionLayoutDecorationItemInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (nonatomic) NSInteger zIndex;
@property (readonly,nonatomic) NSString * elementKind;
@end
@protocol NSCollectionLayoutDecorationItemClassExports<JSExport, NSCopyingClassExports_>
+(id) backgroundDecorationItemWithElementKind: (NSString *) elementKind ;
@end
@protocol NSCollectionLayoutAnchorInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (readonly,nonatomic) NSDirectionalRectEdge edges;
@property (readonly,nonatomic) CGPoint offset;
@property (readonly,nonatomic) BOOL isAbsoluteOffset;
@property (readonly,nonatomic) BOOL isFractionalOffset;
@end
@protocol NSCollectionLayoutAnchorClassExports<JSExport, NSCopyingClassExports_>
+(id) layoutAnchorWithEdges: (NSDirectionalRectEdge) edges ;
+(id) layoutAnchorWithEdges: (NSDirectionalRectEdge) edges absoluteOffset: (CGPoint) absoluteOffset ;
+(id) layoutAnchorWithEdges: (NSDirectionalRectEdge) edges fractionalOffset: (CGPoint) fractionalOffset ;
@end
@protocol NSCollectionLayoutSectionDeprecatedCategoryInstanceExports<JSExport>
@property (nonatomic) BOOL supplementariesFollowContentInsets;
@end
@protocol NSCollectionLayoutSectionDeprecatedCategoryClassExports<JSExport>
@end
@protocol NSCollectionLayoutGroupDeprecatedCategoryInstanceExports<JSExport>
@end
@protocol NSCollectionLayoutGroupDeprecatedCategoryClassExports<JSExport>
+(id) horizontalGroupWithLayoutSize: (NSCollectionLayoutSize *) layoutSize subitem: (NSCollectionLayoutItem *) subitem count: (NSInteger) count ;
+(id) verticalGroupWithLayoutSize: (NSCollectionLayoutSize *) layoutSize subitem: (NSCollectionLayoutItem *) subitem count: (NSInteger) count ;
@end
@protocol NSCollectionLayoutContainerInstanceExports_<JSExport, NSObjectInstanceExports_>
@property (readonly,nonatomic) CGSize contentSize;
@property (readonly,nonatomic) CGSize effectiveContentSize;
@property (readonly,nonatomic) NSDirectionalEdgeInsets contentInsets;
@property (readonly,nonatomic) NSDirectionalEdgeInsets effectiveContentInsets;
@end
@protocol NSCollectionLayoutContainerClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol NSCollectionLayoutEnvironmentInstanceExports_<JSExport, NSObjectInstanceExports_>
@property (readonly,nonatomic) id container;
@property (readonly,nonatomic) UITraitCollection * traitCollection;
@end
@protocol NSCollectionLayoutEnvironmentClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol NSCollectionLayoutVisibleItemInstanceExports_<JSExport, NSObjectInstanceExports_, UIDynamicItemInstanceExports_>
@property (nonatomic) CGFloat alpha;
@property (nonatomic) NSInteger zIndex;
@property (getter=isHidden,nonatomic) BOOL hidden;
@property (nonatomic) CGPoint center;
@property (nonatomic) CGAffineTransform transform;
@property (nonatomic) CATransform3D transform3D;
@property (readonly,nonatomic) NSString * name;
@property (readonly,nonatomic) NSIndexPath * indexPath;
@property (readonly,nonatomic) CGRect frame;
@property (readonly,nonatomic) CGRect bounds;
@property (readonly,nonatomic) UICollectionElementCategory representedElementCategory;
@property (readonly,nonatomic) NSString * representedElementKind;
@end
@protocol NSCollectionLayoutVisibleItemClassExports_<JSExport, NSObjectClassExports_, UIDynamicItemClassExports_>
@end
#pragma clang diagnostic pop