#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UICollectionViewLayout_symbols(JSContext*);
@protocol UICollectionViewLayoutAttributesInstanceExports<JSExport, NSCopyingInstanceExports_, UIDynamicItemInstanceExports_>
@property (nonatomic) CGRect frame;
@property (nonatomic) CGPoint center;
@property (nonatomic) CGSize size;
@property (nonatomic) CATransform3D transform3D;
@property (nonatomic) CGRect bounds;
@property (nonatomic) CGAffineTransform transform;
@property (nonatomic) CGFloat alpha;
@property (nonatomic) NSInteger zIndex;
@property (getter=isHidden,nonatomic) BOOL hidden;
@property (nonatomic,strong) NSIndexPath * indexPath;
@property (readonly,nonatomic) UICollectionElementCategory representedElementCategory;
@property (readonly,nonatomic) NSString * representedElementKind;
@end
@protocol UICollectionViewLayoutAttributesClassExports<JSExport, NSCopyingClassExports_, UIDynamicItemClassExports_>
+(id) layoutAttributesForCellWithIndexPath: (NSIndexPath *) indexPath ;
+(id) layoutAttributesForSupplementaryViewOfKind: (NSString *) elementKind withIndexPath: (NSIndexPath *) indexPath ;
+(id) layoutAttributesForDecorationViewOfKind: (NSString *) decorationViewKind withIndexPath: (NSIndexPath *) indexPath ;
@end
@protocol UICollectionViewLayoutInvalidationContextInstanceExports<JSExport>
@property (readonly,nonatomic) BOOL invalidateEverything;
@property (readonly,nonatomic) BOOL invalidateDataSourceCounts;
@property (readonly,nonatomic) NSArray * invalidatedItemIndexPaths;
@property (readonly,nonatomic) NSDictionary * invalidatedSupplementaryIndexPaths;
@property (readonly,nonatomic) NSDictionary * invalidatedDecorationIndexPaths;
@property (nonatomic) CGPoint contentOffsetAdjustment;
@property (nonatomic) CGSize contentSizeAdjustment;
@property (readonly,copy,nonatomic) NSArray * previousIndexPathsForInteractivelyMovingItems;
@property (readonly,copy,nonatomic) NSArray * targetIndexPathsForInteractivelyMovingItems;
@property (readonly,nonatomic) CGPoint interactiveMovementTarget;
-(void) invalidateItemsAtIndexPaths: (NSArray *) indexPaths ;
-(void) invalidateSupplementaryElementsOfKind: (NSString *) elementKind atIndexPaths: (NSArray *) indexPaths ;
-(void) invalidateDecorationElementsOfKind: (NSString *) elementKind atIndexPaths: (NSArray *) indexPaths ;
@end
@protocol UICollectionViewLayoutInvalidationContextClassExports<JSExport>
@end
@protocol UICollectionViewLayoutInstanceExports<JSExport, NSCodingInstanceExports_>
@property (readonly,nonatomic) UICollectionView * collectionView;
-(id) jsinit;
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
-(void) invalidateLayout;
-(void) invalidateLayoutWithContext: (UICollectionViewLayoutInvalidationContext *) context ;
JSExportAs(registerClassForDecorationViewOfKind,
-(void) jsregisterClass: (JSValue *) viewClass forDecorationViewOfKind: (NSString *) elementKind );
-(void) registerNib: (UINib *) nib forDecorationViewOfKind: (NSString *) elementKind ;
@end
@protocol UICollectionViewLayoutClassExports<JSExport, NSCodingClassExports_>
@end
@protocol UICollectionViewLayoutUISubclassingHooksCategoryInstanceExports<JSExport>
@property (readonly,nonatomic) CGSize collectionViewContentSize;
@property (readonly,nonatomic) UIUserInterfaceLayoutDirection developmentLayoutDirection;
@property (readonly,nonatomic) BOOL flipsHorizontallyInOppositeLayoutDirection;
-(void) prepareLayout;
-(NSArray *) layoutAttributesForElementsInRect: (CGRect) rect ;
-(UICollectionViewLayoutAttributes *) layoutAttributesForItemAtIndexPath: (NSIndexPath *) indexPath ;
-(UICollectionViewLayoutAttributes *) layoutAttributesForSupplementaryViewOfKind: (NSString *) elementKind atIndexPath: (NSIndexPath *) indexPath ;
-(UICollectionViewLayoutAttributes *) layoutAttributesForDecorationViewOfKind: (NSString *) elementKind atIndexPath: (NSIndexPath *) indexPath ;
-(BOOL) shouldInvalidateLayoutForBoundsChange: (CGRect) newBounds ;
-(UICollectionViewLayoutInvalidationContext *) invalidationContextForBoundsChange: (CGRect) newBounds ;
-(BOOL) shouldInvalidateLayoutForPreferredLayoutAttributes: (UICollectionViewLayoutAttributes *) preferredAttributes withOriginalAttributes: (UICollectionViewLayoutAttributes *) originalAttributes ;
-(UICollectionViewLayoutInvalidationContext *) invalidationContextForPreferredLayoutAttributes: (UICollectionViewLayoutAttributes *) preferredAttributes withOriginalAttributes: (UICollectionViewLayoutAttributes *) originalAttributes ;
-(CGPoint) targetContentOffsetForProposedContentOffset: (CGPoint) proposedContentOffset withScrollingVelocity: (CGPoint) velocity ;
-(CGPoint) targetContentOffsetForProposedContentOffset: (CGPoint) proposedContentOffset ;
@end
@protocol UICollectionViewLayoutUISubclassingHooksCategoryClassExports<JSExport>
+(id) layoutAttributesClass;
+(id) invalidationContextClass;
@end
@protocol UICollectionViewLayoutUIUpdateSupportHooksCategoryInstanceExports<JSExport>
-(void) prepareForCollectionViewUpdates: (NSArray *) updateItems ;
-(void) finalizeCollectionViewUpdates;
-(void) prepareForAnimatedBoundsChange: (CGRect) oldBounds ;
-(void) finalizeAnimatedBoundsChange;
-(void) prepareForTransitionToLayout: (UICollectionViewLayout *) newLayout ;
-(void) prepareForTransitionFromLayout: (UICollectionViewLayout *) oldLayout ;
-(void) finalizeLayoutTransition;
JSExportAs(initialLayoutAttributesForAppearingItemAtIndexPath,
-(UICollectionViewLayoutAttributes *) jsinitialLayoutAttributesForAppearingItemAtIndexPath: (NSIndexPath *) itemIndexPath );
-(UICollectionViewLayoutAttributes *) finalLayoutAttributesForDisappearingItemAtIndexPath: (NSIndexPath *) itemIndexPath ;
JSExportAs(initialLayoutAttributesForAppearingSupplementaryElementOfKindAtIndexPath,
-(UICollectionViewLayoutAttributes *) jsinitialLayoutAttributesForAppearingSupplementaryElementOfKind: (NSString *) elementKind atIndexPath: (NSIndexPath *) elementIndexPath );
-(UICollectionViewLayoutAttributes *) finalLayoutAttributesForDisappearingSupplementaryElementOfKind: (NSString *) elementKind atIndexPath: (NSIndexPath *) elementIndexPath ;
JSExportAs(initialLayoutAttributesForAppearingDecorationElementOfKindAtIndexPath,
-(UICollectionViewLayoutAttributes *) jsinitialLayoutAttributesForAppearingDecorationElementOfKind: (NSString *) elementKind atIndexPath: (NSIndexPath *) decorationIndexPath );
-(UICollectionViewLayoutAttributes *) finalLayoutAttributesForDisappearingDecorationElementOfKind: (NSString *) elementKind atIndexPath: (NSIndexPath *) decorationIndexPath ;
-(NSArray *) indexPathsToDeleteForSupplementaryViewOfKind: (NSString *) elementKind ;
-(NSArray *) indexPathsToDeleteForDecorationViewOfKind: (NSString *) elementKind ;
-(NSArray *) indexPathsToInsertForSupplementaryViewOfKind: (NSString *) elementKind ;
-(NSArray *) indexPathsToInsertForDecorationViewOfKind: (NSString *) elementKind ;
@end
@protocol UICollectionViewLayoutUIUpdateSupportHooksCategoryClassExports<JSExport>
@end
@protocol UICollectionViewLayoutUIReorderingSupportHooksCategoryInstanceExports<JSExport>
-(NSIndexPath *) targetIndexPathForInteractivelyMovingItem: (NSIndexPath *) previousIndexPath withPosition: (CGPoint) position ;
-(UICollectionViewLayoutAttributes *) layoutAttributesForInteractivelyMovingItemAtIndexPath: (NSIndexPath *) indexPath withTargetPosition: (CGPoint) position ;
-(UICollectionViewLayoutInvalidationContext *) invalidationContextForInteractivelyMovingItems: (NSArray *) targetIndexPaths withTargetPosition: (CGPoint) targetPosition previousIndexPaths: (NSArray *) previousIndexPaths previousPosition: (CGPoint) previousPosition ;
-(UICollectionViewLayoutInvalidationContext *) invalidationContextForEndingInteractiveMovementOfItemsToFinalIndexPaths: (NSArray *) indexPaths previousIndexPaths: (NSArray *) previousIndexPaths movementCancelled: (BOOL) movementCancelled ;
@end
@protocol UICollectionViewLayoutUIReorderingSupportHooksCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop