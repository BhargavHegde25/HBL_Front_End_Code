#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UICollectionViewListCell_symbols(JSContext*);
@protocol UICollectionViewListCellInstanceExports<JSExport>
@property (nonatomic) NSInteger indentationLevel;
@property (nonatomic) CGFloat indentationWidth;
@property (nonatomic) BOOL indentsAccessories;
@property (copy,nonatomic) NSArray * accessories;
@property (readonly,nonatomic) UILayoutGuide * separatorLayoutGuide;
-(UIListContentConfiguration *) defaultContentConfiguration;
@end
@protocol UICollectionViewListCellClassExports<JSExport>
@end
#pragma clang diagnostic pop