#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIColor_symbols(JSContext*);
@protocol UIColorInstanceExports<JSExport, NSSecureCodingInstanceExports_, NSCopyingInstanceExports_>
@property (readonly,nonatomic) id CGColor;
@property (readonly,nonatomic) CIColor * CIColor;
JSExportAs(initWithWhiteAlpha,
-(UIColor *) jsinitWithWhite: (CGFloat) white alpha: (CGFloat) alpha );
JSExportAs(initWithHueSaturationBrightnessAlpha,
-(UIColor *) jsinitWithHue: (CGFloat) hue saturation: (CGFloat) saturation brightness: (CGFloat) brightness alpha: (CGFloat) alpha );
JSExportAs(initWithRedGreenBlueAlpha,
-(UIColor *) jsinitWithRed: (CGFloat) red green: (CGFloat) green blue: (CGFloat) blue alpha: (CGFloat) alpha );
JSExportAs(initWithDisplayP3RedGreenBlueAlpha,
-(UIColor *) jsinitWithDisplayP3Red: (CGFloat) displayP3Red green: (CGFloat) green blue: (CGFloat) blue alpha: (CGFloat) alpha );
JSExportAs(initWithCGColor,
-(UIColor *) jsinitWithCGColor: (id) cgColor );
JSExportAs(initWithPatternImage,
-(UIColor *) jsinitWithPatternImage: (UIImage *) image );
JSExportAs(initWithCIColor,
-(UIColor *) jsinitWithCIColor: (CIColor *) ciColor );
-(void) set;
-(void) setFill;
-(void) setStroke;
-(UIColor *) colorWithAlphaComponent: (CGFloat) alpha ;
-(id) CGColor;
@end
@protocol UIColorClassExports<JSExport, NSSecureCodingClassExports_, NSCopyingClassExports_>
+(UIColor *) colorWithWhite: (CGFloat) white alpha: (CGFloat) alpha ;
+(UIColor *) colorWithHue: (CGFloat) hue saturation: (CGFloat) saturation brightness: (CGFloat) brightness alpha: (CGFloat) alpha ;
+(UIColor *) colorWithRed: (CGFloat) red green: (CGFloat) green blue: (CGFloat) blue alpha: (CGFloat) alpha ;
+(UIColor *) colorWithDisplayP3Red: (CGFloat) displayP3Red green: (CGFloat) green blue: (CGFloat) blue alpha: (CGFloat) alpha ;
+(UIColor *) colorWithCGColor: (id) cgColor ;
+(UIColor *) colorWithPatternImage: (UIImage *) image ;
+(UIColor *) colorWithCIColor: (CIColor *) ciColor ;
+(UIColor *) blackColor;
+(UIColor *) darkGrayColor;
+(UIColor *) lightGrayColor;
+(UIColor *) whiteColor;
+(UIColor *) grayColor;
+(UIColor *) redColor;
+(UIColor *) greenColor;
+(UIColor *) blueColor;
+(UIColor *) cyanColor;
+(UIColor *) yellowColor;
+(UIColor *) magentaColor;
+(UIColor *) orangeColor;
+(UIColor *) purpleColor;
+(UIColor *) brownColor;
+(UIColor *) clearColor;
@end
@protocol UIColorUINSItemProviderCategoryInstanceExports<JSExport, NSItemProviderReadingInstanceExports_, NSItemProviderWritingInstanceExports_>
@end
@protocol UIColorUINSItemProviderCategoryClassExports<JSExport, NSItemProviderReadingClassExports_, NSItemProviderWritingClassExports_>
@end
@protocol CIColorUIKitAdditionsCategoryInstanceExports<JSExport>
JSExportAs(initWithColor,
-(id) jsinitWithColor: (UIColor *) color );
@end
@protocol CIColorUIKitAdditionsCategoryClassExports<JSExport>
@end
@protocol UIColorUIColorNamedColorsCategoryInstanceExports<JSExport>
@end
@protocol UIColorUIColorNamedColorsCategoryClassExports<JSExport>
+(UIColor *) colorNamed: (NSString *) name ;
+(UIColor *) colorNamed: (NSString *) name inBundle: (NSBundle *) bundle compatibleWithTraitCollection: (UITraitCollection *) traitCollection ;
@end
@protocol UIColorDynamicColorsCategoryInstanceExports<JSExport>
JSExportAs(initWithDynamicProvider,
-(UIColor *) jsinitWithDynamicProvider: (JSValue *) dynamicProvider );
-(UIColor *) resolvedColorWithTraitCollection: (UITraitCollection *) traitCollection ;
@end
@protocol UIColorDynamicColorsCategoryClassExports<JSExport>
JSExportAs(colorWithDynamicProvider,
+(UIColor *) jscolorWithDynamicProvider: (JSValue *) dynamicProvider );
@end
#pragma clang diagnostic pop