#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIContentUnavailableButtonProperties_symbols(JSContext*);
@protocol UIContentUnavailableButtonPropertiesInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (copy,nonatomic) UIAction * primaryAction;
@property (copy,nonatomic) UIMenu * menu;
@property (getter=isEnabled,nonatomic) BOOL enabled;
@property (nonatomic) UIButtonRole role;
@end
@protocol UIContentUnavailableButtonPropertiesClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
@end
#pragma clang diagnostic pop