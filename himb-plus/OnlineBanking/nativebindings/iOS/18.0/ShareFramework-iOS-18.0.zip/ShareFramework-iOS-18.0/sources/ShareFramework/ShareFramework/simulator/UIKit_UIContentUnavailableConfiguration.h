#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIContentUnavailableConfiguration_symbols(JSContext*);
@protocol UIContentUnavailableConfigurationInstanceExports<JSExport, UIContentConfigurationInstanceExports_, NSSecureCodingInstanceExports_>
@property (nonatomic,strong) UIImage * image;
@property (readonly,nonatomic) UIContentUnavailableImageProperties * imageProperties;
@property (copy,nonatomic) NSString * text;
@property (copy,nonatomic) NSAttributedString * attributedText;
@property (readonly,nonatomic) UIContentUnavailableTextProperties * textProperties;
@property (copy,nonatomic) NSString * secondaryText;
@property (copy,nonatomic) NSAttributedString * secondaryAttributedText;
@property (readonly,nonatomic) UIContentUnavailableTextProperties * secondaryTextProperties;
@property (nonatomic,strong) UIButtonConfiguration * button;
@property (readonly,nonatomic) UIContentUnavailableButtonProperties * buttonProperties;
@property (nonatomic,strong) UIButtonConfiguration * secondaryButton;
@property (readonly,nonatomic) UIContentUnavailableButtonProperties * secondaryButtonProperties;
@property (nonatomic) UIContentUnavailableAlignment alignment;
@property (nonatomic) UIAxis axesPreservingSuperviewLayoutMargins;
@property (nonatomic) NSDirectionalEdgeInsets directionalLayoutMargins;
@property (nonatomic) CGFloat imageToTextPadding;
@property (nonatomic) CGFloat textToSecondaryTextPadding;
@property (nonatomic) CGFloat textToButtonPadding;
@property (nonatomic) CGFloat buttonToSecondaryButtonPadding;
@property (nonatomic,strong) UIBackgroundConfiguration * background;
@end
@protocol UIContentUnavailableConfigurationClassExports<JSExport, UIContentConfigurationClassExports_, NSSecureCodingClassExports_>
+(id) emptyConfiguration;
+(id) loadingConfiguration;
+(id) searchConfiguration;
@end
#pragma clang diagnostic pop