#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIContentUnavailableConfigurationState_symbols(JSContext*);
@protocol UIContentUnavailableConfigurationStateInstanceExports<JSExport, UIConfigurationStateInstanceExports_>
@property (nonatomic,strong) UITraitCollection * traitCollection;
@property (nonatomic,strong) NSString * searchText;
JSExportAs(initWithTraitCollection,
-(id) jsinitWithTraitCollection: (UITraitCollection *) traitCollection );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
@end
@protocol UIContentUnavailableConfigurationStateClassExports<JSExport, UIConfigurationStateClassExports_>
@end
#pragma clang diagnostic pop