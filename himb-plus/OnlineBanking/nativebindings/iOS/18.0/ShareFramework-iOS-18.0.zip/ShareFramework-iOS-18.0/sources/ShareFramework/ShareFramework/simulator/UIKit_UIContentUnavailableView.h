#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIContentUnavailableView_symbols(JSContext*);
@protocol UIContentUnavailableViewInstanceExports<JSExport, UIContentViewInstanceExports_>
@property (copy,nonatomic) UIContentUnavailableConfiguration * configuration;
@property (getter=isScrollEnabled,nonatomic) BOOL scrollEnabled;
JSExportAs(initWithConfiguration,
-(id) jsinitWithConfiguration: (UIContentUnavailableConfiguration *) configuration );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
@end
@protocol UIContentUnavailableViewClassExports<JSExport, UIContentViewClassExports_>
@end
#pragma clang diagnostic pop