#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIContextMenuInteraction_symbols(JSContext*);
@protocol UIContextMenuInteractionInstanceExports<JSExport, UIInteractionInstanceExports_>
@property (readonly,nonatomic,weak) id delegate;
@property (readonly,nonatomic) UIContextMenuInteractionAppearance menuAppearance;
JSExportAs(initWithDelegate,
-(id) jsinitWithDelegate: (id) delegate );
-(CGPoint) locationInView: (UIView *) view ;
JSExportAs(updateVisibleMenuWithBlock,
-(void) jsupdateVisibleMenuWithBlock: (JSValue *) block );
-(void) dismissMenu;
@end
@protocol UIContextMenuInteractionClassExports<JSExport, UIInteractionClassExports_>
@end
@protocol UIContextMenuInteractionAnimatingInstanceExports_<JSExport, NSObjectInstanceExports_>
@property (readonly,nonatomic) UIViewController * previewViewController;
JSExportAs(addAnimations,
-(void) jsaddAnimations: (JSValue *) animations );
JSExportAs(addCompletion,
-(void) jsaddCompletion: (JSValue *) completion );
@end
@protocol UIContextMenuInteractionAnimatingClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UIContextMenuInteractionCommitAnimatingInstanceExports_<JSExport, UIContextMenuInteractionAnimatingInstanceExports_>
@property (nonatomic) UIContextMenuInteractionCommitStyle preferredCommitStyle;
@end
@protocol UIContextMenuInteractionCommitAnimatingClassExports_<JSExport, UIContextMenuInteractionAnimatingClassExports_>
@end
@protocol UIContextMenuInteractionDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(UIContextMenuConfiguration *) contextMenuInteraction: (UIContextMenuInteraction *) interaction configurationForMenuAtLocation: (CGPoint) location ;
-(UITargetedPreview *) contextMenuInteraction: (UIContextMenuInteraction *) interaction configuration: (UIContextMenuConfiguration *) configuration highlightPreviewForItemWithIdentifier: (id) identifier ;
-(UITargetedPreview *) contextMenuInteraction: (UIContextMenuInteraction *) interaction configuration: (UIContextMenuConfiguration *) configuration dismissalPreviewForItemWithIdentifier: (id) identifier ;
-(void) contextMenuInteraction: (UIContextMenuInteraction *) interaction willPerformPreviewActionForMenuWithConfiguration: (UIContextMenuConfiguration *) configuration animator: (id) animator ;
-(void) contextMenuInteraction: (UIContextMenuInteraction *) interaction willDisplayMenuForConfiguration: (UIContextMenuConfiguration *) configuration animator: (id) animator ;
-(void) contextMenuInteraction: (UIContextMenuInteraction *) interaction willEndForConfiguration: (UIContextMenuConfiguration *) configuration animator: (id) animator ;
-(UITargetedPreview *) contextMenuInteraction: (UIContextMenuInteraction *) interaction previewForHighlightingMenuWithConfiguration: (UIContextMenuConfiguration *) configuration ;
-(UITargetedPreview *) contextMenuInteraction: (UIContextMenuInteraction *) interaction previewForDismissingMenuWithConfiguration: (UIContextMenuConfiguration *) configuration ;
@end
@protocol UIContextMenuInteractionDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop