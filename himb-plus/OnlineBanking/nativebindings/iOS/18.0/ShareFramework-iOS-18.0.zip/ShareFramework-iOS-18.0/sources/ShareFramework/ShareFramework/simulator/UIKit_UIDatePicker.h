#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIDatePicker_symbols(JSContext*);
@protocol UIDatePickerInstanceExports<JSExport, NSCodingInstanceExports_>
@property (nonatomic) UIDatePickerMode datePickerMode;
@property (nonatomic,strong) NSLocale * locale;
@property (copy,nonatomic) NSCalendar * calendar;
@property (nonatomic,strong) NSTimeZone * timeZone;
@property (nonatomic,strong) NSDate * date;
@property (nonatomic,strong) NSDate * minimumDate;
@property (nonatomic,strong) NSDate * maximumDate;
@property (nonatomic) NSTimeInterval countDownDuration;
@property (nonatomic) NSInteger minuteInterval;
@property (assign,readwrite,nonatomic) UIDatePickerStyle preferredDatePickerStyle;
@property (readonly,assign,nonatomic) UIDatePickerStyle datePickerStyle;
@property (nonatomic) BOOL roundsToMinuteInterval;
-(void) setDate: (NSDate *) date animated: (BOOL) animated ;
@end
@protocol UIDatePickerClassExports<JSExport, NSCodingClassExports_>
@end
#pragma clang diagnostic pop