#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIDiffableDataSource_symbols(JSContext*);
@protocol NSDiffableDataSourceSnapshotInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (readonly,nonatomic) NSInteger numberOfItems;
@property (readonly,nonatomic) NSInteger numberOfSections;
@property (readonly,nonatomic) NSArray * sectionIdentifiers;
@property (readonly,nonatomic) NSArray * itemIdentifiers;
@property (readonly,nonatomic) NSArray * reloadedSectionIdentifiers;
@property (readonly,nonatomic) NSArray * reloadedItemIdentifiers;
@property (readonly,nonatomic) NSArray * reconfiguredItemIdentifiers;
-(void) appendItemsWithIdentifiers: (NSArray *) identifiers ;
-(void) deleteItemsWithIdentifiers: (NSArray *) identifiers ;
-(void) deleteAllItems;
-(void) reloadItemsWithIdentifiers: (NSArray *) identifiers ;
-(void) reconfigureItemsWithIdentifiers: (NSArray *) identifiers ;
-(void) appendSectionsWithIdentifiers: (NSArray *) sectionIdentifiers ;
-(void) deleteSectionsWithIdentifiers: (NSArray *) sectionIdentifiers ;
-(void) reloadSectionsWithIdentifiers: (NSArray *) sectionIdentifiers ;
@end
@protocol NSDiffableDataSourceSnapshotClassExports<JSExport, NSCopyingClassExports_>
@end
@protocol NSDiffableDataSourceSectionTransactionInstanceExports<JSExport>
@property (readonly,nonatomic) NSDiffableDataSourceSectionSnapshot * initialSnapshot;
@property (readonly,nonatomic) NSDiffableDataSourceSectionSnapshot * finalSnapshot;
@property (readonly,nonatomic) NSOrderedCollectionDifference * difference;
@end
@protocol NSDiffableDataSourceSectionTransactionClassExports<JSExport>
@end
@protocol NSDiffableDataSourceTransactionInstanceExports<JSExport>
@property (readonly,nonatomic) NSDiffableDataSourceSnapshot * initialSnapshot;
@property (readonly,nonatomic) NSDiffableDataSourceSnapshot * finalSnapshot;
@property (readonly,nonatomic) NSOrderedCollectionDifference * difference;
@property (readonly,nonatomic) NSArray * sectionTransactions;
@end
@protocol NSDiffableDataSourceTransactionClassExports<JSExport>
@end
@protocol UICollectionViewDiffableDataSourceReorderingHandlersInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (getter=getJsCanReorderItemHandler,setter=setJsCanReorderItemHandler:) JSValue* jscanReorderItemHandler;
@property (getter=getJsWillReorderHandler,setter=setJsWillReorderHandler:) JSValue* jswillReorderHandler;
@property (getter=getJsDidReorderHandler,setter=setJsDidReorderHandler:) JSValue* jsdidReorderHandler;
@end
@protocol UICollectionViewDiffableDataSourceReorderingHandlersClassExports<JSExport, NSCopyingClassExports_>
@end
@protocol UICollectionViewDiffableDataSourceSectionSnapshotHandlersInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (getter=getJsShouldExpandItemHandler,setter=setJsShouldExpandItemHandler:) JSValue* jsshouldExpandItemHandler;
@property (getter=getJsWillExpandItemHandler,setter=setJsWillExpandItemHandler:) JSValue* jswillExpandItemHandler;
@property (getter=getJsShouldCollapseItemHandler,setter=setJsShouldCollapseItemHandler:) JSValue* jsshouldCollapseItemHandler;
@property (getter=getJsWillCollapseItemHandler,setter=setJsWillCollapseItemHandler:) JSValue* jswillCollapseItemHandler;
@property (getter=getJsSnapshotForExpandingParentItemHandler,setter=setJsSnapshotForExpandingParentItemHandler:) JSValue* jssnapshotForExpandingParentItemHandler;
@end
@protocol UICollectionViewDiffableDataSourceSectionSnapshotHandlersClassExports<JSExport, NSCopyingClassExports_>
@end
@protocol UICollectionViewDiffableDataSourceInstanceExports<JSExport, UICollectionViewDataSourceInstanceExports_>
@property (getter=getJsSupplementaryViewProvider,setter=setJsSupplementaryViewProvider:) JSValue* jssupplementaryViewProvider;
@property (copy,nonatomic) UICollectionViewDiffableDataSourceReorderingHandlers * reorderingHandlers;
@property (copy,nonatomic) UICollectionViewDiffableDataSourceSectionSnapshotHandlers * sectionSnapshotHandlers;
JSExportAs(initWithCollectionViewCellProvider,
-(id) jsinitWithCollectionView: (UICollectionView *) collectionView cellProvider: (JSValue *) cellProvider );
-(NSDiffableDataSourceSnapshot *) snapshot;
-(void) applySnapshot: (NSDiffableDataSourceSnapshot *) snapshot animatingDifferences: (BOOL) animatingDifferences ;
JSExportAs(applySnapshotAnimatingDifferencesCompletion,
-(void) jsapplySnapshot: (NSDiffableDataSourceSnapshot *) snapshot animatingDifferences: (BOOL) animatingDifferences completion: (JSValue *) completion );
-(void) applySnapshotUsingReloadData: (NSDiffableDataSourceSnapshot *) snapshot ;
JSExportAs(applySnapshotUsingReloadDataCompletion,
-(void) jsapplySnapshotUsingReloadData: (NSDiffableDataSourceSnapshot *) snapshot completion: (JSValue *) completion );
@end
@protocol UICollectionViewDiffableDataSourceClassExports<JSExport, UICollectionViewDataSourceClassExports_>
@end
@protocol UITableViewDiffableDataSourceInstanceExports<JSExport, UITableViewDataSourceInstanceExports_>
@property (nonatomic) UITableViewRowAnimation defaultRowAnimation;
JSExportAs(initWithTableViewCellProvider,
-(id) jsinitWithTableView: (UITableView *) tableView cellProvider: (JSValue *) cellProvider );
-(NSDiffableDataSourceSnapshot *) snapshot;
-(void) applySnapshot: (NSDiffableDataSourceSnapshot *) snapshot animatingDifferences: (BOOL) animatingDifferences ;
JSExportAs(applySnapshotAnimatingDifferencesCompletion,
-(void) jsapplySnapshot: (NSDiffableDataSourceSnapshot *) snapshot animatingDifferences: (BOOL) animatingDifferences completion: (JSValue *) completion );
-(void) applySnapshotUsingReloadData: (NSDiffableDataSourceSnapshot *) snapshot ;
JSExportAs(applySnapshotUsingReloadDataCompletion,
-(void) jsapplySnapshotUsingReloadData: (NSDiffableDataSourceSnapshot *) snapshot completion: (JSValue *) completion );
@end
@protocol UITableViewDiffableDataSourceClassExports<JSExport, UITableViewDataSourceClassExports_>
@end
#pragma clang diagnostic pop