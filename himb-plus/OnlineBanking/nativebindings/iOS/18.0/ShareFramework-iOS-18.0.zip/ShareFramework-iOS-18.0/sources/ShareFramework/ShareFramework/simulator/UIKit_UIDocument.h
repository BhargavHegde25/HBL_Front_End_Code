#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIDocument_symbols(JSContext*);
@protocol UIDocumentInstanceExports<JSExport, NSFilePresenterInstanceExports_, NSProgressReportingInstanceExports_>
@property (readonly) NSURL * fileURL;
@property (readonly,copy) NSString * localizedName;
@property (readonly,copy) NSString * fileType;
@property (copy) NSDate * fileModificationDate;
@property (readonly) UIDocumentState documentState;
@property (readonly) NSProgress * progress;
@property (strong) NSUndoManager * undoManager;
@property (readonly,nonatomic) BOOL hasUnsavedChanges;
@property (readonly,nonatomic) NSString * savingFileType;
JSExportAs(initWithFileURL,
-(id) jsinitWithFileURL: (NSURL *) url );
JSExportAs(openWithCompletionHandler,
-(void) jsopenWithCompletionHandler: (JSValue *) completionHandler );
JSExportAs(closeWithCompletionHandler,
-(void) jscloseWithCompletionHandler: (JSValue *) completionHandler );
JSExportAs(loadFromContentsOfTypeError,
-(BOOL) jsloadFromContents: (id) contents ofType: (NSString *) typeName error: (JSValue *) outError );
JSExportAs(contentsForTypeError,
-(id) jscontentsForType: (NSString *) typeName error: (JSValue *) outError );
-(void) disableEditing;
-(void) enableEditing;
-(void) updateChangeCount: (UIDocumentChangeKind) change ;
-(id) changeCountTokenForSaveOperation: (UIDocumentSaveOperation) saveOperation ;
-(void) updateChangeCountWithToken: (id) changeCountToken forSaveOperation: (UIDocumentSaveOperation) saveOperation ;
JSExportAs(saveToURLForSaveOperationCompletionHandler,
-(void) jssaveToURL: (NSURL *) url forSaveOperation: (UIDocumentSaveOperation) saveOperation completionHandler: (JSValue *) completionHandler );
JSExportAs(autosaveWithCompletionHandler,
-(void) jsautosaveWithCompletionHandler: (JSValue *) completionHandler );
-(NSString *) fileNameExtensionForType: (NSString *) typeName saveOperation: (UIDocumentSaveOperation) saveOperation ;
JSExportAs(writeContentsAndAttributesSafelyToURLForSaveOperationError,
-(BOOL) jswriteContents: (id) contents andAttributes: (NSDictionary *) additionalFileAttributes safelyToURL: (NSURL *) url forSaveOperation: (UIDocumentSaveOperation) saveOperation error: (JSValue *) outError );
JSExportAs(writeContentsToURLForSaveOperationOriginalContentsURLError,
-(BOOL) jswriteContents: (id) contents toURL: (NSURL *) url forSaveOperation: (UIDocumentSaveOperation) saveOperation originalContentsURL: (NSURL *) originalContentsURL error: (JSValue *) outError );
JSExportAs(fileAttributesToWriteToURLForSaveOperationError,
-(NSDictionary *) jsfileAttributesToWriteToURL: (NSURL *) url forSaveOperation: (UIDocumentSaveOperation) saveOperation error: (JSValue *) outError );
JSExportAs(readFromURLError,
-(BOOL) jsreadFromURL: (NSURL *) url error: (JSValue *) outError );
JSExportAs(performAsynchronousFileAccessUsingBlock,
-(void) jsperformAsynchronousFileAccessUsingBlock: (JSValue *) block );
-(void) handleError: (NSError *) error userInteractionPermitted: (BOOL) userInteractionPermitted ;
-(void) finishedHandlingError: (NSError *) error recovered: (BOOL) recovered ;
-(void) userInteractionNoLongerPermittedForError: (NSError *) error ;
JSExportAs(revertToContentsOfURLCompletionHandler,
-(void) jsrevertToContentsOfURL: (NSURL *) url completionHandler: (JSValue *) completionHandler );
@end
@protocol UIDocumentClassExports<JSExport, NSFilePresenterClassExports_, NSProgressReportingClassExports_>
@end
@protocol UIDocumentAnonCategoryInstanceExports<JSExport, UINavigationItemRenameDelegateInstanceExports_>
@end
@protocol UIDocumentAnonCategoryClassExports<JSExport, UINavigationItemRenameDelegateClassExports_>
@end
@protocol UIDocumentActivityContinuationCategoryInstanceExports<JSExport, UIUserActivityRestoringInstanceExports_>
@property (nonatomic,strong) NSUserActivity * userActivity;
-(void) updateUserActivityState: (NSUserActivity *) userActivity ;
-(void) restoreUserActivityState: (NSUserActivity *) userActivity ;
@end
@protocol UIDocumentActivityContinuationCategoryClassExports<JSExport, UIUserActivityRestoringClassExports_>
@end
#pragma clang diagnostic pop