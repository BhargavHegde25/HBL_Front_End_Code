#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIDocumentBrowserViewController_symbols(JSContext*);
@protocol UIDocumentBrowserViewControllerInstanceExports<JSExport, NSCodingInstanceExports_>
@property (nonatomic,weak) id delegate;
@property (assign,nonatomic) BOOL allowsDocumentCreation;
@property (assign,nonatomic) BOOL allowsPickingMultipleItems;
@property (readonly,copy,nonatomic) NSArray * allowedContentTypes;
@property (readonly,copy,nonatomic) NSArray * recentDocumentsContentTypes;
@property (readonly,copy,nonatomic) NSArray * contentTypesForRecentDocuments;
@property (assign,nonatomic) BOOL shouldShowFileExtensions;
@property (nonatomic,strong) NSArray * additionalLeadingNavigationBarButtonItems;
@property (nonatomic,strong) NSArray * additionalTrailingNavigationBarButtonItems;
@property (copy,nonatomic) NSArray * customActions;
@property (assign,nonatomic) UIDocumentBrowserUserInterfaceStyle browserUserInterfaceStyle;
@property (copy,nonatomic) NSString * localizedCreateDocumentActionTitle;
@property (assign,nonatomic) CGFloat defaultDocumentAspectRatio;
JSExportAs(initForOpeningFilesWithContentTypes,
-(id) jsinitForOpeningFilesWithContentTypes: (NSArray *) allowedContentTypes );
JSExportAs(initForOpeningContentTypes,
-(id) jsinitForOpeningContentTypes: (NSArray *) contentTypes );
JSExportAs(revealDocumentAtURLImportIfNeededCompletion,
-(void) jsrevealDocumentAtURL: (NSURL *) url importIfNeeded: (BOOL) importIfNeeded completion: (JSValue *) completion );
JSExportAs(importDocumentAtURLNextToDocumentAtURLModeCompletionHandler,
-(void) jsimportDocumentAtURL: (NSURL *) documentURL nextToDocumentAtURL: (NSURL *) neighbourURL mode: (UIDocumentBrowserImportMode) importMode completionHandler: (JSValue *) completion );
JSExportAs(renameDocumentAtURLProposedNameCompletionHandler,
-(void) jsrenameDocumentAtURL: (NSURL *) documentURL proposedName: (NSString *) proposedName completionHandler: (JSValue *) completionHandler );
-(UIDocumentBrowserTransitionController *) transitionControllerForDocumentAtURL: (NSURL *) documentURL ;
-(UIDocumentBrowserTransitionController *) transitionControllerForDocumentURL: (NSURL *) documentURL ;
@end
@protocol UIDocumentBrowserViewControllerClassExports<JSExport, NSCodingClassExports_>
@end
@protocol UIDocumentBrowserTransitionControllerInstanceExports<JSExport, UIViewControllerAnimatedTransitioningInstanceExports_>
@property (nonatomic,strong) NSProgress * loadingProgress;
@property (nonatomic,weak) UIView * targetView;
@end
@protocol UIDocumentBrowserTransitionControllerClassExports<JSExport, UIViewControllerAnimatedTransitioningClassExports_>
@end
@protocol UIDocumentBrowserViewControllerDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) documentBrowser: (UIDocumentBrowserViewController *) controller didPickDocumentURLs: (NSArray *) documentURLs ;
-(void) documentBrowser: (UIDocumentBrowserViewController *) controller didPickDocumentsAtURLs: (NSArray *) documentURLs ;
JSExportAs(documentBrowserDidRequestDocumentCreationWithHandler,
-(void) jsdocumentBrowser: (UIDocumentBrowserViewController *) controller didRequestDocumentCreationWithHandler: (JSValue *) importHandler );
-(void) documentBrowser: (UIDocumentBrowserViewController *) controller didImportDocumentAtURL: (NSURL *) sourceURL toDestinationURL: (NSURL *) destinationURL ;
-(void) documentBrowser: (UIDocumentBrowserViewController *) controller failedToImportDocumentAtURL: (NSURL *) documentURL error: (NSError *) error ;
-(NSArray *) documentBrowser: (UIDocumentBrowserViewController *) controller applicationActivitiesForDocumentURLs: (NSArray *) documentURLs ;
-(void) documentBrowser: (UIDocumentBrowserViewController *) controller willPresentActivityViewController: (UIActivityViewController *) activityViewController ;
@end
@protocol UIDocumentBrowserViewControllerDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop