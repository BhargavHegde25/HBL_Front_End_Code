#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIDocumentProperties_symbols(JSContext*);
@protocol UIDocumentPropertiesInstanceExports<JSExport>
@property (readwrite,copy,nonatomic) LPLinkMetadata * metadata;
@property (getter=getJsDragItemsProvider,setter=setJsDragItemsProvider:) JSValue* jsdragItemsProvider;
@property (getter=getJsActivityViewControllerProvider,setter=setJsActivityViewControllerProvider:) JSValue* jsactivityViewControllerProvider;
@property (nonatomic) BOOL wantsIconRepresentation;
JSExportAs(initWithURL,
-(id) jsinitWithURL: (NSURL *) url );
JSExportAs(initWithMetadata,
-(id) jsinitWithMetadata: (LPLinkMetadata *) metadata );
@end
@protocol UIDocumentPropertiesClassExports<JSExport>
@end
#pragma clang diagnostic pop