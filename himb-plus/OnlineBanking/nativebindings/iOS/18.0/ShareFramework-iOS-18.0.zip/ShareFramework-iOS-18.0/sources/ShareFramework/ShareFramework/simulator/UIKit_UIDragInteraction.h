#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIDragInteraction_symbols(JSContext*);
@protocol UIDragInteractionInstanceExports<JSExport, UIInteractionInstanceExports_>
@property (readonly,nonatomic,weak) id delegate;
@property (nonatomic) BOOL allowsSimultaneousRecognitionDuringLift;
@property (getter=isEnabled,nonatomic) BOOL enabled;
JSExportAs(initWithDelegate,
-(id) jsinitWithDelegate: (id) delegate );
@end
@protocol UIDragInteractionClassExports<JSExport, UIInteractionClassExports_>
+(BOOL) isEnabledByDefault;
@end
@protocol UIDragAnimatingInstanceExports_<JSExport, NSObjectInstanceExports_>
JSExportAs(addAnimations,
-(void) jsaddAnimations: (JSValue *) animations );
JSExportAs(addCompletion,
-(void) jsaddCompletion: (JSValue *) completion );
@end
@protocol UIDragAnimatingClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UIDragInteractionDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(NSArray *) dragInteraction: (UIDragInteraction *) interaction itemsForBeginningSession: (id) session ;
-(UITargetedDragPreview *) dragInteraction: (UIDragInteraction *) interaction previewForLiftingItem: (UIDragItem *) item session: (id) session ;
-(void) dragInteraction: (UIDragInteraction *) interaction willAnimateLiftWithAnimator: (id) animator session: (id) session ;
-(void) dragInteraction: (UIDragInteraction *) interaction sessionWillBegin: (id) session ;
-(BOOL) dragInteraction: (UIDragInteraction *) interaction sessionAllowsMoveOperation: (id) session ;
-(BOOL) dragInteraction: (UIDragInteraction *) interaction sessionIsRestrictedToDraggingApplication: (id) session ;
-(BOOL) dragInteraction: (UIDragInteraction *) interaction prefersFullSizePreviewsForSession: (id) session ;
-(void) dragInteraction: (UIDragInteraction *) interaction sessionDidMove: (id) session ;
-(void) dragInteraction: (UIDragInteraction *) interaction session: (id) session willEndWithOperation: (UIDropOperation) operation ;
-(void) dragInteraction: (UIDragInteraction *) interaction session: (id) session didEndWithOperation: (UIDropOperation) operation ;
-(void) dragInteraction: (UIDragInteraction *) interaction sessionDidTransferItems: (id) session ;
-(NSArray *) dragInteraction: (UIDragInteraction *) interaction itemsForAddingToSession: (id) session withTouchAtPoint: (CGPoint) point ;
-(id) dragInteraction: (UIDragInteraction *) interaction sessionForAddingItems: (NSArray *) sessions withTouchAtPoint: (CGPoint) point ;
-(void) dragInteraction: (UIDragInteraction *) interaction session: (id) session willAddItems: (NSArray *) items forInteraction: (UIDragInteraction *) addingInteraction ;
-(UITargetedDragPreview *) dragInteraction: (UIDragInteraction *) interaction previewForCancellingItem: (UIDragItem *) item withDefault: (UITargetedDragPreview *) defaultPreview ;
-(void) dragInteraction: (UIDragInteraction *) interaction item: (UIDragItem *) item willAnimateCancelWithAnimator: (id) animator ;
@end
@protocol UIDragInteractionDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop