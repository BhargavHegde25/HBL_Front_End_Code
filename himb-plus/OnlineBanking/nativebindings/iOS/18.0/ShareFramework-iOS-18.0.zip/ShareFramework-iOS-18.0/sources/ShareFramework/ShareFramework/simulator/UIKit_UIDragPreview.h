#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIDragPreview_symbols(JSContext*);
@protocol UIDragPreviewInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (readonly,nonatomic) UIView * view;
@property (readonly,copy,nonatomic) UIDragPreviewParameters * parameters;
JSExportAs(initWithViewParameters,
-(id) jsinitWithView: (UIView *) view parameters: (UIDragPreviewParameters *) parameters );
JSExportAs(initWithView,
-(id) jsinitWithView: (UIView *) view );
@end
@protocol UIDragPreviewClassExports<JSExport, NSCopyingClassExports_>
@end
#pragma clang diagnostic pop