#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIDynamicAnimator_symbols(JSContext*);
@protocol UIDynamicAnimatorInstanceExports<JSExport>
@property (readonly,nonatomic) UIView * referenceView;
@property (readonly,copy,nonatomic) NSArray * behaviors;
@property (getter=isRunning,readonly,nonatomic) BOOL running;
@property (readonly,nonatomic) NSTimeInterval elapsedTime;
@property (nonatomic,weak) id delegate;
JSExportAs(initWithReferenceView,
-(id) jsinitWithReferenceView: (UIView *) view );
-(void) addBehavior: (UIDynamicBehavior *) behavior ;
-(void) removeBehavior: (UIDynamicBehavior *) behavior ;
-(void) removeAllBehaviors;
-(NSArray *) itemsInRect: (CGRect) rect ;
-(void) updateItemUsingCurrentState: (id) item ;
@end
@protocol UIDynamicAnimatorClassExports<JSExport>
@end
@protocol UIDynamicAnimatorUICollectionViewAdditionsCategoryInstanceExports<JSExport>
JSExportAs(initWithCollectionViewLayout,
-(id) jsinitWithCollectionViewLayout: (UICollectionViewLayout *) layout );
-(UICollectionViewLayoutAttributes *) layoutAttributesForCellAtIndexPath: (NSIndexPath *) indexPath ;
-(UICollectionViewLayoutAttributes *) layoutAttributesForSupplementaryViewOfKind: (NSString *) kind atIndexPath: (NSIndexPath *) indexPath ;
-(UICollectionViewLayoutAttributes *) layoutAttributesForDecorationViewOfKind: (NSString *) decorationViewKind atIndexPath: (NSIndexPath *) indexPath ;
@end
@protocol UIDynamicAnimatorUICollectionViewAdditionsCategoryClassExports<JSExport>
@end
@protocol UIDynamicAnimatorDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) dynamicAnimatorWillResume: (UIDynamicAnimator *) animator ;
-(void) dynamicAnimatorDidPause: (UIDynamicAnimator *) animator ;
@end
@protocol UIDynamicAnimatorDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop