#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIFieldBehavior_symbols(JSContext*);
@protocol UIFieldBehaviorInstanceExports<JSExport>
@property (readonly,copy,nonatomic) NSArray * items;
@property (assign,nonatomic) CGPoint position;
@property (nonatomic,strong) UIRegion * region;
@property (assign,nonatomic) CGFloat strength;
@property (assign,nonatomic) CGFloat falloff;
@property (assign,nonatomic) CGFloat minimumRadius;
@property (assign,nonatomic) CGVector direction;
@property (assign,nonatomic) CGFloat smoothness;
@property (assign,nonatomic) CGFloat animationSpeed;
-(void) addItem: (id) item ;
-(void) removeItem: (id) item ;
@end
@protocol UIFieldBehaviorClassExports<JSExport>
+(id) dragField;
+(id) vortexField;
+(id) radialGravityFieldWithPosition: (CGPoint) position ;
+(id) linearGravityFieldWithVector: (CGVector) direction ;
+(id) velocityFieldWithVector: (CGVector) direction ;
+(id) noiseFieldWithSmoothness: (CGFloat) smoothness animationSpeed: (CGFloat) speed ;
+(id) turbulenceFieldWithSmoothness: (CGFloat) smoothness animationSpeed: (CGFloat) speed ;
+(id) springField;
+(id) electricField;
+(id) magneticField;
JSExportAs(fieldWithEvaluationBlock,
+(id) jsfieldWithEvaluationBlock: (JSValue *) block );
@end
#pragma clang diagnostic pop