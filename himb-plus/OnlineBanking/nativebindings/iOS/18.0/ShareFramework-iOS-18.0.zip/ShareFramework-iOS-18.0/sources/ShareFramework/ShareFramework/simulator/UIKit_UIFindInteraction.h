#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIFindInteraction_symbols(JSContext*);
@protocol UIFindInteractionInstanceExports<JSExport, UIInteractionInstanceExports_>
@property (getter=isFindNavigatorVisible,readonly,nonatomic) BOOL findNavigatorVisible;
@property (readonly,nonatomic) UIFindSession * activeFindSession;
@property (copy,nonatomic) NSString * searchText;
@property (copy,nonatomic) NSString * replacementText;
@property (getter=getJsOptionsMenuProvider,setter=setJsOptionsMenuProvider:) JSValue* jsoptionsMenuProvider;
@property (readonly,nonatomic,weak) id delegate;
JSExportAs(initWithSessionDelegate,
-(id) jsinitWithSessionDelegate: (id) sessionDelegate );
-(void) presentFindNavigatorShowingReplace: (BOOL) showingReplace ;
-(void) dismissFindNavigator;
-(void) findNext;
-(void) findPrevious;
-(void) updateResultCount;
@end
@protocol UIFindInteractionClassExports<JSExport, UIInteractionClassExports_>
@end
@protocol UIFindInteractionDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(UIFindSession *) findInteraction: (UIFindInteraction *) interaction sessionForView: (UIView *) view ;
-(void) findInteraction: (UIFindInteraction *) interaction didBeginFindSession: (UIFindSession *) session ;
-(void) findInteraction: (UIFindInteraction *) interaction didEndFindSession: (UIFindSession *) session ;
@end
@protocol UIFindInteractionDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop