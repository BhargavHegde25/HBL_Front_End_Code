#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIFontDescriptor_symbols(JSContext*);
@protocol UIFontDescriptorInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,nonatomic) NSString * postscriptName;
@property (readonly,nonatomic) CGFloat pointSize;
@property (readonly,nonatomic) CGAffineTransform matrix;
@property (readonly,nonatomic) UIFontDescriptorSymbolicTraits symbolicTraits;
@property (readonly,nonatomic) NSDictionary * fontAttributes;
-(id) jsinit;
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
-(id) objectForKey: (UIFontDescriptorAttributeName) anAttribute ;
-(NSArray *) matchingFontDescriptorsWithMandatoryKeys: (NSSet *) mandatoryKeys ;
JSExportAs(initWithFontAttributes,
-(id) jsinitWithFontAttributes: (NSDictionary *) attributes );
-(UIFontDescriptor *) fontDescriptorByAddingAttributes: (NSDictionary *) attributes ;
-(UIFontDescriptor *) fontDescriptorWithSize: (CGFloat) newPointSize ;
-(UIFontDescriptor *) fontDescriptorWithMatrix: (CGAffineTransform) matrix ;
-(UIFontDescriptor *) fontDescriptorWithFace: (NSString *) newFace ;
-(UIFontDescriptor *) fontDescriptorWithFamily: (NSString *) newFamily ;
-(UIFontDescriptor *) fontDescriptorWithSymbolicTraits: (UIFontDescriptorSymbolicTraits) symbolicTraits ;
-(UIFontDescriptor *) fontDescriptorWithDesign: (UIFontDescriptorSystemDesign) design ;
@end
@protocol UIFontDescriptorClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
+(UIFontDescriptor *) fontDescriptorWithFontAttributes: (NSDictionary *) attributes ;
+(UIFontDescriptor *) fontDescriptorWithName: (NSString *) fontName size: (CGFloat) size ;
+(UIFontDescriptor *) fontDescriptorWithName: (NSString *) fontName matrix: (CGAffineTransform) matrix ;
+(UIFontDescriptor *) preferredFontDescriptorWithTextStyle: (UIFontTextStyle) style ;
+(UIFontDescriptor *) preferredFontDescriptorWithTextStyle: (UIFontTextStyle) style compatibleWithTraitCollection: (UITraitCollection *) traitCollection ;
@end
#pragma clang diagnostic pop