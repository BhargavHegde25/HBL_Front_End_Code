#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIGeometry_symbols(JSContext*);
@interface JSValue (UIKit_UIGeometry)
+(JSValue*) valueWithUIEdgeInsets: (UIEdgeInsets) s inContext: (JSContext*) context;
-(UIEdgeInsets) toUIEdgeInsets;
+(JSValue*) valueWithNSDirectionalEdgeInsets: (NSDirectionalEdgeInsets) s inContext: (JSContext*) context;
-(NSDirectionalEdgeInsets) toNSDirectionalEdgeInsets;
+(JSValue*) valueWithUIOffset: (UIOffset) s inContext: (JSContext*) context;
-(UIOffset) toUIOffset;
@end
@protocol NSValueNSValueUIGeometryExtensionsCategoryInstanceExports<JSExport>
@property (readonly,nonatomic) CGPoint CGPointValue;
@property (readonly,nonatomic) CGVector CGVectorValue;
@property (readonly,nonatomic) CGSize CGSizeValue;
@property (readonly,nonatomic) CGRect CGRectValue;
@property (readonly,nonatomic) CGAffineTransform CGAffineTransformValue;
@property (readonly,nonatomic) UIEdgeInsets UIEdgeInsetsValue;
@property (readonly,nonatomic) NSDirectionalEdgeInsets directionalEdgeInsetsValue;
@property (readonly,nonatomic) UIOffset UIOffsetValue;
@end
@protocol NSValueNSValueUIGeometryExtensionsCategoryClassExports<JSExport>
+(NSValue *) valueWithCGPoint: (CGPoint) point ;
+(NSValue *) valueWithCGVector: (CGVector) vector ;
+(NSValue *) valueWithCGSize: (CGSize) size ;
+(NSValue *) valueWithCGRect: (CGRect) rect ;
+(NSValue *) valueWithCGAffineTransform: (CGAffineTransform) transform ;
+(NSValue *) valueWithUIEdgeInsets: (UIEdgeInsets) insets ;
+(NSValue *) valueWithDirectionalEdgeInsets: (NSDirectionalEdgeInsets) insets ;
+(NSValue *) valueWithUIOffset: (UIOffset) insets ;
@end
@protocol NSCoderUIGeometryKeyedCodingCategoryInstanceExports<JSExport>
-(void) encodeCGPoint: (CGPoint) point forKey: (NSString *) key ;
-(void) encodeCGVector: (CGVector) vector forKey: (NSString *) key ;
-(void) encodeCGSize: (CGSize) size forKey: (NSString *) key ;
-(void) encodeCGRect: (CGRect) rect forKey: (NSString *) key ;
-(void) encodeCGAffineTransform: (CGAffineTransform) transform forKey: (NSString *) key ;
-(void) encodeUIEdgeInsets: (UIEdgeInsets) insets forKey: (NSString *) key ;
-(void) encodeDirectionalEdgeInsets: (NSDirectionalEdgeInsets) insets forKey: (NSString *) key ;
-(void) encodeUIOffset: (UIOffset) offset forKey: (NSString *) key ;
-(CGPoint) decodeCGPointForKey: (NSString *) key ;
-(CGVector) decodeCGVectorForKey: (NSString *) key ;
-(CGSize) decodeCGSizeForKey: (NSString *) key ;
-(CGRect) decodeCGRectForKey: (NSString *) key ;
-(CGAffineTransform) decodeCGAffineTransformForKey: (NSString *) key ;
-(UIEdgeInsets) decodeUIEdgeInsetsForKey: (NSString *) key ;
-(NSDirectionalEdgeInsets) decodeDirectionalEdgeInsetsForKey: (NSString *) key ;
-(UIOffset) decodeUIOffsetForKey: (NSString *) key ;
@end
@protocol NSCoderUIGeometryKeyedCodingCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop