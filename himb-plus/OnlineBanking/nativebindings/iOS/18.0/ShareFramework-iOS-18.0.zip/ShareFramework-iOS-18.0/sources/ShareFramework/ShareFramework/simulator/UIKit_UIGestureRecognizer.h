#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIGestureRecognizer_symbols(JSContext*);
@protocol UIGestureRecognizerInstanceExports<JSExport>
@property (readonly,nonatomic) UIGestureRecognizerState state;
@property (nonatomic,weak) id delegate;
@property (getter=isEnabled,nonatomic) BOOL enabled;
@property (readonly,nonatomic) UIView * view;
@property (nonatomic) BOOL cancelsTouchesInView;
@property (nonatomic) BOOL delaysTouchesBegan;
@property (nonatomic) BOOL delaysTouchesEnded;
@property (copy,nonatomic) NSArray * allowedTouchTypes;
@property (copy,nonatomic) NSArray * allowedPressTypes;
@property (nonatomic) BOOL requiresExclusiveTouchType;
@property (readonly,nonatomic) NSUInteger numberOfTouches;
@property (copy,nonatomic) NSString * name;
@property (readonly,nonatomic) UIKeyModifierFlags modifierFlags;
@property (readonly,nonatomic) UIEventButtonMask buttonMask;
JSExportAs(initWithTargetAction,
-(id) jsinitWithTarget: (id) target action: (NSString *) action );
-(id) jsinit;
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
JSExportAs(addTargetAction,
-(void) jsaddTarget: (id) target action: (NSString *) action );
JSExportAs(removeTargetAction,
-(void) jsremoveTarget: (id) target action: (NSString *) action );
-(void) requireGestureRecognizerToFail: (UIGestureRecognizer *) otherGestureRecognizer ;
-(CGPoint) locationInView: (UIView *) view ;
-(CGPoint) locationOfTouch: (NSUInteger) touchIndex inView: (UIView *) view ;
@end
@protocol UIGestureRecognizerClassExports<JSExport>
@end
@protocol UIGestureRecognizerDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(BOOL) gestureRecognizerShouldBegin: (UIGestureRecognizer *) gestureRecognizer ;
-(BOOL) gestureRecognizer: (UIGestureRecognizer *) gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer: (UIGestureRecognizer *) otherGestureRecognizer ;
-(BOOL) gestureRecognizer: (UIGestureRecognizer *) gestureRecognizer shouldRequireFailureOfGestureRecognizer: (UIGestureRecognizer *) otherGestureRecognizer ;
-(BOOL) gestureRecognizer: (UIGestureRecognizer *) gestureRecognizer shouldBeRequiredToFailByGestureRecognizer: (UIGestureRecognizer *) otherGestureRecognizer ;
-(BOOL) gestureRecognizer: (UIGestureRecognizer *) gestureRecognizer shouldReceiveTouch: (UITouch *) touch ;
-(BOOL) gestureRecognizer: (UIGestureRecognizer *) gestureRecognizer shouldReceivePress: (UIPress *) press ;
-(BOOL) gestureRecognizer: (UIGestureRecognizer *) gestureRecognizer shouldReceiveEvent: (UIEvent *) event ;
@end
@protocol UIGestureRecognizerDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop