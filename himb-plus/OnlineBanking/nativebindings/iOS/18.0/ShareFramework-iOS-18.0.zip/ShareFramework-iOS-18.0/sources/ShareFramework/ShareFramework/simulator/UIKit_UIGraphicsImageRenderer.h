#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIGraphicsImageRenderer_symbols(JSContext*);
@protocol UIGraphicsImageRendererFormatInstanceExports<JSExport>
@property (nonatomic) CGFloat scale;
@property (nonatomic) BOOL opaque;
@property (nonatomic) BOOL prefersExtendedRange;
@property (readonly,assign,nonatomic) BOOL supportsHighDynamicRange;
@property (nonatomic) UIGraphicsImageRendererFormatRange preferredRange;
@end
@protocol UIGraphicsImageRendererFormatClassExports<JSExport>
+(id) formatForTraitCollection: (UITraitCollection *) traitCollection ;
@end
@protocol UIGraphicsImageRendererContextInstanceExports<JSExport>
@property (readonly,nonatomic) UIImage * currentImage;
@end
@protocol UIGraphicsImageRendererContextClassExports<JSExport>
@end
@protocol UIGraphicsImageRendererInstanceExports<JSExport>
JSExportAs(initWithSize,
-(id) jsinitWithSize: (CGSize) size );
JSExportAs(initWithSizeFormat,
-(id) jsinitWithSize: (CGSize) size format: (UIGraphicsImageRendererFormat *) format );
JSExportAs(initWithBoundsFormat,
-(id) jsinitWithBounds: (CGRect) bounds format: (UIGraphicsImageRendererFormat *) format );
JSExportAs(imageWithActions,
-(UIImage *) jsimageWithActions: (JSValue *) actions );
JSExportAs(PNGDataWithActions,
-(NSData *) jsPNGDataWithActions: (JSValue *) actions );
JSExportAs(JPEGDataWithCompressionQualityActions,
-(NSData *) jsJPEGDataWithCompressionQuality: (CGFloat) compressionQuality actions: (JSValue *) actions );
@end
@protocol UIGraphicsImageRendererClassExports<JSExport>
@end
#pragma clang diagnostic pop