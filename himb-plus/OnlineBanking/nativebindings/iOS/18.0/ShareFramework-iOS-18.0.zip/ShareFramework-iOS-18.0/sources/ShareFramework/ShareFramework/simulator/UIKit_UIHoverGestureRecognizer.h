#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIHoverGestureRecognizer_symbols(JSContext*);
@protocol UIHoverGestureRecognizerInstanceExports<JSExport>
@property (readonly,nonatomic) CGFloat zOffset;
@property (readonly,nonatomic) CGFloat altitudeAngle;
-(CGFloat) azimuthAngleInView: (UIView *) view ;
-(CGVector) azimuthUnitVectorInView: (UIView *) view ;
@end
@protocol UIHoverGestureRecognizerClassExports<JSExport>
@end
#pragma clang diagnostic pop