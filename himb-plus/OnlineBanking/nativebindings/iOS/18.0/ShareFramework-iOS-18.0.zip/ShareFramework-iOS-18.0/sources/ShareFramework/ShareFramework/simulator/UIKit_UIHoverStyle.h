#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIHoverStyle_symbols(JSContext*);
@protocol UIHoverStyleInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (nonatomic,strong) id effect;
@property (nonatomic,strong) UIShape * shape;
@property (getter=isEnabled,nonatomic) BOOL enabled;
@end
@protocol UIHoverStyleClassExports<JSExport, NSCopyingClassExports_>
+(id) styleWithEffect: (id) effect shape: (UIShape *) shape ;
+(id) styleWithShape: (UIShape *) shape ;
+(id) automaticStyle;
@end
@protocol UIViewUIHoverStyleCategoryInstanceExports<JSExport>
@property (copy,nonatomic) UIHoverStyle * hoverStyle;
@end
@protocol UIViewUIHoverStyleCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop