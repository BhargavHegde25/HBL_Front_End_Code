#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIImage_symbols(JSContext*);
@protocol UIImageInstanceExports<JSExport, NSSecureCodingInstanceExports_>
@property (readonly,nonatomic) CGSize size;
@property (readonly,nonatomic) id CGImage;
@property (readonly,nonatomic) CIImage * CIImage;
@property (readonly,nonatomic) UIImageOrientation imageOrientation;
@property (readonly,nonatomic) CGFloat scale;
@property (getter=isSymbolImage,readonly,nonatomic) BOOL symbolImage;
@property (readonly,nonatomic) NSArray * images;
@property (readonly,nonatomic) NSTimeInterval duration;
@property (readonly,nonatomic) UIEdgeInsets capInsets;
@property (readonly,nonatomic) UIImageResizingMode resizingMode;
@property (readonly,nonatomic) UIEdgeInsets alignmentRectInsets;
@property (readonly,nonatomic) UIImageRenderingMode renderingMode;
@property (readonly,nonatomic) UIGraphicsImageRendererFormat * imageRendererFormat;
@property (readonly,copy,nonatomic) UITraitCollection * traitCollection;
@property (readonly,nonatomic) UIImageAsset * imageAsset;
@property (readonly,nonatomic) BOOL flipsForRightToLeftLayoutDirection;
@property (readonly,nonatomic) CGFloat baselineOffsetFromBottom;
@property (readonly,nonatomic) BOOL hasBaseline;
@property (readonly,copy,nonatomic) __kindof UIImageConfiguration * configuration;
@property (readonly,copy,nonatomic) UIImageSymbolConfiguration * symbolConfiguration;
@property (readonly,assign,nonatomic) BOOL isHighDynamicRange;
JSExportAs(initWithContentsOfFile,
-(id) jsinitWithContentsOfFile: (NSString *) path );
JSExportAs(initWithData,
-(id) jsinitWithData: (NSData *) data );
JSExportAs(initWithDataScale,
-(id) jsinitWithData: (NSData *) data scale: (CGFloat) scale );
JSExportAs(initWithCGImage,
-(id) jsinitWithCGImage: (id) cgImage );
JSExportAs(initWithCGImageScaleOrientation,
-(id) jsinitWithCGImage: (id) cgImage scale: (CGFloat) scale orientation: (UIImageOrientation) orientation );
JSExportAs(initWithCIImage,
-(id) jsinitWithCIImage: (CIImage *) ciImage );
JSExportAs(initWithCIImageScaleOrientation,
-(id) jsinitWithCIImage: (CIImage *) ciImage scale: (CGFloat) scale orientation: (UIImageOrientation) orientation );
-(id) CGImage;
-(void) drawAtPoint: (CGPoint) point ;
-(void) drawAtPoint: (CGPoint) point blendMode: (CGBlendMode) blendMode alpha: (CGFloat) alpha ;
-(void) drawInRect: (CGRect) rect ;
-(void) drawInRect: (CGRect) rect blendMode: (CGBlendMode) blendMode alpha: (CGFloat) alpha ;
-(void) drawAsPatternInRect: (CGRect) rect ;
-(UIImage *) resizableImageWithCapInsets: (UIEdgeInsets) capInsets ;
-(UIImage *) resizableImageWithCapInsets: (UIEdgeInsets) capInsets resizingMode: (UIImageResizingMode) resizingMode ;
-(UIImage *) imageWithAlignmentRectInsets: (UIEdgeInsets) alignmentInsets ;
-(UIImage *) imageWithRenderingMode: (UIImageRenderingMode) renderingMode ;
-(UIImage *) imageFlippedForRightToLeftLayoutDirection;
-(UIImage *) imageWithHorizontallyFlippedOrientation;
-(UIImage *) imageWithBaselineOffsetFromBottom: (CGFloat) baselineOffset ;
-(UIImage *) imageWithoutBaseline;
-(UIImage *) imageWithConfiguration: (UIImageConfiguration *) configuration ;
-(UIImage *) imageByApplyingSymbolConfiguration: (UIImageSymbolConfiguration *) configuration ;
-(UIImage *) imageWithTintColor: (UIColor *) color ;
-(UIImage *) imageWithTintColor: (UIColor *) color renderingMode: (UIImageRenderingMode) renderingMode ;
-(UIImage *) imageByPreparingForDisplay;
JSExportAs(prepareForDisplayWithCompletionHandler,
-(void) jsprepareForDisplayWithCompletionHandler: (JSValue *) completionHandler );
-(UIImage *) imageByPreparingThumbnailOfSize: (CGSize) size ;
JSExportAs(prepareThumbnailOfSizeCompletionHandler,
-(void) jsprepareThumbnailOfSize: (CGSize) size completionHandler: (JSValue *) completionHandler );
-(UIImage *) imageRestrictedToStandardDynamicRange;
@end
@protocol UIImageClassExports<JSExport, NSSecureCodingClassExports_>
+(UIImage *) systemImageNamed: (NSString *) name ;
+(UIImage *) systemImageNamed: (NSString *) name withConfiguration: (UIImageConfiguration *) configuration ;
+(UIImage *) systemImageNamed: (NSString *) name compatibleWithTraitCollection: (UITraitCollection *) traitCollection ;
+(UIImage *) systemImageNamed: (NSString *) name variableValue: (double) value withConfiguration: (UIImageConfiguration *) configuration ;
+(UIImage *) imageNamed: (NSString *) name ;
+(UIImage *) imageNamed: (NSString *) name inBundle: (NSBundle *) bundle withConfiguration: (UIImageConfiguration *) configuration ;
+(UIImage *) imageNamed: (NSString *) name inBundle: (NSBundle *) bundle compatibleWithTraitCollection: (UITraitCollection *) traitCollection ;
+(UIImage *) imageNamed: (NSString *) name inBundle: (NSBundle *) bundle variableValue: (double) value withConfiguration: (UIImageConfiguration *) configuration ;
+(UIImage *) imageWithContentsOfFile: (NSString *) path ;
+(UIImage *) imageWithData: (NSData *) data ;
+(UIImage *) imageWithData: (NSData *) data scale: (CGFloat) scale ;
+(UIImage *) imageWithCGImage: (id) cgImage ;
+(UIImage *) imageWithCGImage: (id) cgImage scale: (CGFloat) scale orientation: (UIImageOrientation) orientation ;
+(UIImage *) imageWithCIImage: (CIImage *) ciImage ;
+(UIImage *) imageWithCIImage: (CIImage *) ciImage scale: (CGFloat) scale orientation: (UIImageOrientation) orientation ;
+(UIImage *) animatedImageNamed: (NSString *) name duration: (NSTimeInterval) duration ;
+(UIImage *) animatedResizableImageNamed: (NSString *) name capInsets: (UIEdgeInsets) capInsets duration: (NSTimeInterval) duration ;
+(UIImage *) animatedResizableImageNamed: (NSString *) name capInsets: (UIEdgeInsets) capInsets resizingMode: (UIImageResizingMode) resizingMode duration: (NSTimeInterval) duration ;
+(UIImage *) animatedImageWithImages: (NSArray *) images duration: (NSTimeInterval) duration ;
@end
@protocol UIImagePreconfiguredSystemImagesCategoryInstanceExports<JSExport>
@end
@protocol UIImagePreconfiguredSystemImagesCategoryClassExports<JSExport>
+(UIImage *) actionsImage;
+(UIImage *) addImage;
+(UIImage *) removeImage;
+(UIImage *) checkmarkImage;
+(UIImage *) strokedCheckmarkImage;
@end
@protocol UIImageNSItemProviderCategoryInstanceExports<JSExport, NSItemProviderReadingInstanceExports_, NSItemProviderWritingInstanceExports_, UIItemProviderPresentationSizeProvidingInstanceExports_>
@end
@protocol UIImageNSItemProviderCategoryClassExports<JSExport, NSItemProviderReadingClassExports_, NSItemProviderWritingClassExports_, UIItemProviderPresentationSizeProvidingClassExports_>
@end
@protocol NSTextAttachmentUIImageCategoryInstanceExports<JSExport>
@end
@protocol NSTextAttachmentUIImageCategoryClassExports<JSExport>
+(NSTextAttachment *) textAttachmentWithImage: (UIImage *) image ;
@end
@protocol UIImageUIImageDeprecatedCategoryInstanceExports<JSExport>
@property (readonly,nonatomic) NSInteger leftCapWidth;
@property (readonly,nonatomic) NSInteger topCapHeight;
-(UIImage *) stretchableImageWithLeftCapWidth: (NSInteger) leftCapWidth topCapHeight: (NSInteger) topCapHeight ;
@end
@protocol UIImageUIImageDeprecatedCategoryClassExports<JSExport>
@end
@protocol CIImageUIKitAdditionsCategoryInstanceExports<JSExport>
JSExportAs(initWithImage,
-(id) jsinitWithImage: (UIImage *) image );
JSExportAs(initWithImageOptions,
-(id) jsinitWithImage: (UIImage *) image options: (NSDictionary *) options );
@end
@protocol CIImageUIKitAdditionsCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop