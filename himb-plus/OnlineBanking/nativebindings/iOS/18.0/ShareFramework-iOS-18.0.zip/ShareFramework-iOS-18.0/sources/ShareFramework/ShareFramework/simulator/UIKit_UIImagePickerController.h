#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIImagePickerController_symbols(JSContext*);
@protocol UIImagePickerControllerInstanceExports<JSExport, NSCodingInstanceExports_>
@property (nonatomic,weak) id delegate;
@property (nonatomic) UIImagePickerControllerSourceType sourceType;
@property (copy,nonatomic) NSArray * mediaTypes;
@property (nonatomic) BOOL allowsEditing;
@property (nonatomic) BOOL allowsImageEditing;
@property (nonatomic) UIImagePickerControllerImageURLExportPreset imageExportPreset;
@property (nonatomic) NSTimeInterval videoMaximumDuration;
@property (nonatomic) UIImagePickerControllerQualityType videoQuality;
@property (copy,nonatomic) NSString * videoExportPreset;
@property (nonatomic) BOOL showsCameraControls;
@property (nonatomic,strong) __kindof UIView * cameraOverlayView;
@property (nonatomic) CGAffineTransform cameraViewTransform;
@property (nonatomic) UIImagePickerControllerCameraCaptureMode cameraCaptureMode;
@property (nonatomic) UIImagePickerControllerCameraDevice cameraDevice;
@property (nonatomic) UIImagePickerControllerCameraFlashMode cameraFlashMode;
-(void) takePicture;
-(BOOL) startVideoCapture;
-(void) stopVideoCapture;
@end
@protocol UIImagePickerControllerClassExports<JSExport, NSCodingClassExports_>
+(BOOL) isSourceTypeAvailable: (UIImagePickerControllerSourceType) sourceType ;
+(NSArray *) availableMediaTypesForSourceType: (UIImagePickerControllerSourceType) sourceType ;
+(BOOL) isCameraDeviceAvailable: (UIImagePickerControllerCameraDevice) cameraDevice ;
+(BOOL) isFlashAvailableForCameraDevice: (UIImagePickerControllerCameraDevice) cameraDevice ;
+(NSArray *) availableCaptureModesForCameraDevice: (UIImagePickerControllerCameraDevice) cameraDevice ;
@end
@protocol UIImagePickerControllerDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) imagePickerController: (UIImagePickerController *) picker didFinishPickingImage: (UIImage *) image editingInfo: (NSDictionary *) editingInfo ;
-(void) imagePickerController: (UIImagePickerController *) picker didFinishPickingMediaWithInfo: (NSDictionary *) info ;
-(void) imagePickerControllerDidCancel: (UIImagePickerController *) picker ;
@end
@protocol UIImagePickerControllerDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop