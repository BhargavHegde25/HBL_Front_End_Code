#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIImageView_symbols(JSContext*);
@protocol UIImageViewInstanceExports<JSExport>
@property (nonatomic,strong) UIImage * image;
@property (nonatomic,strong) UIImage * highlightedImage;
@property (nonatomic,strong) UIImageSymbolConfiguration * preferredSymbolConfiguration;
@property (getter=isUserInteractionEnabled,nonatomic) BOOL userInteractionEnabled;
@property (getter=isHighlighted,nonatomic) BOOL highlighted;
@property (copy,nonatomic) NSArray * animationImages;
@property (copy,nonatomic) NSArray * highlightedAnimationImages;
@property (nonatomic) NSTimeInterval animationDuration;
@property (nonatomic) NSInteger animationRepeatCount;
@property (nonatomic,strong) UIColor * tintColor;
@property (getter=isAnimating,readonly,nonatomic) BOOL animating;
@property (assign,readwrite,nonatomic) UIImageDynamicRange preferredImageDynamicRange;
@property (readonly,assign,nonatomic) UIImageDynamicRange imageDynamicRange;
JSExportAs(initWithImage,
-(id) jsinitWithImage: (UIImage *) image );
JSExportAs(initWithImageHighlightedImage,
-(id) jsinitWithImage: (UIImage *) image highlightedImage: (UIImage *) highlightedImage );
-(void) startAnimating;
-(void) stopAnimating;
@end
@protocol UIImageViewClassExports<JSExport>
@end
@protocol UIImageViewAnonCategoryInstanceExports<JSExport>
-(void) addSymbolEffect: (NSSymbolEffect *) symbolEffect ;
-(void) addSymbolEffect: (NSSymbolEffect *) symbolEffect options: (NSSymbolEffectOptions *) options ;
-(void) addSymbolEffect: (NSSymbolEffect *) symbolEffect options: (NSSymbolEffectOptions *) options animated: (BOOL) animated ;
JSExportAs(addSymbolEffectOptionsAnimatedCompletion,
-(void) jsaddSymbolEffect: (NSSymbolEffect *) symbolEffect options: (NSSymbolEffectOptions *) options animated: (BOOL) animated completion: (JSValue *) completionHandler );
-(void) removeSymbolEffectOfType: (NSSymbolEffect *) symbolEffect ;
-(void) removeSymbolEffectOfType: (NSSymbolEffect *) symbolEffect options: (NSSymbolEffectOptions *) options ;
-(void) removeSymbolEffectOfType: (NSSymbolEffect *) symbolEffect options: (NSSymbolEffectOptions *) options animated: (BOOL) animated ;
JSExportAs(removeSymbolEffectOfTypeOptionsAnimatedCompletion,
-(void) jsremoveSymbolEffectOfType: (NSSymbolEffect *) symbolEffect options: (NSSymbolEffectOptions *) options animated: (BOOL) animated completion: (JSValue *) completionHandler );
-(void) removeAllSymbolEffects;
-(void) removeAllSymbolEffectsWithOptions: (NSSymbolEffectOptions *) options ;
-(void) removeAllSymbolEffectsWithOptions: (NSSymbolEffectOptions *) options animated: (BOOL) animated ;
-(void) setSymbolImage: (UIImage *) symbolImage withContentTransition: (NSSymbolContentTransition *) transition ;
-(void) setSymbolImage: (UIImage *) symbolImage withContentTransition: (NSSymbolContentTransition *) transition options: (NSSymbolEffectOptions *) options ;
JSExportAs(setSymbolImageWithContentTransitionOptionsCompletion,
-(void) jssetSymbolImage: (UIImage *) symbolImage withContentTransition: (NSSymbolContentTransition *) transition options: (NSSymbolEffectOptions *) options completion: (JSValue *) completionHandler );
@end
@protocol UIImageViewAnonCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop