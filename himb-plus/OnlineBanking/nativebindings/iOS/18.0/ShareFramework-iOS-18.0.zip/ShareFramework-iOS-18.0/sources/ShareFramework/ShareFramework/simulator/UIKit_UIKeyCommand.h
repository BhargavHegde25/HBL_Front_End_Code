#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIKeyCommand_symbols(JSContext*);
@protocol UIKeyCommandInstanceExports<JSExport>
@property (copy,nonatomic) NSString * title;
@property (copy,nonatomic) UIImage * image;
@property (copy,nonatomic) NSString * discoverabilityTitle;
@property (readonly,getter=getJsAction) NSString* jsaction;
@property (readonly,nonatomic) NSString * input;
@property (readonly,nonatomic) UIKeyModifierFlags modifierFlags;
@property (readonly,nonatomic) id propertyList;
@property (nonatomic) UIMenuElementAttributes attributes;
@property (nonatomic) UIMenuElementState state;
@property (readonly,nonatomic) NSArray * alternates;
@property (nonatomic) BOOL wantsPriorityOverSystemBehavior;
@property (nonatomic) BOOL allowsAutomaticLocalization;
@property (nonatomic) BOOL allowsAutomaticMirroring;
-(id) jsinit;
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
@end
@protocol UIKeyCommandClassExports<JSExport>
JSExportAs(commandWithTitleImageActionInputModifierFlagsPropertyList,
+(id) jscommandWithTitle: (NSString *) title image: (UIImage *) image action: (NSString *) action input: (NSString *) input modifierFlags: (UIKeyModifierFlags) modifierFlags propertyList: (id) propertyList );
JSExportAs(commandWithTitleImageActionInputModifierFlagsPropertyListAlternates,
+(id) jscommandWithTitle: (NSString *) title image: (UIImage *) image action: (NSString *) action input: (NSString *) input modifierFlags: (UIKeyModifierFlags) modifierFlags propertyList: (id) propertyList alternates: (NSArray *) alternates );
JSExportAs(keyCommandWithInputModifierFlagsAction,
+(id) jskeyCommandWithInput: (NSString *) input modifierFlags: (UIKeyModifierFlags) modifierFlags action: (NSString *) action );
JSExportAs(keyCommandWithInputModifierFlagsActionDiscoverabilityTitle,
+(id) jskeyCommandWithInput: (NSString *) input modifierFlags: (UIKeyModifierFlags) modifierFlags action: (NSString *) action discoverabilityTitle: (NSString *) discoverabilityTitle );
@end
#pragma clang diagnostic pop