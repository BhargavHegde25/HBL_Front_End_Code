#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIMenuBuilder_symbols(JSContext*);
@protocol UIMenuBuilderInstanceExports_<JSExport>
@property (readonly,nonatomic) UIMenuSystem * system;
-(UIMenu *) menuForIdentifier: (UIMenuIdentifier) identifier ;
-(UIAction *) actionForIdentifier: (UIActionIdentifier) identifier ;
JSExportAs(commandForActionPropertyList,
-(UICommand *) jscommandForAction: (NSString *) action propertyList: (id) propertyList );
-(void) replaceMenuForIdentifier: (UIMenuIdentifier) replacedIdentifier withMenu: (UIMenu *) replacementMenu ;
JSExportAs(replaceChildrenOfMenuForIdentifierFromChildrenBlock,
-(void) jsreplaceChildrenOfMenuForIdentifier: (UIMenuIdentifier) parentIdentifier fromChildrenBlock: (JSValue *) childrenBlock );
-(void) insertSiblingMenu: (UIMenu *) siblingMenu beforeMenuForIdentifier: (UIMenuIdentifier) siblingIdentifier ;
-(void) insertSiblingMenu: (UIMenu *) siblingMenu afterMenuForIdentifier: (UIMenuIdentifier) siblingIdentifier ;
-(void) insertChildMenu: (UIMenu *) childMenu atStartOfMenuForIdentifier: (UIMenuIdentifier) parentIdentifier ;
-(void) insertChildMenu: (UIMenu *) childMenu atEndOfMenuForIdentifier: (UIMenuIdentifier) parentIdentifier ;
-(void) removeMenuForIdentifier: (UIMenuIdentifier) removedIdentifier ;
@end
@protocol UIMenuBuilderClassExports_<JSExport>
@end
#pragma clang diagnostic pop