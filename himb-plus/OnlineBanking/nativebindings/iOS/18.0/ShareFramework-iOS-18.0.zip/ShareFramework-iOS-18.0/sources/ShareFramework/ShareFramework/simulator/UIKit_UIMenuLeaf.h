#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIMenuLeaf_symbols(JSContext*);
@protocol UIMenuLeafInstanceExports_<JSExport, NSObjectInstanceExports_>
@property (copy,nonatomic) NSString * title;
@property (copy,nonatomic) UIImage * image;
@property (copy,nonatomic) UIImage * selectedImage;
@property (copy,nonatomic) NSString * discoverabilityTitle;
@property (nonatomic) UIMenuElementAttributes attributes;
@property (nonatomic) UIMenuElementState state;
@property (readonly,nonatomic) id sender;
@property (readonly,nonatomic) id presentationSourceItem;
-(void) performWithSender: (id) sender target: (id) target ;
@end
@protocol UIMenuLeafClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop