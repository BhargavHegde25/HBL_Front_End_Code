#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIMotionEffect_symbols(JSContext*);
@protocol UIMotionEffectInstanceExports<JSExport, NSCopyingInstanceExports_, NSCodingInstanceExports_>
-(id) jsinit;
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
-(NSDictionary *) keyPathsAndRelativeValuesForViewerOffset: (UIOffset) viewerOffset ;
@end
@protocol UIMotionEffectClassExports<JSExport, NSCopyingClassExports_, NSCodingClassExports_>
@end
@protocol UIInterpolatingMotionEffectInstanceExports<JSExport>
@property (readonly,nonatomic) NSString * keyPath;
@property (readonly,nonatomic) UIInterpolatingMotionEffectType type;
@property (nonatomic,strong) id minimumRelativeValue;
@property (nonatomic,strong) id maximumRelativeValue;
JSExportAs(initWithKeyPathType,
-(id) jsinitWithKeyPath: (NSString *) keyPath type: (UIInterpolatingMotionEffectType) type );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
@end
@protocol UIInterpolatingMotionEffectClassExports<JSExport>
@end
@protocol UIMotionEffectGroupInstanceExports<JSExport>
@property (copy,nonatomic) NSArray * motionEffects;
@end
@protocol UIMotionEffectGroupClassExports<JSExport>
@end
#pragma clang diagnostic pop