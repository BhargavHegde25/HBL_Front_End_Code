#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UINavigationController_symbols(JSContext*);
@protocol UINavigationControllerInstanceExports<JSExport>
@property (readonly,nonatomic,strong) UIViewController * topViewController;
@property (readonly,nonatomic,strong) UIViewController * visibleViewController;
@property (copy,nonatomic) NSArray * viewControllers;
@property (getter=isNavigationBarHidden,nonatomic) BOOL navigationBarHidden;
@property (readonly,nonatomic) UINavigationBar * navigationBar;
@property (getter=isToolbarHidden,nonatomic) BOOL toolbarHidden;
@property (readonly,nonatomic) UIToolbar * toolbar;
@property (nonatomic,weak) id delegate;
@property (readonly,nonatomic) UIGestureRecognizer * interactivePopGestureRecognizer;
@property (assign,readwrite,nonatomic) BOOL hidesBarsWhenKeyboardAppears;
@property (assign,readwrite,nonatomic) BOOL hidesBarsOnSwipe;
@property (readonly,nonatomic,strong) UIPanGestureRecognizer * barHideOnSwipeGestureRecognizer;
@property (assign,readwrite,nonatomic) BOOL hidesBarsWhenVerticallyCompact;
@property (assign,readwrite,nonatomic) BOOL hidesBarsOnTap;
@property (readonly,assign,nonatomic) UITapGestureRecognizer * barHideOnTapGestureRecognizer;
JSExportAs(initWithNavigationBarClassToolbarClass,
-(id) jsinitWithNavigationBarClass: (JSValue *) navigationBarClass toolbarClass: (JSValue *) toolbarClass );
JSExportAs(initWithRootViewController,
-(id) jsinitWithRootViewController: (UIViewController *) rootViewController );
JSExportAs(initWithNibNameBundle,
-(id) jsinitWithNibName: (NSString *) nibNameOrNil bundle: (NSBundle *) nibBundleOrNil );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) aDecoder );
-(void) pushViewController: (UIViewController *) viewController animated: (BOOL) animated ;
-(UIViewController *) popViewControllerAnimated: (BOOL) animated ;
-(NSArray *) popToViewController: (UIViewController *) viewController animated: (BOOL) animated ;
-(NSArray *) popToRootViewControllerAnimated: (BOOL) animated ;
-(void) setViewControllers: (NSArray *) viewControllers animated: (BOOL) animated ;
-(void) setNavigationBarHidden: (BOOL) hidden animated: (BOOL) animated ;
-(void) setToolbarHidden: (BOOL) hidden animated: (BOOL) animated ;
-(void) showViewController: (UIViewController *) vc sender: (id) sender ;
@end
@protocol UINavigationControllerClassExports<JSExport>
@end
@protocol UIViewControllerUINavigationControllerItemCategoryInstanceExports<JSExport>
@property (readonly,nonatomic,strong) UINavigationItem * navigationItem;
@property (nonatomic) BOOL hidesBottomBarWhenPushed;
@property (readonly,nonatomic,strong) UINavigationController * navigationController;
@end
@protocol UIViewControllerUINavigationControllerItemCategoryClassExports<JSExport>
@end
@protocol UIViewControllerUINavigationControllerContextualToolbarItemsCategoryInstanceExports<JSExport>
@property (nonatomic,strong) NSArray * toolbarItems;
-(void) setToolbarItems: (NSArray *) toolbarItems animated: (BOOL) animated ;
@end
@protocol UIViewControllerUINavigationControllerContextualToolbarItemsCategoryClassExports<JSExport>
@end
@protocol UINavigationControllerDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) navigationController: (UINavigationController *) navigationController willShowViewController: (UIViewController *) viewController animated: (BOOL) animated ;
-(void) navigationController: (UINavigationController *) navigationController didShowViewController: (UIViewController *) viewController animated: (BOOL) animated ;
-(UIInterfaceOrientationMask) navigationControllerSupportedInterfaceOrientations: (UINavigationController *) navigationController ;
-(UIInterfaceOrientation) navigationControllerPreferredInterfaceOrientationForPresentation: (UINavigationController *) navigationController ;
-(id) navigationController: (UINavigationController *) navigationController interactionControllerForAnimationController: (id) animationController ;
-(id) navigationController: (UINavigationController *) navigationController animationControllerForOperation: (UINavigationControllerOperation) operation fromViewController: (UIViewController *) fromVC toViewController: (UIViewController *) toVC ;
@end
@protocol UINavigationControllerDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop