#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UINavigationItem_symbols(JSContext*);
@protocol UINavigationItemInstanceExports<JSExport, NSCodingInstanceExports_>
@property (readwrite,copy,nonatomic) NSString * title;
@property (readwrite,nonatomic,strong) UIView * titleView;
@property (readwrite,copy,nonatomic) NSString * prompt;
@property (readwrite,nonatomic,strong) UIBarButtonItem * backBarButtonItem;
@property (readwrite,copy,nonatomic) NSString * backButtonTitle;
@property (assign,readwrite,nonatomic) BOOL hidesBackButton;
@property (assign,readwrite,nonatomic) UINavigationItemBackButtonDisplayMode backButtonDisplayMode;
@property (readwrite,copy,nonatomic) UIAction * backAction;
@property (getter=getJsTitleMenuProvider,setter=setJsTitleMenuProvider:) JSValue* jstitleMenuProvider;
@property (readwrite,nonatomic,weak) id renameDelegate;
@property (readwrite,nonatomic,strong) UIDocumentProperties * documentProperties;
@property (readwrite,copy,nonatomic) NSArray * leftBarButtonItems;
@property (readwrite,copy,nonatomic) NSArray * rightBarButtonItems;
@property (assign,readwrite,nonatomic) BOOL leftItemsSupplementBackButton;
@property (readwrite,nonatomic,strong) UIBarButtonItem * leftBarButtonItem;
@property (readwrite,nonatomic,strong) UIBarButtonItem * rightBarButtonItem;
@property (readwrite,copy,nonatomic) NSString * customizationIdentifier;
@property (readwrite,copy,nonatomic) NSArray * leadingItemGroups;
@property (readwrite,copy,nonatomic) NSArray * centerItemGroups;
@property (readwrite,copy,nonatomic) NSArray * trailingItemGroups;
@property (readwrite,nonatomic,strong) UIBarButtonItemGroup * pinnedTrailingGroup;
@property (readwrite,nonatomic,strong) UIDeferredMenuElement * additionalOverflowItems;
@property (readonly,nonatomic,strong) id overflowPresentationSource;
@property (assign,readwrite,nonatomic) UINavigationItemLargeTitleDisplayMode largeTitleDisplayMode;
@property (assign,readwrite,nonatomic) UINavigationItemStyle style;
@property (readwrite,nonatomic,strong) UISearchController * searchController;
@property (assign,readwrite,nonatomic) BOOL hidesSearchBarWhenScrolling;
@property (assign,readwrite,nonatomic) UINavigationItemSearchBarPlacement preferredSearchBarPlacement;
@property (readonly,assign,nonatomic) UINavigationItemSearchBarPlacement searchBarPlacement;
@property (readwrite,copy,nonatomic) UINavigationBarAppearance * standardAppearance;
@property (readwrite,copy,nonatomic) UINavigationBarAppearance * compactAppearance;
@property (readwrite,copy,nonatomic) UINavigationBarAppearance * scrollEdgeAppearance;
@property (readwrite,copy,nonatomic) UINavigationBarAppearance * compactScrollEdgeAppearance;
JSExportAs(initWithTitle,
-(id) jsinitWithTitle: (NSString *) title );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
-(void) setHidesBackButton: (BOOL) hidesBackButton animated: (BOOL) animated ;
-(void) setLeftBarButtonItems: (NSArray *) items animated: (BOOL) animated ;
-(void) setRightBarButtonItems: (NSArray *) items animated: (BOOL) animated ;
-(void) setLeftBarButtonItem: (UIBarButtonItem *) item animated: (BOOL) animated ;
-(void) setRightBarButtonItem: (UIBarButtonItem *) item animated: (BOOL) animated ;
@end
@protocol UINavigationItemClassExports<JSExport, NSCodingClassExports_>
@end
@protocol UINavigationItemRenameDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) navigationItem: (UINavigationItem *) navigationItem didEndRenamingWithTitle: (NSString *) title ;
-(BOOL) navigationItemShouldBeginRenaming: (UINavigationItem *) navigationItem ;
-(BOOL) navigationItem: (UINavigationItem *) navigationItem shouldEndRenamingWithTitle: (NSString *) title ;
@end
@protocol UINavigationItemRenameDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop