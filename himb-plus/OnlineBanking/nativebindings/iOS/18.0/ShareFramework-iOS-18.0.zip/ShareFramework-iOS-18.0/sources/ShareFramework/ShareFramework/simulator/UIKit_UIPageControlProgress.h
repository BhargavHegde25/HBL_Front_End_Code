#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIPageControlProgress_symbols(JSContext*);
@protocol UIPageControlProgressInstanceExports<JSExport>
@property (nonatomic,weak) id delegate;
@property (assign,nonatomic) float currentProgress;
@property (getter=isProgressVisible,readonly,assign,nonatomic) BOOL progressVisible;
@end
@protocol UIPageControlProgressClassExports<JSExport>
@end
@protocol UIPageControlTimerProgressInstanceExports<JSExport>
@property (nonatomic,weak) id delegate;
@property (assign,nonatomic) BOOL resetsToInitialPageAfterEnd;
@property (getter=isRunning,readonly,assign,nonatomic) BOOL running;
@property (assign,nonatomic) NSTimeInterval preferredDuration;
JSExportAs(initWithPreferredDuration,
-(id) jsinitWithPreferredDuration: (NSTimeInterval) preferredDuration );
-(void) resumeTimer;
-(void) pauseTimer;
-(void) setDuration: (NSTimeInterval) duration forPage: (NSInteger) page ;
-(NSTimeInterval) durationForPage: (NSInteger) page ;
@end
@protocol UIPageControlTimerProgressClassExports<JSExport>
@end
@protocol UIPageControlProgressDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(float) pageControlProgress: (UIPageControlProgress *) progress initialProgressForPage: (NSInteger) page ;
-(void) pageControlProgressVisibilityDidChange: (UIPageControlProgress *) progress ;
@end
@protocol UIPageControlProgressDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UIPageControlTimerProgressDelegateInstanceExports_<JSExport, UIPageControlProgressDelegateInstanceExports_>
-(void) pageControlTimerProgressDidChange: (UIPageControlTimerProgress *) progress ;
-(BOOL) pageControlTimerProgress: (UIPageControlTimerProgress *) progress shouldAdvanceToPage: (NSInteger) page ;
@end
@protocol UIPageControlTimerProgressDelegateClassExports_<JSExport, UIPageControlProgressDelegateClassExports_>
@end
#pragma clang diagnostic pop