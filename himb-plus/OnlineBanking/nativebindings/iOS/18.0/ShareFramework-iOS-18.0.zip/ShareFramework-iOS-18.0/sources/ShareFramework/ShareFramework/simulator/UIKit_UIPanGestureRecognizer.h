#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIPanGestureRecognizer_symbols(JSContext*);
@protocol UIPanGestureRecognizerInstanceExports<JSExport>
@property (nonatomic) NSUInteger minimumNumberOfTouches;
@property (nonatomic) NSUInteger maximumNumberOfTouches;
@property (nonatomic) UIScrollTypeMask allowedScrollTypesMask;
-(CGPoint) translationInView: (UIView *) view ;
-(void) setTranslation: (CGPoint) translation inView: (UIView *) view ;
-(CGPoint) velocityInView: (UIView *) view ;
@end
@protocol UIPanGestureRecognizerClassExports<JSExport>
@end
#pragma clang diagnostic pop