#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIPasteControl_symbols(JSContext*);
@protocol UIPasteControlConfigurationInstanceExports<JSExport, NSSecureCodingInstanceExports_>
@property (assign,nonatomic) UIPasteControlDisplayMode displayMode;
@property (assign,nonatomic) UIButtonConfigurationCornerStyle cornerStyle;
@property (assign,nonatomic) CGFloat cornerRadius;
@property (nonatomic,strong) UIColor * baseForegroundColor;
@property (nonatomic,strong) UIColor * baseBackgroundColor;
@end
@protocol UIPasteControlConfigurationClassExports<JSExport, NSSecureCodingClassExports_>
@end
@protocol UIPasteControlInstanceExports<JSExport>
@property (readonly,nonatomic) UIPasteControlConfiguration * configuration;
@property (nonatomic,weak) id target;
JSExportAs(initWithConfiguration,
-(id) jsinitWithConfiguration: (UIPasteControlConfiguration *) configuration );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
JSExportAs(initWithFrame,
-(id) jsinitWithFrame: (CGRect) frame );
@end
@protocol UIPasteControlClassExports<JSExport>
@end
#pragma clang diagnostic pop