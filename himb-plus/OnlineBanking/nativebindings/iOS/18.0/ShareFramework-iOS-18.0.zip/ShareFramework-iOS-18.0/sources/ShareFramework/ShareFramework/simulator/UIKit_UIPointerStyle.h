#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIPointerStyle_symbols(JSContext*);
@protocol UIPointerStyleInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (copy,nonatomic) NSArray * accessories;
@end
@protocol UIPointerStyleClassExports<JSExport, NSCopyingClassExports_>
+(id) styleWithEffect: (UIPointerEffect *) effect shape: (UIPointerShape *) shape ;
+(id) styleWithShape: (UIPointerShape *) shape constrainedAxes: (UIAxis) axes ;
+(id) hiddenPointerStyle;
+(id) systemPointerStyle;
@end
@protocol UIPointerEffectInstanceExports<JSExport, NSCopyingInstanceExports_, UIHoverEffectInstanceExports_>
@property (readonly,copy,nonatomic) UITargetedPreview * preview;
@end
@protocol UIPointerEffectClassExports<JSExport, NSCopyingClassExports_, UIHoverEffectClassExports_>
+(id) effectWithPreview: (UITargetedPreview *) preview ;
@end
@protocol UIPointerHighlightEffectInstanceExports<JSExport>
@end
@protocol UIPointerHighlightEffectClassExports<JSExport>
@end
@protocol UIPointerLiftEffectInstanceExports<JSExport>
@end
@protocol UIPointerLiftEffectClassExports<JSExport>
@end
@protocol UIPointerHoverEffectInstanceExports<JSExport>
@property (nonatomic) UIPointerEffectTintMode preferredTintMode;
@property (nonatomic) BOOL prefersShadow;
@property (nonatomic) BOOL prefersScaledContent;
@end
@protocol UIPointerHoverEffectClassExports<JSExport>
@end
@protocol UIPointerShapeInstanceExports<JSExport, NSCopyingInstanceExports_>
@end
@protocol UIPointerShapeClassExports<JSExport, NSCopyingClassExports_>
+(id) shapeWithPath: (UIBezierPath *) path ;
+(id) shapeWithRoundedRect: (CGRect) rect ;
+(id) shapeWithRoundedRect: (CGRect) rect cornerRadius: (CGFloat) cornerRadius ;
+(id) beamWithPreferredLength: (CGFloat) length axis: (UIAxis) axis ;
@end
#pragma clang diagnostic pop