#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIPopoverController_symbols(JSContext*);
@protocol UIPopoverControllerInstanceExports<JSExport, UIAppearanceContainerInstanceExports_>
@property (nonatomic,weak) id delegate;
@property (nonatomic,strong) UIViewController * contentViewController;
@property (nonatomic) CGSize popoverContentSize;
@property (getter=isPopoverVisible,readonly,nonatomic) BOOL popoverVisible;
@property (readonly,nonatomic) UIPopoverArrowDirection popoverArrowDirection;
@property (copy,nonatomic) NSArray * passthroughViews;
@property (copy,nonatomic) UIColor * backgroundColor;
@property (readwrite,nonatomic) UIEdgeInsets popoverLayoutMargins;
@property (getter=getJsPopoverBackgroundViewClass,setter=setJsPopoverBackgroundViewClass:) JSValue* jspopoverBackgroundViewClass;
JSExportAs(initWithContentViewController,
-(id) jsinitWithContentViewController: (UIViewController *) viewController );
-(void) setContentViewController: (UIViewController *) viewController animated: (BOOL) animated ;
-(void) setPopoverContentSize: (CGSize) size animated: (BOOL) animated ;
-(void) presentPopoverFromRect: (CGRect) rect inView: (UIView *) view permittedArrowDirections: (UIPopoverArrowDirection) arrowDirections animated: (BOOL) animated ;
-(void) presentPopoverFromBarButtonItem: (UIBarButtonItem *) item permittedArrowDirections: (UIPopoverArrowDirection) arrowDirections animated: (BOOL) animated ;
-(void) dismissPopoverAnimated: (BOOL) animated ;
@end
@protocol UIPopoverControllerClassExports<JSExport, UIAppearanceContainerClassExports_>
@end
@protocol UIPopoverControllerDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(BOOL) popoverControllerShouldDismissPopover: (UIPopoverController *) popoverController ;
-(void) popoverControllerDidDismissPopover: (UIPopoverController *) popoverController ;
@end
@protocol UIPopoverControllerDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop