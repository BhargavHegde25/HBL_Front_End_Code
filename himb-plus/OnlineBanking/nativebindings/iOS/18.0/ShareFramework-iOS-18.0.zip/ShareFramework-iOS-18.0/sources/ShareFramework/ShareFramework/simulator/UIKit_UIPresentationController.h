#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIPresentationController_symbols(JSContext*);
@protocol UIPresentationControllerInstanceExports<JSExport, UIAppearanceContainerInstanceExports_, UITraitEnvironmentInstanceExports_, UIContentContainerInstanceExports_, UIFocusEnvironmentInstanceExports_>
@property (readonly,nonatomic,strong) UIViewController * presentingViewController;
@property (readonly,nonatomic,strong) UIViewController * presentedViewController;
@property (readonly,nonatomic) UIModalPresentationStyle presentationStyle;
@property (readonly,nonatomic,strong) UIView * containerView;
@property (nonatomic,weak) id delegate;
@property (readonly,nonatomic) UIModalPresentationStyle adaptivePresentationStyle;
@property (readonly,nonatomic) UIView * presentedView;
@property (readonly,nonatomic) CGRect frameOfPresentedViewInContainerView;
@property (readonly,nonatomic) BOOL shouldPresentInFullscreen;
@property (readonly,nonatomic) BOOL shouldRemovePresentersView;
@property (copy,nonatomic) UITraitCollection * overrideTraitCollection;
JSExportAs(initWithPresentedViewControllerPresentingViewController,
-(id) jsinitWithPresentedViewController: (UIViewController *) presentedViewController presentingViewController: (UIViewController *) presentingViewController );
-(UIModalPresentationStyle) adaptivePresentationStyleForTraitCollection: (UITraitCollection *) traitCollection ;
-(void) containerViewWillLayoutSubviews;
-(void) containerViewDidLayoutSubviews;
-(void) presentationTransitionWillBegin;
-(void) presentationTransitionDidEnd: (BOOL) completed ;
-(void) dismissalTransitionWillBegin;
-(void) dismissalTransitionDidEnd: (BOOL) completed ;
@end
@protocol UIPresentationControllerClassExports<JSExport, UIAppearanceContainerClassExports_, UITraitEnvironmentClassExports_, UIContentContainerClassExports_, UIFocusEnvironmentClassExports_>
@end
@protocol UIPresentationControllerAnonCategoryInstanceExports<JSExport, UITraitChangeObservableInstanceExports_>
@property (readonly,nonatomic) id traitOverrides;
@end
@protocol UIPresentationControllerAnonCategoryClassExports<JSExport, UITraitChangeObservableClassExports_>
@end
@protocol UIAdaptivePresentationControllerDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(UIModalPresentationStyle) adaptivePresentationStyleForPresentationController: (UIPresentationController *) controller ;
-(UIModalPresentationStyle) adaptivePresentationStyleForPresentationController: (UIPresentationController *) controller traitCollection: (UITraitCollection *) traitCollection ;
-(void) presentationController: (UIPresentationController *) presentationController prepareAdaptivePresentationController: (UIPresentationController *) adaptivePresentationController ;
-(UIViewController *) presentationController: (UIPresentationController *) controller viewControllerForAdaptivePresentationStyle: (UIModalPresentationStyle) style ;
-(void) presentationController: (UIPresentationController *) presentationController willPresentWithAdaptiveStyle: (UIModalPresentationStyle) style transitionCoordinator: (id) transitionCoordinator ;
-(BOOL) presentationControllerShouldDismiss: (UIPresentationController *) presentationController ;
-(void) presentationControllerWillDismiss: (UIPresentationController *) presentationController ;
-(void) presentationControllerDidDismiss: (UIPresentationController *) presentationController ;
-(void) presentationControllerDidAttemptToDismiss: (UIPresentationController *) presentationController ;
@end
@protocol UIAdaptivePresentationControllerDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop