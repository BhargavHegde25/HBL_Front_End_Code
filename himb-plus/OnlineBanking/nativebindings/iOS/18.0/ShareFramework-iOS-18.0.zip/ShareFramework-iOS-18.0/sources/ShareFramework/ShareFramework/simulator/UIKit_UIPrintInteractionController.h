#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIPrintInteractionController_symbols(JSContext*);
@protocol UIPrintInteractionControllerInstanceExports<JSExport>
@property (nonatomic,strong) UIPrintInfo * printInfo;
@property (nonatomic,weak) id delegate;
@property (nonatomic) BOOL showsPageRange;
@property (nonatomic) BOOL showsNumberOfCopies;
@property (nonatomic) BOOL showsPaperSelectionForLoadedPapers;
@property (nonatomic) BOOL showsPaperOrientation;
@property (readonly,nonatomic) UIPrintPaper * printPaper;
@property (nonatomic,strong) UIPrintPageRenderer * printPageRenderer;
@property (nonatomic,strong) UIPrintFormatter * printFormatter;
@property (copy,nonatomic) id printingItem;
@property (copy,nonatomic) NSArray * printingItems;
JSExportAs(presentAnimatedCompletionHandler,
-(BOOL) jspresentAnimated: (BOOL) animated completionHandler: (JSValue *) completion );
JSExportAs(presentFromRectInViewAnimatedCompletionHandler,
-(BOOL) jspresentFromRect: (CGRect) rect inView: (UIView *) view animated: (BOOL) animated completionHandler: (JSValue *) completion );
JSExportAs(presentFromBarButtonItemAnimatedCompletionHandler,
-(BOOL) jspresentFromBarButtonItem: (UIBarButtonItem *) item animated: (BOOL) animated completionHandler: (JSValue *) completion );
JSExportAs(printToPrinterCompletionHandler,
-(BOOL) jsprintToPrinter: (UIPrinter *) printer completionHandler: (JSValue *) completion );
-(void) dismissAnimated: (BOOL) animated ;
@end
@protocol UIPrintInteractionControllerClassExports<JSExport>
+(BOOL) canPrintURL: (NSURL *) url ;
+(BOOL) canPrintData: (NSData *) data ;
+(BOOL) isPrintingAvailable;
+(NSSet *) printableUTIs;
+(UIPrintInteractionController *) sharedPrintController;
@end
@protocol UIPrintInteractionControllerDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(UIViewController *) printInteractionControllerParentViewController: (UIPrintInteractionController *) printInteractionController ;
-(UIPrintPaper *) printInteractionController: (UIPrintInteractionController *) printInteractionController choosePaper: (NSArray *) paperList ;
-(void) printInteractionControllerWillPresentPrinterOptions: (UIPrintInteractionController *) printInteractionController ;
-(void) printInteractionControllerDidPresentPrinterOptions: (UIPrintInteractionController *) printInteractionController ;
-(void) printInteractionControllerWillDismissPrinterOptions: (UIPrintInteractionController *) printInteractionController ;
-(void) printInteractionControllerDidDismissPrinterOptions: (UIPrintInteractionController *) printInteractionController ;
-(void) printInteractionControllerWillStartJob: (UIPrintInteractionController *) printInteractionController ;
-(void) printInteractionControllerDidFinishJob: (UIPrintInteractionController *) printInteractionController ;
-(CGFloat) printInteractionController: (UIPrintInteractionController *) printInteractionController cutLengthForPaper: (UIPrintPaper *) paper ;
-(UIPrinterCutterBehavior) printInteractionController: (UIPrintInteractionController *) printInteractionController chooseCutterBehavior: (NSArray *) availableBehaviors ;
@end
@protocol UIPrintInteractionControllerDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop