#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIPrintServiceExtension_symbols(JSContext*);
@protocol UIPrinterDestinationInstanceExports<JSExport, NSSecureCodingInstanceExports_>
@property (readwrite,copy) NSURL * URL;
@property (readwrite,copy) NSString * displayName;
@property (readwrite,copy) NSData * txtRecord;
JSExportAs(initWithURL,
-(id) jsinitWithURL: (NSURL *) url );
@end
@protocol UIPrinterDestinationClassExports<JSExport, NSSecureCodingClassExports_>
@end
@protocol UIPrintServiceExtensionInstanceExports<JSExport>
-(NSArray *) printerDestinationsForPrintInfo: (UIPrintInfo *) printInfo ;
@end
@protocol UIPrintServiceExtensionClassExports<JSExport>
@end
#pragma clang diagnostic pop