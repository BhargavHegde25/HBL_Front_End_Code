#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIPrinterPickerController_symbols(JSContext*);
@protocol UIPrinterPickerControllerInstanceExports<JSExport>
@property (readonly,nonatomic) UIPrinter * selectedPrinter;
@property (nonatomic,weak) id delegate;
JSExportAs(presentAnimatedCompletionHandler,
-(BOOL) jspresentAnimated: (BOOL) animated completionHandler: (JSValue *) completion );
JSExportAs(presentFromRectInViewAnimatedCompletionHandler,
-(BOOL) jspresentFromRect: (CGRect) rect inView: (UIView *) view animated: (BOOL) animated completionHandler: (JSValue *) completion );
JSExportAs(presentFromBarButtonItemAnimatedCompletionHandler,
-(BOOL) jspresentFromBarButtonItem: (UIBarButtonItem *) item animated: (BOOL) animated completionHandler: (JSValue *) completion );
-(void) dismissAnimated: (BOOL) animated ;
@end
@protocol UIPrinterPickerControllerClassExports<JSExport>
+(UIPrinterPickerController *) printerPickerControllerWithInitiallySelectedPrinter: (UIPrinter *) printer ;
@end
@protocol UIPrinterPickerControllerDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(UIViewController *) printerPickerControllerParentViewController: (UIPrinterPickerController *) printerPickerController ;
-(BOOL) printerPickerController: (UIPrinterPickerController *) printerPickerController shouldShowPrinter: (UIPrinter *) printer ;
-(void) printerPickerControllerWillPresent: (UIPrinterPickerController *) printerPickerController ;
-(void) printerPickerControllerDidPresent: (UIPrinterPickerController *) printerPickerController ;
-(void) printerPickerControllerWillDismiss: (UIPrinterPickerController *) printerPickerController ;
-(void) printerPickerControllerDidDismiss: (UIPrinterPickerController *) printerPickerController ;
-(void) printerPickerControllerDidSelectPrinter: (UIPrinterPickerController *) printerPickerController ;
@end
@protocol UIPrinterPickerControllerDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop