#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIProgressView_symbols(JSContext*);
@protocol UIProgressViewInstanceExports<JSExport, NSCodingInstanceExports_>
@property (nonatomic) UIProgressViewStyle progressViewStyle;
@property (nonatomic) float progress;
@property (nonatomic,strong) UIColor * progressTintColor;
@property (nonatomic,strong) UIColor * trackTintColor;
@property (nonatomic,strong) UIImage * progressImage;
@property (nonatomic,strong) UIImage * trackImage;
@property (nonatomic,strong) NSProgress * observedProgress;
JSExportAs(initWithFrame,
-(id) jsinitWithFrame: (CGRect) frame );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
JSExportAs(initWithProgressViewStyle,
-(id) jsinitWithProgressViewStyle: (UIProgressViewStyle) style );
-(void) setProgress: (float) progress animated: (BOOL) animated ;
@end
@protocol UIProgressViewClassExports<JSExport, NSCodingClassExports_>
@end
#pragma clang diagnostic pop