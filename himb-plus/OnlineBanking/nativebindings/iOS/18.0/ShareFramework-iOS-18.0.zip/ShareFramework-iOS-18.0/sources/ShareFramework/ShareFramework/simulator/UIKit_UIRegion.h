#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIRegion_symbols(JSContext*);
@protocol UIRegionInstanceExports<JSExport, NSCopyingInstanceExports_, NSCodingInstanceExports_>
JSExportAs(initWithRadius,
-(id) jsinitWithRadius: (CGFloat) radius );
JSExportAs(initWithSize,
-(id) jsinitWithSize: (CGSize) size );
-(id) inverseRegion;
-(id) regionByUnionWithRegion: (UIRegion *) region ;
-(id) regionByDifferenceFromRegion: (UIRegion *) region ;
-(id) regionByIntersectionWithRegion: (UIRegion *) region ;
-(BOOL) containsPoint: (CGPoint) point ;
@end
@protocol UIRegionClassExports<JSExport, NSCopyingClassExports_, NSCodingClassExports_>
+(UIRegion *) infiniteRegion;
@end
#pragma clang diagnostic pop