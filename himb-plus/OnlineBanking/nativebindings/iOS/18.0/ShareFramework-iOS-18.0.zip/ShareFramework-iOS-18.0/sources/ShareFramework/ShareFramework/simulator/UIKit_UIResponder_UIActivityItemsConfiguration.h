#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIResponder_UIActivityItemsConfiguration_symbols(JSContext*);
@protocol UIResponderUIActivityItemsConfigurationCategoryInstanceExports<JSExport, UIActivityItemsConfigurationProvidingInstanceExports_>
@property (nonatomic,strong) id activityItemsConfiguration;
@end
@protocol UIResponderUIActivityItemsConfigurationCategoryClassExports<JSExport, UIActivityItemsConfigurationProvidingClassExports_>
@end
#pragma clang diagnostic pop