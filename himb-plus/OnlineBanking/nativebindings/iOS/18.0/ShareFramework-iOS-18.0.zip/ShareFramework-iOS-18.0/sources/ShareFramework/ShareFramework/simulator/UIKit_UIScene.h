#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIScene_symbols(JSContext*);
@protocol UISceneInstanceExports<JSExport>
@property (readonly,nonatomic) UISceneSession * session;
@property (nonatomic,strong) id delegate;
@property (readonly,nonatomic) UISceneActivationState activationState;
@property (copy,nonatomic) NSString * title;
@property (copy,nonatomic) NSString * subtitle;
@property (nonatomic,strong) UISceneActivationConditions * activationConditions;
JSExportAs(initWithSessionConnectionOptions,
-(id) jsinitWithSession: (UISceneSession *) session connectionOptions: (UISceneConnectionOptions *) connectionOptions );
JSExportAs(openURLOptionsCompletionHandler,
-(void) jsopenURL: (NSURL *) url options: (UISceneOpenExternalURLOptions *) options completionHandler: (JSValue *) completion );
@end
@protocol UISceneClassExports<JSExport>
@end
@protocol UISceneDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) scene: (UIScene *) scene willConnectToSession: (UISceneSession *) session options: (UISceneConnectionOptions *) connectionOptions ;
-(void) sceneDidDisconnect: (UIScene *) scene ;
-(void) sceneDidBecomeActive: (UIScene *) scene ;
-(void) sceneWillResignActive: (UIScene *) scene ;
-(void) sceneWillEnterForeground: (UIScene *) scene ;
-(void) sceneDidEnterBackground: (UIScene *) scene ;
-(void) scene: (UIScene *) scene openURLContexts: (NSSet *) URLContexts ;
-(NSUserActivity *) stateRestorationActivityForScene: (UIScene *) scene ;
-(void) scene: (UIScene *) scene restoreInteractionStateWithUserActivity: (NSUserActivity *) stateRestorationActivity ;
-(void) scene: (UIScene *) scene willContinueUserActivityWithType: (NSString *) userActivityType ;
-(void) scene: (UIScene *) scene continueUserActivity: (NSUserActivity *) userActivity ;
-(void) scene: (UIScene *) scene didFailToContinueUserActivityWithType: (NSString *) userActivityType error: (NSError *) error ;
-(void) scene: (UIScene *) scene didUpdateUserActivity: (NSUserActivity *) userActivity ;
@end
@protocol UISceneDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop