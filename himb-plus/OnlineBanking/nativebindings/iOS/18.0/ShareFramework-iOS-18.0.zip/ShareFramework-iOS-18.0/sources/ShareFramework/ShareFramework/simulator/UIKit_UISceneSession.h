#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UISceneSession_symbols(JSContext*);
@protocol UISceneConfigurationInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,nonatomic) NSString * name;
@property (readonly,nonatomic) UISceneSessionRole role;
@property (getter=getJsSceneClass,setter=setJsSceneClass:) JSValue* jssceneClass;
@property (getter=getJsDelegateClass,setter=setJsDelegateClass:) JSValue* jsdelegateClass;
@property (nonatomic,strong) UIStoryboard * storyboard;
JSExportAs(initWithNameSessionRole,
-(id) jsinitWithName: (NSString *) name sessionRole: (UISceneSessionRole) sessionRole );
@end
@protocol UISceneConfigurationClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
+(id) configurationWithName: (NSString *) name sessionRole: (UISceneSessionRole) sessionRole ;
@end
@protocol UISceneSessionInstanceExports<JSExport, NSSecureCodingInstanceExports_>
@property (readonly,nonatomic) UIScene * scene;
@property (readonly,nonatomic) UISceneSessionRole role;
@property (readonly,copy,nonatomic) UISceneConfiguration * configuration;
@property (readonly,nonatomic) NSString * persistentIdentifier;
@property (nonatomic,strong) NSUserActivity * stateRestorationActivity;
@property (copy,nonatomic) NSDictionary * userInfo;
@end
@protocol UISceneSessionClassExports<JSExport, NSSecureCodingClassExports_>
@end
#pragma clang diagnostic pop