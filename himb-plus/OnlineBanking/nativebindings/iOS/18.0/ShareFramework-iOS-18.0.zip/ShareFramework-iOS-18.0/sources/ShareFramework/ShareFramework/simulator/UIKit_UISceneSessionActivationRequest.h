#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UISceneSessionActivationRequest_symbols(JSContext*);
@protocol UISceneSessionActivationRequestInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (readonly,nonatomic) UISceneSessionRole role;
@property (readonly,nonatomic) UISceneSession * session;
@property (nonatomic,strong) NSUserActivity * userActivity;
@property (copy,nonatomic) UISceneActivationRequestOptions * options;
@end
@protocol UISceneSessionActivationRequestClassExports<JSExport, NSCopyingClassExports_>
+(id) request;
+(id) requestWithRole: (UISceneSessionRole) role ;
+(id) requestWithSession: (UISceneSession *) session ;
@end
#pragma clang diagnostic pop