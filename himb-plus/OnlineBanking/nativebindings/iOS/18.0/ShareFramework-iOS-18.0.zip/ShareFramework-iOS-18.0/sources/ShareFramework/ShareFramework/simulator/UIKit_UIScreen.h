#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIScreen_symbols(JSContext*);
@protocol UIScreenInstanceExports<JSExport, UITraitEnvironmentInstanceExports_>
@property (readonly,nonatomic) CGRect bounds;
@property (readonly,nonatomic) CGFloat scale;
@property (readonly,copy,nonatomic) NSArray * availableModes;
@property (readonly,nonatomic,strong) UIScreenMode * preferredMode;
@property (nonatomic,strong) UIScreenMode * currentMode;
@property (nonatomic) UIScreenOverscanCompensation overscanCompensation;
@property (readonly,nonatomic) UIEdgeInsets overscanCompensationInsets;
@property (readonly,nonatomic,strong) UIScreen * mirroredScreen;
@property (getter=isCaptured,readonly,nonatomic) BOOL captured;
@property (nonatomic) CGFloat brightness;
@property (nonatomic) BOOL wantsSoftwareDimming;
@property (readonly) id coordinateSpace;
@property (readonly) id fixedCoordinateSpace;
@property (readonly,nonatomic) CGRect nativeBounds;
@property (readonly,nonatomic) CGFloat nativeScale;
@property (readonly) NSInteger maximumFramesPerSecond;
@property (readonly,nonatomic) CFTimeInterval calibratedLatency;
@property (readonly,nonatomic) UIScreenReferenceDisplayModeStatus referenceDisplayModeStatus;
@property (readonly,nonatomic) CGFloat currentEDRHeadroom;
@property (readonly,nonatomic) CGFloat potentialEDRHeadroom;
@property (readonly,nonatomic,weak) id focusedItem;
@property (readonly,nonatomic,weak) UIView * focusedView;
@property (readonly,nonatomic) BOOL supportsFocus;
@property (readonly,nonatomic) CGRect applicationFrame;
JSExportAs(displayLinkWithTargetSelector,
-(CADisplayLink *) jsdisplayLinkWithTarget: (id) target selector: (NSString *) sel );
@end
@protocol UIScreenClassExports<JSExport, UITraitEnvironmentClassExports_>
+(NSArray *) screens;
+(UIScreen *) mainScreen;
@end
@protocol UIScreenUISnapshottingCategoryInstanceExports<JSExport>
-(UIView *) snapshotViewAfterScreenUpdates: (BOOL) afterUpdates ;
@end
@protocol UIScreenUISnapshottingCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop