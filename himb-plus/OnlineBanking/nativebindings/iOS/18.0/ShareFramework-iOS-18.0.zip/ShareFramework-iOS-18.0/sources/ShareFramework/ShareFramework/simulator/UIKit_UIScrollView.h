#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIScrollView_symbols(JSContext*);
@protocol UIScrollViewInstanceExports<JSExport, NSCodingInstanceExports_, UIFocusItemScrollableContainerInstanceExports_>
@property (nonatomic) CGPoint contentOffset;
@property (nonatomic) CGSize contentSize;
@property (nonatomic) UIEdgeInsets contentInset;
@property (readonly,nonatomic) UIEdgeInsets adjustedContentInset;
@property (nonatomic) UIScrollViewContentInsetAdjustmentBehavior contentInsetAdjustmentBehavior;
@property (nonatomic) BOOL automaticallyAdjustsScrollIndicatorInsets;
@property (readonly,nonatomic,strong) UILayoutGuide * contentLayoutGuide;
@property (readonly,nonatomic,strong) UILayoutGuide * frameLayoutGuide;
@property (nonatomic,weak) id delegate;
@property (getter=isDirectionalLockEnabled,nonatomic) BOOL directionalLockEnabled;
@property (nonatomic) BOOL bounces;
@property (nonatomic) BOOL alwaysBounceVertical;
@property (nonatomic) BOOL alwaysBounceHorizontal;
@property (getter=isPagingEnabled,nonatomic) BOOL pagingEnabled;
@property (getter=isScrollEnabled,nonatomic) BOOL scrollEnabled;
@property (nonatomic) BOOL showsVerticalScrollIndicator;
@property (nonatomic) BOOL showsHorizontalScrollIndicator;
@property (nonatomic) UIScrollViewIndicatorStyle indicatorStyle;
@property (nonatomic) UIEdgeInsets verticalScrollIndicatorInsets;
@property (nonatomic) UIEdgeInsets horizontalScrollIndicatorInsets;
@property (nonatomic) UIEdgeInsets scrollIndicatorInsets;
@property (nonatomic) UIScrollViewIndexDisplayMode indexDisplayMode;
@property (getter=isTracking,readonly,nonatomic) BOOL tracking;
@property (getter=isDragging,readonly,nonatomic) BOOL dragging;
@property (getter=isDecelerating,readonly,nonatomic) BOOL decelerating;
@property (nonatomic) BOOL delaysContentTouches;
@property (nonatomic) BOOL canCancelContentTouches;
@property (nonatomic) CGFloat minimumZoomScale;
@property (nonatomic) CGFloat maximumZoomScale;
@property (nonatomic) CGFloat zoomScale;
@property (nonatomic) BOOL bouncesZoom;
@property (getter=isZooming,readonly,nonatomic) BOOL zooming;
@property (getter=isZoomBouncing,readonly,nonatomic) BOOL zoomBouncing;
@property (nonatomic) BOOL scrollsToTop;
@property (readonly,nonatomic) UIPanGestureRecognizer * panGestureRecognizer;
@property (readonly,nonatomic) UIPinchGestureRecognizer * pinchGestureRecognizer;
@property (readonly,nonatomic) UIGestureRecognizer * directionalPressGestureRecognizer;
@property (nonatomic) UIScrollViewKeyboardDismissMode keyboardDismissMode;
@property (nonatomic,strong) UIRefreshControl * refreshControl;
@property (assign,nonatomic) BOOL allowsKeyboardScrolling;
-(void) adjustedContentInsetDidChange;
-(UIEdgeInsets) scrollIndicatorInsets;
-(void) setContentOffset: (CGPoint) contentOffset animated: (BOOL) animated ;
-(void) scrollRectToVisible: (CGRect) rect animated: (BOOL) animated ;
-(void) flashScrollIndicators;
-(BOOL) touchesShouldBegin: (NSSet *) touches withEvent: (UIEvent *) event inContentView: (UIView *) view ;
-(BOOL) touchesShouldCancelInContentView: (UIView *) view ;
-(void) setZoomScale: (CGFloat) scale animated: (BOOL) animated ;
-(void) zoomToRect: (CGRect) rect animated: (BOOL) animated ;
@end
@protocol UIScrollViewClassExports<JSExport, NSCodingClassExports_, UIFocusItemScrollableContainerClassExports_>
@end
@protocol UIScrollViewDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) scrollViewDidScroll: (UIScrollView *) scrollView ;
-(void) scrollViewDidZoom: (UIScrollView *) scrollView ;
-(void) scrollViewWillBeginDragging: (UIScrollView *) scrollView ;
-(void) scrollViewDidEndDragging: (UIScrollView *) scrollView willDecelerate: (BOOL) decelerate ;
-(void) scrollViewWillBeginDecelerating: (UIScrollView *) scrollView ;
-(void) scrollViewDidEndDecelerating: (UIScrollView *) scrollView ;
-(void) scrollViewDidEndScrollingAnimation: (UIScrollView *) scrollView ;
-(UIView *) viewForZoomingInScrollView: (UIScrollView *) scrollView ;
-(void) scrollViewWillBeginZooming: (UIScrollView *) scrollView withView: (UIView *) view ;
-(void) scrollViewDidEndZooming: (UIScrollView *) scrollView withView: (UIView *) view atScale: (CGFloat) scale ;
-(BOOL) scrollViewShouldScrollToTop: (UIScrollView *) scrollView ;
-(void) scrollViewDidScrollToTop: (UIScrollView *) scrollView ;
-(void) scrollViewDidChangeAdjustedContentInset: (UIScrollView *) scrollView ;
@end
@protocol UIScrollViewDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop