#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UISearchController_symbols(JSContext*);
@protocol UISearchControllerInstanceExports<JSExport, UIViewControllerTransitioningDelegateInstanceExports_, UIViewControllerAnimatedTransitioningInstanceExports_>
@property (nonatomic,weak) id searchResultsUpdater;
@property (getter=isActive,assign,nonatomic) BOOL active;
@property (nonatomic,weak) id delegate;
@property (assign,nonatomic) BOOL dimsBackgroundDuringPresentation;
@property (assign,nonatomic) BOOL obscuresBackgroundDuringPresentation;
@property (assign,nonatomic) BOOL hidesNavigationBarDuringPresentation;
@property (readonly,nonatomic,strong) UIViewController * searchResultsController;
@property (readonly,nonatomic,strong) UISearchBar * searchBar;
@property (readonly,nonatomic) UINavigationItemSearchBarPlacement searchBarPlacement;
@property (nonatomic) BOOL automaticallyShowsSearchResultsController;
@property (nonatomic) BOOL showsSearchResultsController;
@property (nonatomic) BOOL automaticallyShowsCancelButton;
@property (nonatomic) BOOL automaticallyShowsScopeBar;
@property (nonatomic) UISearchControllerScopeBarActivation scopeBarActivation;
@property (copy,nonatomic) NSArray * searchSuggestions;
@property (nonatomic) BOOL ignoresSearchSuggestionsForSearchBarPlacementStacked;
JSExportAs(initWithSearchResultsController,
-(id) jsinitWithSearchResultsController: (UIViewController *) searchResultsController );
JSExportAs(initWithNibNameBundle,
-(id) jsinitWithNibName: (NSString *) nibNameOrNil bundle: (NSBundle *) nibBundleOrNil );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
@end
@protocol UISearchControllerClassExports<JSExport, UIViewControllerTransitioningDelegateClassExports_, UIViewControllerAnimatedTransitioningClassExports_>
@end
@protocol UISearchControllerDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) willPresentSearchController: (UISearchController *) searchController ;
-(void) didPresentSearchController: (UISearchController *) searchController ;
-(void) willDismissSearchController: (UISearchController *) searchController ;
-(void) didDismissSearchController: (UISearchController *) searchController ;
-(void) presentSearchController: (UISearchController *) searchController ;
-(void) searchController: (UISearchController *) searchController willChangeToSearchBarPlacement: (UINavigationItemSearchBarPlacement) newPlacement ;
-(void) searchController: (UISearchController *) searchController didChangeFromSearchBarPlacement: (UINavigationItemSearchBarPlacement) previousPlacement ;
@end
@protocol UISearchControllerDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UISearchResultsUpdatingInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) updateSearchResultsForSearchController: (UISearchController *) searchController ;
-(void) updateSearchResultsForSearchController: (UISearchController *) searchController selectingSearchSuggestion: (id) searchSuggestion ;
@end
@protocol UISearchResultsUpdatingClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop