#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UISegmentedControl_symbols(JSContext*);
@protocol UISegmentedControlInstanceExports<JSExport, NSCodingInstanceExports_>
@property (nonatomic) UISegmentedControlStyle segmentedControlStyle;
@property (getter=isMomentary,nonatomic) BOOL momentary;
@property (readonly,nonatomic) NSUInteger numberOfSegments;
@property (nonatomic) BOOL apportionsSegmentWidthsByContent;
@property (nonatomic) NSInteger selectedSegmentIndex;
@property (nonatomic,strong) UIColor * selectedSegmentTintColor;
JSExportAs(initWithFrame,
-(id) jsinitWithFrame: (CGRect) frame );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
JSExportAs(initWithItems,
-(id) jsinitWithItems: (NSArray *) items );
JSExportAs(initWithFrameActions,
-(id) jsinitWithFrame: (CGRect) frame actions: (NSArray *) actions );
-(void) insertSegmentWithAction: (UIAction *) action atIndex: (NSUInteger) segment animated: (BOOL) animated ;
-(void) setAction: (UIAction *) action forSegmentAtIndex: (NSUInteger) segment ;
-(UIAction *) actionForSegmentAtIndex: (NSUInteger) segment ;
-(NSInteger) segmentIndexForActionIdentifier: (UIActionIdentifier) actionIdentifier ;
-(void) insertSegmentWithTitle: (NSString *) title atIndex: (NSUInteger) segment animated: (BOOL) animated ;
-(void) insertSegmentWithImage: (UIImage *) image atIndex: (NSUInteger) segment animated: (BOOL) animated ;
-(void) removeSegmentAtIndex: (NSUInteger) segment animated: (BOOL) animated ;
-(void) removeAllSegments;
-(void) setTitle: (NSString *) title forSegmentAtIndex: (NSUInteger) segment ;
-(NSString *) titleForSegmentAtIndex: (NSUInteger) segment ;
-(void) setImage: (UIImage *) image forSegmentAtIndex: (NSUInteger) segment ;
-(UIImage *) imageForSegmentAtIndex: (NSUInteger) segment ;
-(void) setWidth: (CGFloat) width forSegmentAtIndex: (NSUInteger) segment ;
-(CGFloat) widthForSegmentAtIndex: (NSUInteger) segment ;
-(void) setContentOffset: (CGSize) offset forSegmentAtIndex: (NSUInteger) segment ;
-(CGSize) contentOffsetForSegmentAtIndex: (NSUInteger) segment ;
-(void) setEnabled: (BOOL) enabled forSegmentAtIndex: (NSUInteger) segment ;
-(BOOL) isEnabledForSegmentAtIndex: (NSUInteger) segment ;
-(void) setBackgroundImage: (UIImage *) backgroundImage forState: (UIControlState) state barMetrics: (UIBarMetrics) barMetrics ;
-(UIImage *) backgroundImageForState: (UIControlState) state barMetrics: (UIBarMetrics) barMetrics ;
-(void) setDividerImage: (UIImage *) dividerImage forLeftSegmentState: (UIControlState) leftState rightSegmentState: (UIControlState) rightState barMetrics: (UIBarMetrics) barMetrics ;
-(UIImage *) dividerImageForLeftSegmentState: (UIControlState) leftState rightSegmentState: (UIControlState) rightState barMetrics: (UIBarMetrics) barMetrics ;
-(void) setTitleTextAttributes: (NSDictionary *) attributes forState: (UIControlState) state ;
-(NSDictionary *) titleTextAttributesForState: (UIControlState) state ;
-(void) setContentPositionAdjustment: (UIOffset) adjustment forSegmentType: (UISegmentedControlSegment) leftCenterRightOrAlone barMetrics: (UIBarMetrics) barMetrics ;
-(UIOffset) contentPositionAdjustmentForSegmentType: (UISegmentedControlSegment) leftCenterRightOrAlone barMetrics: (UIBarMetrics) barMetrics ;
@end
@protocol UISegmentedControlClassExports<JSExport, NSCodingClassExports_>
@end
@protocol UISegmentedControlSpringLoadingCategoryInstanceExports<JSExport, UISpringLoadedInteractionSupportingInstanceExports_>
@end
@protocol UISegmentedControlSpringLoadingCategoryClassExports<JSExport, UISpringLoadedInteractionSupportingClassExports_>
@end
#pragma clang diagnostic pop