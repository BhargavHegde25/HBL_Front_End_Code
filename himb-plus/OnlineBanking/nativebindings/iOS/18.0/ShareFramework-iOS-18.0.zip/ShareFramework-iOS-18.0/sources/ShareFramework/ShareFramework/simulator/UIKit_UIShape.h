#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIShape_symbols(JSContext*);
@protocol UIShapeInstanceExports<JSExport, UIShapeProviderInstanceExports_, NSCopyingInstanceExports_>
-(UIShape *) shapeByApplyingInsets: (UIEdgeInsets) insets ;
-(UIShape *) shapeByApplyingInset: (CGFloat) inset ;
-(UIResolvedShape *) resolvedShapeInContext: (UIShapeResolutionContext *) context ;
@end
@protocol UIShapeClassExports<JSExport, UIShapeProviderClassExports_, NSCopyingClassExports_>
+(id) rectShapeWithCornerRadius: (CGFloat) cornerRadius ;
+(id) rectShapeWithCornerRadius: (CGFloat) cornerRadius cornerCurve: (UICornerCurve) cornerCurve ;
+(id) rectShapeWithCornerRadius: (CGFloat) cornerRadius cornerCurve: (UICornerCurve) cornerCurve maskedCorners: (UIRectCorner) maskedCorners ;
+(id) fixedRectShapeWithRect: (CGRect) rect ;
+(id) fixedRectShapeWithRect: (CGRect) rect cornerRadius: (CGFloat) cornerRadius ;
+(id) fixedRectShapeWithRect: (CGRect) rect cornerRadius: (CGFloat) cornerRadius cornerCurve: (UICornerCurve) cornerCurve maskedCorners: (UIRectCorner) maskedCorners ;
+(id) shapeWithBezierPath: (UIBezierPath *) path ;
+(id) shapeWithProvider: (id) provider ;
+(UIShape *) rectShape;
+(UIShape *) capsuleShape;
+(UIShape *) circleShape;
@end
@protocol UIResolvedShapeInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (readonly,nonatomic) UIShape * shape;
@property (readonly,nonatomic) CGRect boundingRect;
@property (readonly,nonatomic) UIBezierPath * path;
-(UIResolvedShape *) shapeByApplyingInsets: (UIEdgeInsets) insets ;
-(UIResolvedShape *) shapeByApplyingInset: (CGFloat) inset ;
@end
@protocol UIResolvedShapeClassExports<JSExport, NSCopyingClassExports_>
@end
@protocol UIShapeResolutionContextInstanceExports<JSExport>
@property (readonly,nonatomic) UIResolvedShape * contentShape;
@end
@protocol UIShapeResolutionContextClassExports<JSExport>
@end
@protocol UIShapeProviderInstanceExports_<JSExport, NSObjectInstanceExports_>
-(UIResolvedShape *) resolvedShapeInContext: (UIShapeResolutionContext *) context ;
@end
@protocol UIShapeProviderClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop