#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UISlider_symbols(JSContext*);
@protocol UISliderInstanceExports<JSExport, NSCodingInstanceExports_>
@property (nonatomic) float value;
@property (nonatomic) float minimumValue;
@property (nonatomic) float maximumValue;
@property (nonatomic,strong) UIImage * minimumValueImage;
@property (nonatomic,strong) UIImage * maximumValueImage;
@property (getter=isContinuous,nonatomic) BOOL continuous;
@property (nonatomic,strong) UIColor * minimumTrackTintColor;
@property (nonatomic,strong) UIColor * maximumTrackTintColor;
@property (nonatomic,strong) UIColor * thumbTintColor;
@property (readonly,nonatomic) UIImage * currentThumbImage;
@property (readonly,nonatomic) UIImage * currentMinimumTrackImage;
@property (readonly,nonatomic) UIImage * currentMaximumTrackImage;
-(void) setValue: (float) value animated: (BOOL) animated ;
-(void) setThumbImage: (UIImage *) image forState: (UIControlState) state ;
-(void) setMinimumTrackImage: (UIImage *) image forState: (UIControlState) state ;
-(void) setMaximumTrackImage: (UIImage *) image forState: (UIControlState) state ;
-(UIImage *) thumbImageForState: (UIControlState) state ;
-(UIImage *) minimumTrackImageForState: (UIControlState) state ;
-(UIImage *) maximumTrackImageForState: (UIControlState) state ;
-(CGRect) minimumValueImageRectForBounds: (CGRect) bounds ;
-(CGRect) maximumValueImageRectForBounds: (CGRect) bounds ;
-(CGRect) trackRectForBounds: (CGRect) bounds ;
-(CGRect) thumbRectForBounds: (CGRect) bounds trackRect: (CGRect) rect value: (float) value ;
@end
@protocol UISliderClassExports<JSExport, NSCodingClassExports_>
@end
#pragma clang diagnostic pop