#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UISplitViewController_symbols(JSContext*);
@protocol UISplitViewControllerInstanceExports<JSExport>
@property (readonly,nonatomic) UISplitViewControllerStyle style;
@property (nonatomic,weak) id delegate;
@property (nonatomic) BOOL showsSecondaryOnlyButton;
@property (nonatomic) UISplitViewControllerSplitBehavior preferredSplitBehavior;
@property (readonly,nonatomic) UISplitViewControllerSplitBehavior splitBehavior;
@property (copy,nonatomic) NSArray * viewControllers;
@property (nonatomic) BOOL presentsWithGesture;
@property (getter=isCollapsed,readonly,nonatomic) BOOL collapsed;
@property (nonatomic) UISplitViewControllerDisplayMode preferredDisplayMode;
@property (readonly,nonatomic) UISplitViewControllerDisplayMode displayMode;
@property (readonly,nonatomic) UIBarButtonItem * displayModeButtonItem;
@property (nonatomic) UISplitViewControllerDisplayModeButtonVisibility displayModeButtonVisibility;
@property (assign,nonatomic) CGFloat preferredPrimaryColumnWidthFraction;
@property (assign,nonatomic) CGFloat preferredPrimaryColumnWidth;
@property (assign,nonatomic) CGFloat minimumPrimaryColumnWidth;
@property (assign,nonatomic) CGFloat maximumPrimaryColumnWidth;
@property (readonly,nonatomic) CGFloat primaryColumnWidth;
@property (assign,nonatomic) CGFloat preferredSupplementaryColumnWidthFraction;
@property (assign,nonatomic) CGFloat preferredSupplementaryColumnWidth;
@property (assign,nonatomic) CGFloat minimumSupplementaryColumnWidth;
@property (assign,nonatomic) CGFloat maximumSupplementaryColumnWidth;
@property (readonly,nonatomic) CGFloat supplementaryColumnWidth;
@property (nonatomic) UISplitViewControllerPrimaryEdge primaryEdge;
@property (nonatomic) UISplitViewControllerBackgroundStyle primaryBackgroundStyle;
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
JSExportAs(initWithNibNameBundle,
-(id) jsinitWithNibName: (NSString *) nibNameOrNil bundle: (NSBundle *) nibBundleOrNil );
JSExportAs(initWithStyle,
-(id) jsinitWithStyle: (UISplitViewControllerStyle) style );
-(void) setViewController: (UIViewController *) vc forColumn: (UISplitViewControllerColumn) column ;
-(__kindof UIViewController *) viewControllerForColumn: (UISplitViewControllerColumn) column ;
-(void) hideColumn: (UISplitViewControllerColumn) column ;
-(void) showColumn: (UISplitViewControllerColumn) column ;
-(void) showViewController: (UIViewController *) vc sender: (id) sender ;
-(void) showDetailViewController: (UIViewController *) vc sender: (id) sender ;
@end
@protocol UISplitViewControllerClassExports<JSExport>
@end
@protocol UIViewControllerUISplitViewControllerCategoryInstanceExports<JSExport>
@property (readonly,nonatomic,strong) UISplitViewController * splitViewController;
-(void) collapseSecondaryViewController: (UIViewController *) secondaryViewController forSplitViewController: (UISplitViewController *) splitViewController ;
-(UIViewController *) separateSecondaryViewControllerForSplitViewController: (UISplitViewController *) splitViewController ;
@end
@protocol UIViewControllerUISplitViewControllerCategoryClassExports<JSExport>
@end
@protocol UISplitViewControllerDelegateInstanceExports_<JSExport>
-(void) splitViewController: (UISplitViewController *) svc willChangeToDisplayMode: (UISplitViewControllerDisplayMode) displayMode ;
-(UISplitViewControllerDisplayMode) targetDisplayModeForActionInSplitViewController: (UISplitViewController *) svc ;
-(BOOL) splitViewController: (UISplitViewController *) splitViewController showViewController: (UIViewController *) vc sender: (id) sender ;
-(BOOL) splitViewController: (UISplitViewController *) splitViewController showDetailViewController: (UIViewController *) vc sender: (id) sender ;
-(UIViewController *) primaryViewControllerForCollapsingSplitViewController: (UISplitViewController *) splitViewController ;
-(UIViewController *) primaryViewControllerForExpandingSplitViewController: (UISplitViewController *) splitViewController ;
-(BOOL) splitViewController: (UISplitViewController *) splitViewController collapseSecondaryViewController: (UIViewController *) secondaryViewController ontoPrimaryViewController: (UIViewController *) primaryViewController ;
-(UIViewController *) splitViewController: (UISplitViewController *) splitViewController separateSecondaryViewControllerFromPrimaryViewController: (UIViewController *) primaryViewController ;
-(UIInterfaceOrientationMask) splitViewControllerSupportedInterfaceOrientations: (UISplitViewController *) splitViewController ;
-(UIInterfaceOrientation) splitViewControllerPreferredInterfaceOrientationForPresentation: (UISplitViewController *) splitViewController ;
-(void) splitViewController: (UISplitViewController *) svc willHideViewController: (UIViewController *) aViewController withBarButtonItem: (UIBarButtonItem *) barButtonItem forPopoverController: (UIPopoverController *) pc ;
-(void) splitViewController: (UISplitViewController *) svc willShowViewController: (UIViewController *) aViewController invalidatingBarButtonItem: (UIBarButtonItem *) barButtonItem ;
-(void) splitViewController: (UISplitViewController *) svc popoverController: (UIPopoverController *) pc willPresentViewController: (UIViewController *) aViewController ;
-(BOOL) splitViewController: (UISplitViewController *) svc shouldHideViewController: (UIViewController *) vc inOrientation: (UIInterfaceOrientation) orientation ;
-(UISplitViewControllerColumn) splitViewController: (UISplitViewController *) svc topColumnForCollapsingToProposedTopColumn: (UISplitViewControllerColumn) proposedTopColumn ;
-(UISplitViewControllerDisplayMode) splitViewController: (UISplitViewController *) svc displayModeForExpandingToProposedDisplayMode: (UISplitViewControllerDisplayMode) proposedDisplayMode ;
-(void) splitViewControllerDidCollapse: (UISplitViewController *) svc ;
-(void) splitViewControllerDidExpand: (UISplitViewController *) svc ;
-(void) splitViewController: (UISplitViewController *) svc willShowColumn: (UISplitViewControllerColumn) column ;
-(void) splitViewController: (UISplitViewController *) svc willHideColumn: (UISplitViewControllerColumn) column ;
-(void) splitViewControllerInteractivePresentationGestureWillBegin: (UISplitViewController *) svc ;
-(void) splitViewControllerInteractivePresentationGestureDidEnd: (UISplitViewController *) svc ;
@end
@protocol UISplitViewControllerDelegateClassExports_<JSExport>
@end
#pragma clang diagnostic pop