#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIStoryboardSegue_symbols(JSContext*);
@protocol UIStoryboardSegueInstanceExports<JSExport>
@property (readonly,copy,nonatomic) NSString * identifier;
@property (readonly,nonatomic) __kindof UIViewController * sourceViewController;
@property (readonly,nonatomic) __kindof UIViewController * destinationViewController;
JSExportAs(initWithIdentifierSourceDestination,
-(id) jsinitWithIdentifier: (NSString *) identifier source: (UIViewController *) source destination: (UIViewController *) destination );
-(void) perform;
@end
@protocol UIStoryboardSegueClassExports<JSExport>
JSExportAs(segueWithIdentifierSourceDestinationPerformHandler,
+(id) jssegueWithIdentifier: (NSString *) identifier source: (UIViewController *) source destination: (UIViewController *) destination performHandler: (JSValue *) performHandler );
@end
@protocol UIStoryboardUnwindSegueSourceInstanceExports<JSExport>
@property (readonly) UIViewController * sourceViewController;
@property (readonly,getter=getJsUnwindAction) NSString* jsunwindAction;
@property (readonly) id sender;
@end
@protocol UIStoryboardUnwindSegueSourceClassExports<JSExport>
@end
#pragma clang diagnostic pop