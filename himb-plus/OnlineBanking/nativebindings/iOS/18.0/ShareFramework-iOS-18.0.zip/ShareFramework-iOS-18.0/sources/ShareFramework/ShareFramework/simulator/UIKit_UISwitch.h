#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UISwitch_symbols(JSContext*);
@protocol UISwitchInstanceExports<JSExport, NSCodingInstanceExports_>
@property (nonatomic,strong) UIColor * onTintColor;
@property (nonatomic,strong) UIColor * thumbTintColor;
@property (nonatomic,strong) UIImage * onImage;
@property (nonatomic,strong) UIImage * offImage;
@property (copy,nonatomic) NSString * title;
@property (readonly,nonatomic) UISwitchStyle style;
@property (nonatomic) UISwitchStyle preferredStyle;
@property (getter=isOn,nonatomic) BOOL on;
JSExportAs(initWithFrame,
-(id) jsinitWithFrame: (CGRect) frame );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
-(void) setOn: (BOOL) on animated: (BOOL) animated ;
@end
@protocol UISwitchClassExports<JSExport, NSCodingClassExports_>
@end
#pragma clang diagnostic pop