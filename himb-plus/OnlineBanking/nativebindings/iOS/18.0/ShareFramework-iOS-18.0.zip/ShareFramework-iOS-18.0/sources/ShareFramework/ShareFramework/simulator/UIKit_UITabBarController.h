#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UITabBarController_symbols(JSContext*);
@protocol UITabBarControllerInstanceExports<JSExport, UITabBarDelegateInstanceExports_, NSCodingInstanceExports_>
@property (copy,nonatomic) NSArray * viewControllers;
@property (assign,nonatomic) __kindof UIViewController * selectedViewController;
@property (nonatomic) NSUInteger selectedIndex;
@property (readonly,nonatomic) UINavigationController * moreNavigationController;
@property (copy,nonatomic) NSArray * customizableViewControllers;
@property (readonly,nonatomic) UITabBar * tabBar;
@property (nonatomic,weak) id delegate;
-(void) setViewControllers: (NSArray *) viewControllers animated: (BOOL) animated ;
@end
@protocol UITabBarControllerClassExports<JSExport, UITabBarDelegateClassExports_, NSCodingClassExports_>
@end
@protocol UIViewControllerUITabBarControllerItemCategoryInstanceExports<JSExport>
@property (nonatomic,strong) UITabBarItem * tabBarItem;
@property (readonly,nonatomic,strong) UITabBarController * tabBarController;
@end
@protocol UIViewControllerUITabBarControllerItemCategoryClassExports<JSExport>
@end
@protocol UITabBarControllerDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(BOOL) tabBarController: (UITabBarController *) tabBarController shouldSelectViewController: (UIViewController *) viewController ;
-(void) tabBarController: (UITabBarController *) tabBarController didSelectViewController: (UIViewController *) viewController ;
-(void) tabBarController: (UITabBarController *) tabBarController willBeginCustomizingViewControllers: (NSArray *) viewControllers ;
-(void) tabBarController: (UITabBarController *) tabBarController willEndCustomizingViewControllers: (NSArray *) viewControllers changed: (BOOL) changed ;
-(void) tabBarController: (UITabBarController *) tabBarController didEndCustomizingViewControllers: (NSArray *) viewControllers changed: (BOOL) changed ;
-(UIInterfaceOrientationMask) tabBarControllerSupportedInterfaceOrientations: (UITabBarController *) tabBarController ;
-(UIInterfaceOrientation) tabBarControllerPreferredInterfaceOrientationForPresentation: (UITabBarController *) tabBarController ;
-(id) tabBarController: (UITabBarController *) tabBarController interactionControllerForAnimationController: (id) animationController ;
-(id) tabBarController: (UITabBarController *) tabBarController animationControllerForTransitionFromViewController: (UIViewController *) fromVC toViewController: (UIViewController *) toVC ;
@end
@protocol UITabBarControllerDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop