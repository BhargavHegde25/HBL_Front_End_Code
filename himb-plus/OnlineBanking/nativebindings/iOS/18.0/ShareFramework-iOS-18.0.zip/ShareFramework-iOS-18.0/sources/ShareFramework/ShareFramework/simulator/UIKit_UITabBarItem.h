#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UITabBarItem_symbols(JSContext*);
@protocol UITabBarItemInstanceExports<JSExport>
@property (nonatomic,strong) UIImage * selectedImage;
@property (copy,nonatomic) NSString * badgeValue;
@property (assign,readwrite,nonatomic) UIOffset titlePositionAdjustment;
@property (readwrite,copy,nonatomic) UIColor * badgeColor;
@property (readwrite,copy,nonatomic) UITabBarAppearance * standardAppearance;
@property (readwrite,copy,nonatomic) UITabBarAppearance * scrollEdgeAppearance;
-(id) jsinit;
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
JSExportAs(initWithTitleImageTag,
-(id) jsinitWithTitle: (NSString *) title image: (UIImage *) image tag: (NSInteger) tag );
JSExportAs(initWithTitleImageSelectedImage,
-(id) jsinitWithTitle: (NSString *) title image: (UIImage *) image selectedImage: (UIImage *) selectedImage );
JSExportAs(initWithTabBarSystemItemTag,
-(id) jsinitWithTabBarSystemItem: (UITabBarSystemItem) systemItem tag: (NSInteger) tag );
-(void) setFinishedSelectedImage: (UIImage *) selectedImage withFinishedUnselectedImage: (UIImage *) unselectedImage ;
-(UIImage *) finishedSelectedImage;
-(UIImage *) finishedUnselectedImage;
-(void) setBadgeTextAttributes: (NSDictionary *) textAttributes forState: (UIControlState) state ;
-(NSDictionary *) badgeTextAttributesForState: (UIControlState) state ;
@end
@protocol UITabBarItemClassExports<JSExport>
@end
@protocol UITabBarItemSpringLoadingCategoryInstanceExports<JSExport, UISpringLoadedInteractionSupportingInstanceExports_>
@end
@protocol UITabBarItemSpringLoadingCategoryClassExports<JSExport, UISpringLoadedInteractionSupportingClassExports_>
@end
#pragma clang diagnostic pop