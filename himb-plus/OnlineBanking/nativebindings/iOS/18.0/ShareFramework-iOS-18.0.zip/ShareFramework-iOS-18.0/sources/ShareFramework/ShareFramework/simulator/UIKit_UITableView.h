#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UITableView_symbols(JSContext*);
@protocol UITableViewRowActionInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (readonly,nonatomic) UITableViewRowActionStyle style;
@property (copy,nonatomic) NSString * title;
@property (copy,nonatomic) UIColor * backgroundColor;
@property (copy,nonatomic) UIVisualEffect * backgroundEffect;
@end
@protocol UITableViewRowActionClassExports<JSExport, NSCopyingClassExports_>
JSExportAs(rowActionWithStyleTitleHandler,
+(id) jsrowActionWithStyle: (UITableViewRowActionStyle) style title: (NSString *) title handler: (JSValue *) handler );
@end
@protocol UITableViewFocusUpdateContextInstanceExports<JSExport>
@property (readonly,nonatomic,strong) NSIndexPath * previouslyFocusedIndexPath;
@property (readonly,nonatomic,strong) NSIndexPath * nextFocusedIndexPath;
@end
@protocol UITableViewFocusUpdateContextClassExports<JSExport>
@end
@protocol UITableViewInstanceExports<JSExport, NSCodingInstanceExports_, UIDataSourceTranslatingInstanceExports_>
@property (readonly,nonatomic) UITableViewStyle style;
@property (nonatomic,weak) id dataSource;
@property (nonatomic,weak) id delegate;
@property (nonatomic,weak) id prefetchDataSource;
@property (getter=isPrefetchingEnabled,nonatomic) BOOL prefetchingEnabled;
@property (nonatomic,weak) id dragDelegate;
@property (nonatomic,weak) id dropDelegate;
@property (nonatomic) CGFloat rowHeight;
@property (nonatomic) CGFloat sectionHeaderHeight;
@property (nonatomic) CGFloat sectionFooterHeight;
@property (nonatomic) CGFloat estimatedRowHeight;
@property (nonatomic) CGFloat estimatedSectionHeaderHeight;
@property (nonatomic) CGFloat estimatedSectionFooterHeight;
@property (nonatomic) CGFloat fillerRowHeight;
@property (nonatomic) CGFloat sectionHeaderTopPadding;
@property (nonatomic) UIEdgeInsets separatorInset;
@property (nonatomic) UITableViewSeparatorInsetReference separatorInsetReference;
@property (nonatomic) UITableViewSelfSizingInvalidation selfSizingInvalidation;
@property (nonatomic,strong) UIView * backgroundView;
@property (readonly,nonatomic) UIContextMenuInteraction * contextMenuInteraction;
@property (readonly,nonatomic) NSInteger numberOfSections;
@property (readonly,nonatomic) NSArray * visibleCells;
@property (readonly,nonatomic) NSArray * indexPathsForVisibleRows;
@property (readonly,nonatomic) BOOL hasUncommittedUpdates;
@property (getter=isEditing,nonatomic) BOOL editing;
@property (nonatomic) BOOL allowsSelection;
@property (nonatomic) BOOL allowsSelectionDuringEditing;
@property (nonatomic) BOOL allowsMultipleSelection;
@property (nonatomic) BOOL allowsMultipleSelectionDuringEditing;
@property (readonly,nonatomic) NSIndexPath * indexPathForSelectedRow;
@property (readonly,nonatomic) NSArray * indexPathsForSelectedRows;
@property (nonatomic) NSInteger sectionIndexMinimumDisplayRowCount;
@property (nonatomic,strong) UIColor * sectionIndexColor;
@property (nonatomic,strong) UIColor * sectionIndexBackgroundColor;
@property (nonatomic,strong) UIColor * sectionIndexTrackingBackgroundColor;
@property (nonatomic) UITableViewCellSeparatorStyle separatorStyle;
@property (nonatomic,strong) UIColor * separatorColor;
@property (copy,nonatomic) UIVisualEffect * separatorEffect;
@property (nonatomic) BOOL cellLayoutMarginsFollowReadableWidth;
@property (nonatomic) BOOL insetsContentViewsToSafeArea;
@property (nonatomic,strong) UIView * tableHeaderView;
@property (nonatomic,strong) UIView * tableFooterView;
@property (nonatomic) BOOL remembersLastFocusedIndexPath;
@property (nonatomic) BOOL selectionFollowsFocus;
@property (nonatomic) BOOL allowsFocus;
@property (nonatomic) BOOL allowsFocusDuringEditing;
@property (nonatomic) BOOL dragInteractionEnabled;
@property (readonly,nonatomic) BOOL hasActiveDrag;
@property (readonly,nonatomic) BOOL hasActiveDrop;
JSExportAs(initWithFrameStyle,
-(id) jsinitWithFrame: (CGRect) frame style: (UITableViewStyle) style );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
-(NSInteger) numberOfRowsInSection: (NSInteger) section ;
-(CGRect) rectForSection: (NSInteger) section ;
-(CGRect) rectForHeaderInSection: (NSInteger) section ;
-(CGRect) rectForFooterInSection: (NSInteger) section ;
-(CGRect) rectForRowAtIndexPath: (NSIndexPath *) indexPath ;
-(NSIndexPath *) indexPathForRowAtPoint: (CGPoint) point ;
-(NSIndexPath *) indexPathForCell: (UITableViewCell *) cell ;
-(NSArray *) indexPathsForRowsInRect: (CGRect) rect ;
-(__kindof UITableViewCell *) cellForRowAtIndexPath: (NSIndexPath *) indexPath ;
-(UITableViewHeaderFooterView *) headerViewForSection: (NSInteger) section ;
-(UITableViewHeaderFooterView *) footerViewForSection: (NSInteger) section ;
-(void) scrollToRowAtIndexPath: (NSIndexPath *) indexPath atScrollPosition: (UITableViewScrollPosition) scrollPosition animated: (BOOL) animated ;
-(void) scrollToNearestSelectedRowAtScrollPosition: (UITableViewScrollPosition) scrollPosition animated: (BOOL) animated ;
JSExportAs(performBatchUpdatesCompletion,
-(void) jsperformBatchUpdates: (JSValue *) updates completion: (JSValue *) completion );
-(void) beginUpdates;
-(void) endUpdates;
-(void) insertSections: (NSIndexSet *) sections withRowAnimation: (UITableViewRowAnimation) animation ;
-(void) deleteSections: (NSIndexSet *) sections withRowAnimation: (UITableViewRowAnimation) animation ;
-(void) moveSection: (NSInteger) section toSection: (NSInteger) newSection ;
-(void) reloadSections: (NSIndexSet *) sections withRowAnimation: (UITableViewRowAnimation) animation ;
-(void) insertRowsAtIndexPaths: (NSArray *) indexPaths withRowAnimation: (UITableViewRowAnimation) animation ;
-(void) deleteRowsAtIndexPaths: (NSArray *) indexPaths withRowAnimation: (UITableViewRowAnimation) animation ;
-(void) moveRowAtIndexPath: (NSIndexPath *) indexPath toIndexPath: (NSIndexPath *) newIndexPath ;
-(void) reloadRowsAtIndexPaths: (NSArray *) indexPaths withRowAnimation: (UITableViewRowAnimation) animation ;
-(void) reconfigureRowsAtIndexPaths: (NSArray *) indexPaths ;
-(void) reloadData;
-(void) reloadSectionIndexTitles;
-(void) setEditing: (BOOL) editing animated: (BOOL) animated ;
-(void) selectRowAtIndexPath: (NSIndexPath *) indexPath animated: (BOOL) animated scrollPosition: (UITableViewScrollPosition) scrollPosition ;
-(void) deselectRowAtIndexPath: (NSIndexPath *) indexPath animated: (BOOL) animated ;
-(__kindof UITableViewCell *) dequeueReusableCellWithIdentifier: (NSString *) identifier ;
-(__kindof UITableViewCell *) dequeueReusableCellWithIdentifier: (NSString *) identifier forIndexPath: (NSIndexPath *) indexPath ;
-(__kindof UITableViewHeaderFooterView *) dequeueReusableHeaderFooterViewWithIdentifier: (NSString *) identifier ;
-(void) registerNib: (UINib *) nib forCellReuseIdentifier: (NSString *) identifier ;
JSExportAs(registerClassForCellReuseIdentifier,
-(void) jsregisterClass: (JSValue *) cellClass forCellReuseIdentifier: (NSString *) identifier );
-(void) registerNib: (UINib *) nib forHeaderFooterViewReuseIdentifier: (NSString *) identifier ;
JSExportAs(registerClassForHeaderFooterViewReuseIdentifier,
-(void) jsregisterClass: (JSValue *) aClass forHeaderFooterViewReuseIdentifier: (NSString *) identifier );
@end
@protocol UITableViewClassExports<JSExport, NSCodingClassExports_, UIDataSourceTranslatingClassExports_>
@end
@protocol UITableViewUIDragAndDropCategoryInstanceExports<JSExport, UISpringLoadedInteractionSupportingInstanceExports_>
@end
@protocol UITableViewUIDragAndDropCategoryClassExports<JSExport, UISpringLoadedInteractionSupportingClassExports_>
@end
@protocol UITableViewDropProposalInstanceExports<JSExport>
@property (readonly,nonatomic) UITableViewDropIntent intent;
JSExportAs(initWithDropOperationIntent,
-(id) jsinitWithDropOperation: (UIDropOperation) operation intent: (UITableViewDropIntent) intent );
@end
@protocol UITableViewDropProposalClassExports<JSExport>
@end
@protocol UITableViewPlaceholderInstanceExports<JSExport>
@property (getter=getJsCellUpdateHandler,setter=setJsCellUpdateHandler:) JSValue* jscellUpdateHandler;
JSExportAs(initWithInsertionIndexPathReuseIdentifierRowHeight,
-(id) jsinitWithInsertionIndexPath: (NSIndexPath *) insertionIndexPath reuseIdentifier: (NSString *) reuseIdentifier rowHeight: (CGFloat) rowHeight );
@end
@protocol UITableViewPlaceholderClassExports<JSExport>
@end
@protocol UITableViewDropPlaceholderInstanceExports<JSExport>
@property (getter=getJsPreviewParametersProvider,setter=setJsPreviewParametersProvider:) JSValue* jspreviewParametersProvider;
@end
@protocol UITableViewDropPlaceholderClassExports<JSExport>
@end
@protocol UITableViewDelegateInstanceExports_<JSExport, NSObjectInstanceExports_, UIScrollViewDelegateInstanceExports_>
-(void) tableView: (UITableView *) tableView willDisplayCell: (UITableViewCell *) cell forRowAtIndexPath: (NSIndexPath *) indexPath ;
-(void) tableView: (UITableView *) tableView willDisplayHeaderView: (UIView *) view forSection: (NSInteger) section ;
-(void) tableView: (UITableView *) tableView willDisplayFooterView: (UIView *) view forSection: (NSInteger) section ;
-(void) tableView: (UITableView *) tableView didEndDisplayingCell: (UITableViewCell *) cell forRowAtIndexPath: (NSIndexPath *) indexPath ;
-(void) tableView: (UITableView *) tableView didEndDisplayingHeaderView: (UIView *) view forSection: (NSInteger) section ;
-(void) tableView: (UITableView *) tableView didEndDisplayingFooterView: (UIView *) view forSection: (NSInteger) section ;
-(CGFloat) tableView: (UITableView *) tableView heightForRowAtIndexPath: (NSIndexPath *) indexPath ;
-(CGFloat) tableView: (UITableView *) tableView heightForHeaderInSection: (NSInteger) section ;
-(CGFloat) tableView: (UITableView *) tableView heightForFooterInSection: (NSInteger) section ;
-(CGFloat) tableView: (UITableView *) tableView estimatedHeightForRowAtIndexPath: (NSIndexPath *) indexPath ;
-(CGFloat) tableView: (UITableView *) tableView estimatedHeightForHeaderInSection: (NSInteger) section ;
-(CGFloat) tableView: (UITableView *) tableView estimatedHeightForFooterInSection: (NSInteger) section ;
-(UIView *) tableView: (UITableView *) tableView viewForHeaderInSection: (NSInteger) section ;
-(UIView *) tableView: (UITableView *) tableView viewForFooterInSection: (NSInteger) section ;
-(UITableViewCellAccessoryType) tableView: (UITableView *) tableView accessoryTypeForRowWithIndexPath: (NSIndexPath *) indexPath ;
-(void) tableView: (UITableView *) tableView accessoryButtonTappedForRowWithIndexPath: (NSIndexPath *) indexPath ;
-(BOOL) tableView: (UITableView *) tableView shouldHighlightRowAtIndexPath: (NSIndexPath *) indexPath ;
-(void) tableView: (UITableView *) tableView didHighlightRowAtIndexPath: (NSIndexPath *) indexPath ;
-(void) tableView: (UITableView *) tableView didUnhighlightRowAtIndexPath: (NSIndexPath *) indexPath ;
-(NSIndexPath *) tableView: (UITableView *) tableView willSelectRowAtIndexPath: (NSIndexPath *) indexPath ;
-(NSIndexPath *) tableView: (UITableView *) tableView willDeselectRowAtIndexPath: (NSIndexPath *) indexPath ;
-(void) tableView: (UITableView *) tableView didSelectRowAtIndexPath: (NSIndexPath *) indexPath ;
-(void) tableView: (UITableView *) tableView didDeselectRowAtIndexPath: (NSIndexPath *) indexPath ;
-(BOOL) tableView: (UITableView *) tableView canPerformPrimaryActionForRowAtIndexPath: (NSIndexPath *) indexPath ;
-(void) tableView: (UITableView *) tableView performPrimaryActionForRowAtIndexPath: (NSIndexPath *) indexPath ;
-(UITableViewCellEditingStyle) tableView: (UITableView *) tableView editingStyleForRowAtIndexPath: (NSIndexPath *) indexPath ;
-(NSString *) tableView: (UITableView *) tableView titleForDeleteConfirmationButtonForRowAtIndexPath: (NSIndexPath *) indexPath ;
-(NSArray *) tableView: (UITableView *) tableView editActionsForRowAtIndexPath: (NSIndexPath *) indexPath ;
-(UISwipeActionsConfiguration *) tableView: (UITableView *) tableView leadingSwipeActionsConfigurationForRowAtIndexPath: (NSIndexPath *) indexPath ;
-(UISwipeActionsConfiguration *) tableView: (UITableView *) tableView trailingSwipeActionsConfigurationForRowAtIndexPath: (NSIndexPath *) indexPath ;
-(BOOL) tableView: (UITableView *) tableView shouldIndentWhileEditingRowAtIndexPath: (NSIndexPath *) indexPath ;
-(void) tableView: (UITableView *) tableView willBeginEditingRowAtIndexPath: (NSIndexPath *) indexPath ;
-(void) tableView: (UITableView *) tableView didEndEditingRowAtIndexPath: (NSIndexPath *) indexPath ;
-(NSIndexPath *) tableView: (UITableView *) tableView targetIndexPathForMoveFromRowAtIndexPath: (NSIndexPath *) sourceIndexPath toProposedIndexPath: (NSIndexPath *) proposedDestinationIndexPath ;
-(NSInteger) tableView: (UITableView *) tableView indentationLevelForRowAtIndexPath: (NSIndexPath *) indexPath ;
-(BOOL) tableView: (UITableView *) tableView shouldShowMenuForRowAtIndexPath: (NSIndexPath *) indexPath ;
JSExportAs(tableViewCanPerformActionForRowAtIndexPathWithSender,
-(BOOL) jstableView: (UITableView *) tableView canPerformAction: (NSString *) action forRowAtIndexPath: (NSIndexPath *) indexPath withSender: (id) sender );
JSExportAs(tableViewPerformActionForRowAtIndexPathWithSender,
-(void) jstableView: (UITableView *) tableView performAction: (NSString *) action forRowAtIndexPath: (NSIndexPath *) indexPath withSender: (id) sender );
-(BOOL) tableView: (UITableView *) tableView canFocusRowAtIndexPath: (NSIndexPath *) indexPath ;
-(BOOL) tableView: (UITableView *) tableView shouldUpdateFocusInContext: (UITableViewFocusUpdateContext *) context ;
-(void) tableView: (UITableView *) tableView didUpdateFocusInContext: (UITableViewFocusUpdateContext *) context withAnimationCoordinator: (UIFocusAnimationCoordinator *) coordinator ;
-(NSIndexPath *) indexPathForPreferredFocusedViewInTableView: (UITableView *) tableView ;
-(BOOL) tableView: (UITableView *) tableView selectionFollowsFocusForRowAtIndexPath: (NSIndexPath *) indexPath ;
-(BOOL) tableView: (UITableView *) tableView shouldSpringLoadRowAtIndexPath: (NSIndexPath *) indexPath withContext: (id) context ;
-(BOOL) tableView: (UITableView *) tableView shouldBeginMultipleSelectionInteractionAtIndexPath: (NSIndexPath *) indexPath ;
-(void) tableView: (UITableView *) tableView didBeginMultipleSelectionInteractionAtIndexPath: (NSIndexPath *) indexPath ;
-(void) tableViewDidEndMultipleSelectionInteraction: (UITableView *) tableView ;
-(UIContextMenuConfiguration *) tableView: (UITableView *) tableView contextMenuConfigurationForRowAtIndexPath: (NSIndexPath *) indexPath point: (CGPoint) point ;
-(UITargetedPreview *) tableView: (UITableView *) tableView previewForHighlightingContextMenuWithConfiguration: (UIContextMenuConfiguration *) configuration ;
-(UITargetedPreview *) tableView: (UITableView *) tableView previewForDismissingContextMenuWithConfiguration: (UIContextMenuConfiguration *) configuration ;
-(void) tableView: (UITableView *) tableView willPerformPreviewActionForMenuWithConfiguration: (UIContextMenuConfiguration *) configuration animator: (id) animator ;
-(void) tableView: (UITableView *) tableView willDisplayContextMenuWithConfiguration: (UIContextMenuConfiguration *) configuration animator: (id) animator ;
-(void) tableView: (UITableView *) tableView willEndContextMenuInteractionWithConfiguration: (UIContextMenuConfiguration *) configuration animator: (id) animator ;
@end
@protocol UITableViewDelegateClassExports_<JSExport, NSObjectClassExports_, UIScrollViewDelegateClassExports_>
@end
@protocol UITableViewDataSourceInstanceExports_<JSExport, NSObjectInstanceExports_>
-(NSInteger) tableView: (UITableView *) tableView numberOfRowsInSection: (NSInteger) section ;
-(UITableViewCell *) tableView: (UITableView *) tableView cellForRowAtIndexPath: (NSIndexPath *) indexPath ;
-(NSInteger) numberOfSectionsInTableView: (UITableView *) tableView ;
-(NSString *) tableView: (UITableView *) tableView titleForHeaderInSection: (NSInteger) section ;
-(NSString *) tableView: (UITableView *) tableView titleForFooterInSection: (NSInteger) section ;
-(BOOL) tableView: (UITableView *) tableView canEditRowAtIndexPath: (NSIndexPath *) indexPath ;
-(BOOL) tableView: (UITableView *) tableView canMoveRowAtIndexPath: (NSIndexPath *) indexPath ;
-(NSArray *) sectionIndexTitlesForTableView: (UITableView *) tableView ;
-(NSInteger) tableView: (UITableView *) tableView sectionForSectionIndexTitle: (NSString *) title atIndex: (NSInteger) index ;
-(void) tableView: (UITableView *) tableView commitEditingStyle: (UITableViewCellEditingStyle) editingStyle forRowAtIndexPath: (NSIndexPath *) indexPath ;
-(void) tableView: (UITableView *) tableView moveRowAtIndexPath: (NSIndexPath *) sourceIndexPath toIndexPath: (NSIndexPath *) destinationIndexPath ;
@end
@protocol UITableViewDataSourceClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UITableViewDataSourcePrefetchingInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) tableView: (UITableView *) tableView prefetchRowsAtIndexPaths: (NSArray *) indexPaths ;
-(void) tableView: (UITableView *) tableView cancelPrefetchingForRowsAtIndexPaths: (NSArray *) indexPaths ;
@end
@protocol UITableViewDataSourcePrefetchingClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UITableViewDragDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(NSArray *) tableView: (UITableView *) tableView itemsForBeginningDragSession: (id) session atIndexPath: (NSIndexPath *) indexPath ;
-(NSArray *) tableView: (UITableView *) tableView itemsForAddingToDragSession: (id) session atIndexPath: (NSIndexPath *) indexPath point: (CGPoint) point ;
-(UIDragPreviewParameters *) tableView: (UITableView *) tableView dragPreviewParametersForRowAtIndexPath: (NSIndexPath *) indexPath ;
-(void) tableView: (UITableView *) tableView dragSessionWillBegin: (id) session ;
-(void) tableView: (UITableView *) tableView dragSessionDidEnd: (id) session ;
-(BOOL) tableView: (UITableView *) tableView dragSessionAllowsMoveOperation: (id) session ;
-(BOOL) tableView: (UITableView *) tableView dragSessionIsRestrictedToDraggingApplication: (id) session ;
@end
@protocol UITableViewDragDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UITableViewDropDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) tableView: (UITableView *) tableView performDropWithCoordinator: (id) coordinator ;
-(BOOL) tableView: (UITableView *) tableView canHandleDropSession: (id) session ;
-(void) tableView: (UITableView *) tableView dropSessionDidEnter: (id) session ;
-(UITableViewDropProposal *) tableView: (UITableView *) tableView dropSessionDidUpdate: (id) session withDestinationIndexPath: (NSIndexPath *) destinationIndexPath ;
-(void) tableView: (UITableView *) tableView dropSessionDidExit: (id) session ;
-(void) tableView: (UITableView *) tableView dropSessionDidEnd: (id) session ;
-(UIDragPreviewParameters *) tableView: (UITableView *) tableView dropPreviewParametersForRowAtIndexPath: (NSIndexPath *) indexPath ;
@end
@protocol UITableViewDropDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UITableViewDropCoordinatorInstanceExports_<JSExport, NSObjectInstanceExports_>
@property (readonly,nonatomic) NSArray * items;
@property (readonly,nonatomic) NSIndexPath * destinationIndexPath;
@property (readonly,nonatomic) UITableViewDropProposal * proposal;
@property (readonly,nonatomic) id session;
-(id) dropItem: (UIDragItem *) dragItem toPlaceholder: (UITableViewDropPlaceholder *) placeholder ;
-(id) dropItem: (UIDragItem *) dragItem toRowAtIndexPath: (NSIndexPath *) indexPath ;
-(id) dropItem: (UIDragItem *) dragItem intoRowAtIndexPath: (NSIndexPath *) indexPath rect: (CGRect) rect ;
-(id) dropItem: (UIDragItem *) dragItem toTarget: (UIDragPreviewTarget *) target ;
@end
@protocol UITableViewDropCoordinatorClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UITableViewDropItemInstanceExports_<JSExport, NSObjectInstanceExports_>
@property (readonly,nonatomic) UIDragItem * dragItem;
@property (readonly,nonatomic) NSIndexPath * sourceIndexPath;
@property (readonly,nonatomic) CGSize previewSize;
@end
@protocol UITableViewDropItemClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UITableViewDropPlaceholderContextInstanceExports_<JSExport, UIDragAnimatingInstanceExports_>
@property (readonly,nonatomic) UIDragItem * dragItem;
JSExportAs(commitInsertionWithDataSourceUpdates,
-(BOOL) jscommitInsertionWithDataSourceUpdates: (JSValue *) dataSourceUpdates );
-(BOOL) deletePlaceholder;
@end
@protocol UITableViewDropPlaceholderContextClassExports_<JSExport, UIDragAnimatingClassExports_>
@end
#pragma clang diagnostic pop