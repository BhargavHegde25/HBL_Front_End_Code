#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UITableViewHeaderFooterView_symbols(JSContext*);
@protocol UITableViewHeaderFooterViewInstanceExports<JSExport>
@property (readonly,nonatomic) UIViewConfigurationState * configurationState;
@property (getter=getJsConfigurationUpdateHandler,setter=setJsConfigurationUpdateHandler:) JSValue* jsconfigurationUpdateHandler;
@property (copy,nonatomic) id contentConfiguration;
@property (nonatomic) BOOL automaticallyUpdatesContentConfiguration;
@property (readonly,nonatomic,strong) UIView * contentView;
@property (readonly,nonatomic,strong) UILabel * textLabel;
@property (readonly,nonatomic,strong) UILabel * detailTextLabel;
@property (copy,nonatomic) UIBackgroundConfiguration * backgroundConfiguration;
@property (nonatomic) BOOL automaticallyUpdatesBackgroundConfiguration;
@property (nonatomic,strong) UIView * backgroundView;
@property (readonly,copy,nonatomic) NSString * reuseIdentifier;
JSExportAs(initWithReuseIdentifier,
-(id) jsinitWithReuseIdentifier: (NSString *) reuseIdentifier );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
-(void) setNeedsUpdateConfiguration;
-(void) updateConfigurationUsingState: (UIViewConfigurationState *) state ;
-(UIListContentConfiguration *) defaultContentConfiguration;
-(UIBackgroundConfiguration *) defaultBackgroundConfiguration;
-(void) prepareForReuse;
@end
@protocol UITableViewHeaderFooterViewClassExports<JSExport>
@end
#pragma clang diagnostic pop