#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UITextInputContext_symbols(JSContext*);
@protocol UITextInputContextInstanceExports<JSExport>
@property (getter=isPencilInputExpected,readwrite,nonatomic) BOOL pencilInputExpected;
@property (getter=isDictationInputExpected,readwrite,nonatomic) BOOL dictationInputExpected;
@property (getter=isHardwareKeyboardInputExpected,readwrite,nonatomic) BOOL hardwareKeyboardInputExpected;
@end
@protocol UITextInputContextClassExports<JSExport>
+(UITextInputContext *) current;
@end
#pragma clang diagnostic pop