#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UITextInputTraits_symbols(JSContext*);
@protocol UITextInputPasswordRulesInstanceExports<JSExport, NSSecureCodingInstanceExports_, NSCopyingInstanceExports_>
@property (readonly,nonatomic) NSString * passwordRulesDescriptor;
@end
@protocol UITextInputPasswordRulesClassExports<JSExport, NSSecureCodingClassExports_, NSCopyingClassExports_>
+(id) passwordRulesWithDescriptor: (NSString *) passwordRulesDescriptor ;
@end
@protocol UITextInputTraitsInstanceExports_<JSExport, NSObjectInstanceExports_>
@property (nonatomic) UITextAutocapitalizationType autocapitalizationType;
@property (nonatomic) UITextAutocorrectionType autocorrectionType;
@property (nonatomic) UITextSpellCheckingType spellCheckingType;
@property (nonatomic) UITextSmartQuotesType smartQuotesType;
@property (nonatomic) UITextSmartDashesType smartDashesType;
@property (nonatomic) UITextSmartInsertDeleteType smartInsertDeleteType;
@property (nonatomic) UITextInlinePredictionType inlinePredictionType;
@property (nonatomic) UIKeyboardType keyboardType;
@property (nonatomic) UIKeyboardAppearance keyboardAppearance;
@property (nonatomic) UIReturnKeyType returnKeyType;
@property (nonatomic) BOOL enablesReturnKeyAutomatically;
@property (getter=isSecureTextEntry,nonatomic) BOOL secureTextEntry;
@property (copy,nonatomic) UITextContentType textContentType;
@property (copy,nonatomic) UITextInputPasswordRules * passwordRules;
@end
@protocol UITextInputTraitsClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop