#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UITextItem_symbols(JSContext*);
@protocol UITextItemInstanceExports<JSExport>
@property (readonly,assign,nonatomic) UITextItemContentType contentType;
@property (readonly,assign,nonatomic) NSRange range;
@property (readonly,nonatomic,strong) NSURL * link;
@property (readonly,nonatomic,strong) NSTextAttachment * textAttachment;
@property (readonly,nonatomic,strong) NSString * tagIdentifier;
@end
@protocol UITextItemClassExports<JSExport>
@end
@protocol UITextItemMenuPreviewInstanceExports<JSExport>
JSExportAs(initWithView,
-(id) jsinitWithView: (UIView *) view );
@end
@protocol UITextItemMenuPreviewClassExports<JSExport>
+(id) defaultPreview;
@end
@protocol UITextItemMenuConfigurationInstanceExports<JSExport>
@end
@protocol UITextItemMenuConfigurationClassExports<JSExport>
+(id) configurationWithMenu: (UIMenu *) menu ;
+(id) configurationWithPreview: (UITextItemMenuPreview *) preview menu: (UIMenu *) menu ;
@end
#pragma clang diagnostic pop