#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UITextPasteDelegate_symbols(JSContext*);
@protocol UITextPasteDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) textPasteConfigurationSupporting: (id) textPasteConfigurationSupporting transformPasteItem: (id) item ;
-(NSAttributedString *) textPasteConfigurationSupporting: (id) textPasteConfigurationSupporting combineItemAttributedStrings: (NSArray *) itemStrings forRange: (UITextRange *) textRange ;
-(UITextRange *) textPasteConfigurationSupporting: (id) textPasteConfigurationSupporting performPasteOfAttributedString: (NSAttributedString *) attributedString toRange: (UITextRange *) textRange ;
-(BOOL) textPasteConfigurationSupporting: (id) textPasteConfigurationSupporting shouldAnimatePasteOfAttributedString: (NSAttributedString *) attributedString toRange: (UITextRange *) textRange ;
@end
@protocol UITextPasteDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UITextPasteItemInstanceExports_<JSExport, NSObjectInstanceExports_>
@property (readonly,nonatomic) __kindof NSItemProvider * itemProvider;
@property (readonly,nonatomic) id localObject;
@property (readonly,nonatomic) NSDictionary * defaultAttributes;
-(void) setStringResult: (NSString *) string ;
-(void) setAttributedStringResult: (NSAttributedString *) string ;
-(void) setAttachmentResult: (NSTextAttachment *) textAttachment ;
-(void) setNoResult;
-(void) setDefaultResult;
@end
@protocol UITextPasteItemClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop