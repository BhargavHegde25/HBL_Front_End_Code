#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UITextView_symbols(JSContext*);
@protocol UITextViewInstanceExports<JSExport, UITextInputInstanceExports_, UIContentSizeCategoryAdjustingInstanceExports_, UILetterformAwareAdjustingInstanceExports_>
@property (nonatomic,weak) id delegate;
@property (copy,nonatomic) NSString * text;
@property (nonatomic,strong) UIFont * font;
@property (nonatomic,strong) UIColor * textColor;
@property (nonatomic) NSTextAlignment textAlignment;
@property (nonatomic) NSRange selectedRange;
@property (getter=isEditable,nonatomic) BOOL editable;
@property (getter=isSelectable,nonatomic) BOOL selectable;
@property (nonatomic) UIDataDetectorTypes dataDetectorTypes;
@property (nonatomic) BOOL allowsEditingTextAttributes;
@property (copy) NSAttributedString * attributedText;
@property (copy,nonatomic) NSDictionary * typingAttributes;
@property (readwrite,strong) UIView * inputView;
@property (readwrite,strong) UIView * inputAccessoryView;
@property (nonatomic) BOOL clearsOnInsertion;
@property (readonly,nonatomic) NSTextContainer * textContainer;
@property (assign,nonatomic) UIEdgeInsets textContainerInset;
@property (readonly,nonatomic) NSTextLayoutManager * textLayoutManager;
@property (readonly,nonatomic) NSLayoutManager * layoutManager;
@property (readonly,nonatomic,strong) NSTextStorage * textStorage;
@property (copy,nonatomic) NSDictionary * linkTextAttributes;
@property (nonatomic) BOOL usesStandardTextScaling;
@property (readonly,nonatomic) UIFindInteraction * findInteraction;
@property (getter=isFindInteractionEnabled,readwrite,nonatomic) BOOL findInteractionEnabled;
@property (nonatomic) UITextViewBorderStyle borderStyle;
-(void) scrollRangeToVisible: (NSRange) range ;
JSExportAs(initWithFrameTextContainer,
-(id) jsinitWithFrame: (CGRect) frame textContainer: (NSTextContainer *) textContainer );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
@end
@protocol UITextViewClassExports<JSExport, UITextInputClassExports_, UIContentSizeCategoryAdjustingClassExports_, UILetterformAwareAdjustingClassExports_>
+(id) textViewUsingTextLayoutManager: (BOOL) usingTextLayoutManager ;
@end
@protocol UITextViewAnonCategoryInstanceExports<JSExport, UITextDraggableInstanceExports_, UITextDroppableInstanceExports_, UITextPasteConfigurationSupportingInstanceExports_, UIFindInteractionDelegateInstanceExports_, UITextSearchingInstanceExports_>
@end
@protocol UITextViewAnonCategoryClassExports<JSExport, UITextDraggableClassExports_, UITextDroppableClassExports_, UITextPasteConfigurationSupportingClassExports_, UIFindInteractionDelegateClassExports_, UITextSearchingClassExports_>
@end
@protocol UITextViewUIInteractionStateRestorableCategoryInstanceExports<JSExport>
@property (copy,nonatomic) id interactionState;
@end
@protocol UITextViewUIInteractionStateRestorableCategoryClassExports<JSExport>
@end
@protocol UITextViewDelegateInstanceExports_<JSExport, NSObjectInstanceExports_, UIScrollViewDelegateInstanceExports_>
-(BOOL) textViewShouldBeginEditing: (UITextView *) textView ;
-(BOOL) textViewShouldEndEditing: (UITextView *) textView ;
-(void) textViewDidBeginEditing: (UITextView *) textView ;
-(void) textViewDidEndEditing: (UITextView *) textView ;
-(BOOL) textView: (UITextView *) textView shouldChangeTextInRange: (NSRange) range replacementText: (NSString *) text ;
-(void) textViewDidChange: (UITextView *) textView ;
-(void) textViewDidChangeSelection: (UITextView *) textView ;
-(UIMenu *) textView: (UITextView *) textView editMenuForTextInRange: (NSRange) range suggestedActions: (NSArray *) suggestedActions ;
-(void) textView: (UITextView *) textView willPresentEditMenuWithAnimator: (id) animator ;
-(void) textView: (UITextView *) textView willDismissEditMenuWithAnimator: (id) animator ;
-(UIAction *) textView: (UITextView *) textView primaryActionForTextItem: (UITextItem *) textItem defaultAction: (UIAction *) defaultAction ;
-(UITextItemMenuConfiguration *) textView: (UITextView *) textView menuConfigurationForTextItem: (UITextItem *) textItem defaultMenu: (UIMenu *) defaultMenu ;
-(void) textView: (UITextView *) textView textItemMenuWillDisplayForTextItem: (UITextItem *) textItem animator: (id) animator ;
-(void) textView: (UITextView *) textView textItemMenuWillEndForTextItem: (UITextItem *) textItem animator: (id) animator ;
-(BOOL) textView: (UITextView *) textView shouldInteractWithURL: (NSURL *) URL inRange: (NSRange) characterRange interaction: (UITextItemInteraction) interaction ;
-(BOOL) textView: (UITextView *) textView shouldInteractWithTextAttachment: (NSTextAttachment *) textAttachment inRange: (NSRange) characterRange interaction: (UITextItemInteraction) interaction ;
-(BOOL) textView: (UITextView *) textView shouldInteractWithURL: (NSURL *) URL inRange: (NSRange) characterRange ;
-(BOOL) textView: (UITextView *) textView shouldInteractWithTextAttachment: (NSTextAttachment *) textAttachment inRange: (NSRange) characterRange ;
@end
@protocol UITextViewDelegateClassExports_<JSExport, NSObjectClassExports_, UIScrollViewDelegateClassExports_>
@end
#pragma clang diagnostic pop