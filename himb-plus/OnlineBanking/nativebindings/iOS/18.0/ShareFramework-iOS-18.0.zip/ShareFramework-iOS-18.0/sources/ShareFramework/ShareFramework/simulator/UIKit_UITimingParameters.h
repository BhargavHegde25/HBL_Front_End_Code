#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UITimingParameters_symbols(JSContext*);
@protocol UICubicTimingParametersInstanceExports<JSExport, UITimingCurveProviderInstanceExports_>
@property (readonly,nonatomic) UIViewAnimationCurve animationCurve;
@property (readonly,nonatomic) CGPoint controlPoint1;
@property (readonly,nonatomic) CGPoint controlPoint2;
-(id) jsinit;
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
JSExportAs(initWithAnimationCurve,
-(id) jsinitWithAnimationCurve: (UIViewAnimationCurve) curve );
JSExportAs(initWithControlPoint1ControlPoint2,
-(id) jsinitWithControlPoint1: (CGPoint) point1 controlPoint2: (CGPoint) point2 );
@end
@protocol UICubicTimingParametersClassExports<JSExport, UITimingCurveProviderClassExports_>
@end
@protocol UISpringTimingParametersInstanceExports<JSExport, UITimingCurveProviderInstanceExports_>
@property (readonly,nonatomic) CGVector initialVelocity;
-(id) jsinit;
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
JSExportAs(initWithDampingRatioInitialVelocity,
-(id) jsinitWithDampingRatio: (CGFloat) ratio initialVelocity: (CGVector) velocity );
JSExportAs(initWithMassStiffnessDampingInitialVelocity,
-(id) jsinitWithMass: (CGFloat) mass stiffness: (CGFloat) stiffness damping: (CGFloat) damping initialVelocity: (CGVector) velocity );
JSExportAs(initWithDampingRatio,
-(id) jsinitWithDampingRatio: (CGFloat) ratio );
JSExportAs(initWithDurationBounceInitialVelocity,
-(id) jsinitWithDuration: (NSTimeInterval) duration bounce: (CGFloat) bounce initialVelocity: (CGVector) velocity );
JSExportAs(initWithDurationBounce,
-(id) jsinitWithDuration: (NSTimeInterval) duration bounce: (CGFloat) bounce );
@end
@protocol UISpringTimingParametersClassExports<JSExport, UITimingCurveProviderClassExports_>
@end
#pragma clang diagnostic pop