#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIToolTipInteraction_symbols(JSContext*);
@protocol UIToolTipInteractionInstanceExports<JSExport, UIInteractionInstanceExports_>
@property (nonatomic,weak) id delegate;
@property (getter=isEnabled,nonatomic) BOOL enabled;
@property (copy,nonatomic) NSString * defaultToolTip;
-(id) jsinit;
JSExportAs(initWithDefaultToolTip,
-(id) jsinitWithDefaultToolTip: (NSString *) defaultToolTip );
@end
@protocol UIToolTipInteractionClassExports<JSExport, UIInteractionClassExports_>
@end
@protocol UIToolTipConfigurationInstanceExports<JSExport>
@property (readonly,copy,nonatomic) NSString * toolTip;
@property (readonly,nonatomic) CGRect sourceRect;
@end
@protocol UIToolTipConfigurationClassExports<JSExport>
+(id) configurationWithToolTip: (NSString *) toolTip ;
+(id) configurationWithToolTip: (NSString *) toolTip inRect: (CGRect) sourceRect ;
@end
@protocol UIToolTipInteractionDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(UIToolTipConfiguration *) toolTipInteraction: (UIToolTipInteraction *) interaction configurationAtPoint: (CGPoint) point ;
@end
@protocol UIToolTipInteractionDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop