#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIToolbar_symbols(JSContext*);
@protocol UIToolbarInstanceExports<JSExport, UIBarPositioningInstanceExports_>
@property (nonatomic) UIBarStyle barStyle;
@property (copy,nonatomic) NSArray * items;
@property (getter=isTranslucent,assign,nonatomic) BOOL translucent;
@property (nonatomic,strong) UIColor * tintColor;
@property (nonatomic,strong) UIColor * barTintColor;
@property (readwrite,copy,nonatomic) UIToolbarAppearance * standardAppearance;
@property (readwrite,copy,nonatomic) UIToolbarAppearance * compactAppearance;
@property (readwrite,copy,nonatomic) UIToolbarAppearance * scrollEdgeAppearance;
@property (readwrite,copy,nonatomic) UIToolbarAppearance * compactScrollEdgeAppearance;
@property (nonatomic,weak) id delegate;
-(void) setItems: (NSArray *) items animated: (BOOL) animated ;
-(void) setBackgroundImage: (UIImage *) backgroundImage forToolbarPosition: (UIBarPosition) topOrBottom barMetrics: (UIBarMetrics) barMetrics ;
-(UIImage *) backgroundImageForToolbarPosition: (UIBarPosition) topOrBottom barMetrics: (UIBarMetrics) barMetrics ;
-(void) setShadowImage: (UIImage *) shadowImage forToolbarPosition: (UIBarPosition) topOrBottom ;
-(UIImage *) shadowImageForToolbarPosition: (UIBarPosition) topOrBottom ;
@end
@protocol UIToolbarClassExports<JSExport, UIBarPositioningClassExports_>
@end
@protocol UIToolbarDelegateInstanceExports_<JSExport, UIBarPositioningDelegateInstanceExports_>
@end
@protocol UIToolbarDelegateClassExports_<JSExport, UIBarPositioningDelegateClassExports_>
@end
#pragma clang diagnostic pop