#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UITrackingLayoutGuide_symbols(JSContext*);
@protocol UITrackingLayoutGuideInstanceExports<JSExport>
-(void) setConstraints: (NSArray *) trackingConstraints activeWhenNearEdge: (NSDirectionalRectEdge) edge ;
-(NSArray *) constraintsActiveWhenNearEdge: (NSDirectionalRectEdge) edge ;
-(void) setConstraints: (NSArray *) trackingConstraints activeWhenAwayFromEdge: (NSDirectionalRectEdge) edge ;
-(NSArray *) constraintsActiveWhenAwayFromEdge: (NSDirectionalRectEdge) edge ;
-(void) removeAllTrackedConstraints;
@end
@protocol UITrackingLayoutGuideClassExports<JSExport>
@end
#pragma clang diagnostic pop