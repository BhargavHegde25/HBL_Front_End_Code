#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIUserNotificationSettings_symbols(JSContext*);
@protocol UIUserNotificationSettingsInstanceExports<JSExport>
@property (readonly,nonatomic) UIUserNotificationType types;
@property (readonly,copy,nonatomic) NSSet * categories;
@end
@protocol UIUserNotificationSettingsClassExports<JSExport>
+(id) settingsForTypes: (UIUserNotificationType) types categories: (NSSet *) categories ;
@end
@protocol UIUserNotificationCategoryInstanceExports<JSExport, NSCopyingInstanceExports_, NSMutableCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,copy,nonatomic) NSString * identifier;
-(id) jsinit;
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
-(NSArray *) actionsForContext: (UIUserNotificationActionContext) context ;
@end
@protocol UIUserNotificationCategoryClassExports<JSExport, NSCopyingClassExports_, NSMutableCopyingClassExports_, NSSecureCodingClassExports_>
@end
@protocol UIMutableUserNotificationCategoryInstanceExports<JSExport>
@property (copy,nonatomic) NSString * identifier;
-(void) setActions: (NSArray *) actions forContext: (UIUserNotificationActionContext) context ;
@end
@protocol UIMutableUserNotificationCategoryClassExports<JSExport>
@end
@protocol UIUserNotificationActionInstanceExports<JSExport, NSCopyingInstanceExports_, NSMutableCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,copy,nonatomic) NSString * identifier;
@property (readonly,copy,nonatomic) NSString * title;
@property (readonly,assign,nonatomic) UIUserNotificationActionBehavior behavior;
@property (readonly,copy,nonatomic) NSDictionary * parameters;
@property (readonly,assign,nonatomic) UIUserNotificationActivationMode activationMode;
@property (getter=isAuthenticationRequired,readonly,assign,nonatomic) BOOL authenticationRequired;
@property (getter=isDestructive,readonly,assign,nonatomic) BOOL destructive;
-(id) jsinit;
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
@end
@protocol UIUserNotificationActionClassExports<JSExport, NSCopyingClassExports_, NSMutableCopyingClassExports_, NSSecureCodingClassExports_>
@end
@protocol UIMutableUserNotificationActionInstanceExports<JSExport>
@property (copy,nonatomic) NSString * identifier;
@property (copy,nonatomic) NSString * title;
@property (assign,nonatomic) UIUserNotificationActionBehavior behavior;
@property (copy,nonatomic) NSDictionary * parameters;
@property (assign,nonatomic) UIUserNotificationActivationMode activationMode;
@property (getter=isAuthenticationRequired,assign,nonatomic) BOOL authenticationRequired;
@property (getter=isDestructive,assign,nonatomic) BOOL destructive;
@end
@protocol UIMutableUserNotificationActionClassExports<JSExport>
@end
#pragma clang diagnostic pop