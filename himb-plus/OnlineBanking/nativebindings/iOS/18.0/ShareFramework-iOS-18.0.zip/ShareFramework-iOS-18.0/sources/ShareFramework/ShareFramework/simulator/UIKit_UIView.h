#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIView_symbols(JSContext*);
@protocol UIViewInstanceExports<JSExport, NSCodingInstanceExports_, UIAppearanceInstanceExports_, UIAppearanceContainerInstanceExports_, UIDynamicItemInstanceExports_, UITraitEnvironmentInstanceExports_, UICoordinateSpaceInstanceExports_, UIFocusItemInstanceExports_, UIFocusItemContainerInstanceExports_, CALayerDelegateInstanceExports_>
@property (getter=isUserInteractionEnabled,nonatomic) BOOL userInteractionEnabled;
@property (nonatomic) NSInteger tag;
@property (readonly,nonatomic,strong) CALayer * layer;
@property (readonly,nonatomic) BOOL canBecomeFocused;
@property (getter=isFocused,readonly,nonatomic) BOOL focused;
@property (readwrite,copy,nonatomic) NSString * focusGroupIdentifier;
@property (readwrite,copy,nonatomic) UIFocusEffect * focusEffect;
@property (nonatomic) UISemanticContentAttribute semanticContentAttribute;
@property (readonly,nonatomic) UIUserInterfaceLayoutDirection effectiveUserInterfaceLayoutDirection;
JSExportAs(initWithFrame,
-(id) jsinitWithFrame: (CGRect) frame );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
@end
@protocol UIViewClassExports<JSExport, NSCodingClassExports_, UIAppearanceClassExports_, UIAppearanceContainerClassExports_, UIDynamicItemClassExports_, UITraitEnvironmentClassExports_, UICoordinateSpaceClassExports_, UIFocusItemClassExports_, UIFocusItemContainerClassExports_, CALayerDelegateClassExports_>
+(UIUserInterfaceLayoutDirection) userInterfaceLayoutDirectionForSemanticContentAttribute: (UISemanticContentAttribute) attribute ;
+(UIUserInterfaceLayoutDirection) userInterfaceLayoutDirectionForSemanticContentAttribute: (UISemanticContentAttribute) semanticContentAttribute relativeToLayoutDirection: (UIUserInterfaceLayoutDirection) layoutDirection ;
+(id) layerClass;
@end
@protocol UIViewUIViewGeometryCategoryInstanceExports<JSExport>
@property (nonatomic) CGRect frame;
@property (nonatomic) CGRect bounds;
@property (nonatomic) CGPoint center;
@property (nonatomic) CGAffineTransform transform;
@property (nonatomic) CATransform3D transform3D;
@property (nonatomic) CGFloat contentScaleFactor;
@property (nonatomic) CGPoint anchorPoint;
@property (getter=isMultipleTouchEnabled,nonatomic) BOOL multipleTouchEnabled;
@property (getter=isExclusiveTouch,nonatomic) BOOL exclusiveTouch;
@property (nonatomic) BOOL autoresizesSubviews;
@property (nonatomic) UIViewAutoresizing autoresizingMask;
-(UIView *) hitTest: (CGPoint) point withEvent: (UIEvent *) event ;
-(BOOL) pointInside: (CGPoint) point withEvent: (UIEvent *) event ;
-(CGPoint) convertPoint: (CGPoint) point toView: (UIView *) view ;
-(CGPoint) convertPoint: (CGPoint) point fromView: (UIView *) view ;
-(CGRect) convertRect: (CGRect) rect toView: (UIView *) view ;
-(CGRect) convertRect: (CGRect) rect fromView: (UIView *) view ;
-(CGSize) sizeThatFits: (CGSize) size ;
-(void) sizeToFit;
@end
@protocol UIViewUIViewGeometryCategoryClassExports<JSExport>
@end
@protocol UIViewUIViewHierarchyCategoryInstanceExports<JSExport>
@property (readonly,nonatomic) UIView * superview;
@property (readonly,copy,nonatomic) NSArray * subviews;
@property (readonly,nonatomic) UIWindow * window;
@property (nonatomic) UIEdgeInsets layoutMargins;
@property (nonatomic) NSDirectionalEdgeInsets directionalLayoutMargins;
@property (nonatomic) BOOL preservesSuperviewLayoutMargins;
@property (nonatomic) BOOL insetsLayoutMarginsFromSafeArea;
@property (readonly,nonatomic) UIEdgeInsets safeAreaInsets;
@property (readonly,strong) UILayoutGuide * layoutMarginsGuide;
@property (readonly,nonatomic,strong) UILayoutGuide * readableContentGuide;
@property (readonly,nonatomic,strong) UILayoutGuide * safeAreaLayoutGuide;
@property (readonly,nonatomic,strong) UIKeyboardLayoutGuide * keyboardLayoutGuide;
-(void) removeFromSuperview;
-(void) insertSubview: (UIView *) view atIndex: (NSInteger) index ;
-(void) exchangeSubviewAtIndex: (NSInteger) index1 withSubviewAtIndex: (NSInteger) index2 ;
-(void) addSubview: (UIView *) view ;
-(void) insertSubview: (UIView *) view belowSubview: (UIView *) siblingSubview ;
-(void) insertSubview: (UIView *) view aboveSubview: (UIView *) siblingSubview ;
-(void) bringSubviewToFront: (UIView *) view ;
-(void) sendSubviewToBack: (UIView *) view ;
-(void) didAddSubview: (UIView *) subview ;
-(void) willRemoveSubview: (UIView *) subview ;
-(void) willMoveToSuperview: (UIView *) newSuperview ;
-(void) didMoveToSuperview;
-(void) willMoveToWindow: (UIWindow *) newWindow ;
-(void) didMoveToWindow;
-(BOOL) isDescendantOfView: (UIView *) view ;
-(__kindof UIView *) viewWithTag: (NSInteger) tag ;
-(void) setNeedsLayout;
-(void) layoutIfNeeded;
-(void) layoutSubviews;
-(void) layoutMarginsDidChange;
-(void) safeAreaInsetsDidChange;
@end
@protocol UIViewUIViewHierarchyCategoryClassExports<JSExport>
@end
@protocol UIViewUIViewRenderingCategoryInstanceExports<JSExport>
@property (nonatomic) BOOL clipsToBounds;
@property (copy,nonatomic) UIColor * backgroundColor;
@property (nonatomic) CGFloat alpha;
@property (getter=isOpaque,nonatomic) BOOL opaque;
@property (nonatomic) BOOL clearsContextBeforeDrawing;
@property (getter=isHidden,nonatomic) BOOL hidden;
@property (nonatomic) UIViewContentMode contentMode;
@property (nonatomic) CGRect contentStretch;
@property (nonatomic,strong) UIView * maskView;
@property (nonatomic,strong) UIColor * tintColor;
@property (nonatomic) UIViewTintAdjustmentMode tintAdjustmentMode;
-(void) drawRect: (CGRect) rect ;
-(void) setNeedsDisplay;
-(void) setNeedsDisplayInRect: (CGRect) rect ;
-(void) tintColorDidChange;
@end
@protocol UIViewUIViewRenderingCategoryClassExports<JSExport>
@end
@protocol UIViewUIViewAnimationCategoryInstanceExports<JSExport>
@end
@protocol UIViewUIViewAnimationCategoryClassExports<JSExport>
+(void) setAnimationsEnabled: (BOOL) enabled ;
JSExportAs(performWithoutAnimation,
+(void) jsperformWithoutAnimation: (JSValue *) actionsWithoutAnimation );
+(BOOL) areAnimationsEnabled;
+(NSTimeInterval) inheritedAnimationDuration;
@end
@protocol UIViewUIViewAnimationWithBlocksCategoryInstanceExports<JSExport>
@end
@protocol UIViewUIViewAnimationWithBlocksCategoryClassExports<JSExport>
JSExportAs(animateWithDurationDelayOptionsAnimationsCompletion,
+(void) jsanimateWithDuration: (NSTimeInterval) duration delay: (NSTimeInterval) delay options: (UIViewAnimationOptions) options animations: (JSValue *) animations completion: (JSValue *) completion );
JSExportAs(animateWithDurationAnimationsCompletion,
+(void) jsanimateWithDuration: (NSTimeInterval) duration animations: (JSValue *) animations completion: (JSValue *) completion );
JSExportAs(animateWithDurationAnimations,
+(void) jsanimateWithDuration: (NSTimeInterval) duration animations: (JSValue *) animations );
JSExportAs(animateWithSpringDurationBounceInitialSpringVelocityDelayOptionsAnimationsCompletion,
+(void) jsanimateWithSpringDuration: (NSTimeInterval) duration bounce: (CGFloat) bounce initialSpringVelocity: (CGFloat) velocity delay: (NSTimeInterval) delay options: (UIViewAnimationOptions) options animations: (JSValue *) animations completion: (JSValue *) completion );
JSExportAs(animateWithDurationDelayUsingSpringWithDampingInitialSpringVelocityOptionsAnimationsCompletion,
+(void) jsanimateWithDuration: (NSTimeInterval) duration delay: (NSTimeInterval) delay usingSpringWithDamping: (CGFloat) dampingRatio initialSpringVelocity: (CGFloat) velocity options: (UIViewAnimationOptions) options animations: (JSValue *) animations completion: (JSValue *) completion );
JSExportAs(transitionWithViewDurationOptionsAnimationsCompletion,
+(void) jstransitionWithView: (UIView *) view duration: (NSTimeInterval) duration options: (UIViewAnimationOptions) options animations: (JSValue *) animations completion: (JSValue *) completion );
JSExportAs(transitionFromViewToViewDurationOptionsCompletion,
+(void) jstransitionFromView: (UIView *) fromView toView: (UIView *) toView duration: (NSTimeInterval) duration options: (UIViewAnimationOptions) options completion: (JSValue *) completion );
JSExportAs(performSystemAnimationOnViewsOptionsAnimationsCompletion,
+(void) jsperformSystemAnimation: (UISystemAnimation) animation onViews: (NSArray *) views options: (UIViewAnimationOptions) options animations: (JSValue *) parallelAnimations completion: (JSValue *) completion );
JSExportAs(modifyAnimationsWithRepeatCountAutoreversesAnimations,
+(void) jsmodifyAnimationsWithRepeatCount: (CGFloat) count autoreverses: (BOOL) autoreverses animations: (JSValue *) animations );
@end
@protocol UIViewUIViewKeyframeAnimationsCategoryInstanceExports<JSExport>
@end
@protocol UIViewUIViewKeyframeAnimationsCategoryClassExports<JSExport>
JSExportAs(animateKeyframesWithDurationDelayOptionsAnimationsCompletion,
+(void) jsanimateKeyframesWithDuration: (NSTimeInterval) duration delay: (NSTimeInterval) delay options: (UIViewKeyframeAnimationOptions) options animations: (JSValue *) animations completion: (JSValue *) completion );
JSExportAs(addKeyframeWithRelativeStartTimeRelativeDurationAnimations,
+(void) jsaddKeyframeWithRelativeStartTime: (double) frameStartTime relativeDuration: (double) frameDuration animations: (JSValue *) animations );
@end
@protocol UIViewUIViewGestureRecognizersCategoryInstanceExports<JSExport>
@property (copy,nonatomic) NSArray * gestureRecognizers;
-(void) addGestureRecognizer: (UIGestureRecognizer *) gestureRecognizer ;
-(void) removeGestureRecognizer: (UIGestureRecognizer *) gestureRecognizer ;
-(BOOL) gestureRecognizerShouldBegin: (UIGestureRecognizer *) gestureRecognizer ;
@end
@protocol UIViewUIViewGestureRecognizersCategoryClassExports<JSExport>
@end
@protocol UIViewUIViewMotionEffectsCategoryInstanceExports<JSExport>
@property (copy,nonatomic) NSArray * motionEffects;
-(void) addMotionEffect: (UIMotionEffect *) effect ;
-(void) removeMotionEffect: (UIMotionEffect *) effect ;
@end
@protocol UIViewUIViewMotionEffectsCategoryClassExports<JSExport>
@end
@protocol UIViewUIConstraintBasedLayoutInstallingConstraintsCategoryInstanceExports<JSExport>
@property (readonly,nonatomic) NSArray * constraints;
-(void) addConstraint: (NSLayoutConstraint *) constraint ;
-(void) addConstraints: (NSArray *) constraints ;
-(void) removeConstraint: (NSLayoutConstraint *) constraint ;
-(void) removeConstraints: (NSArray *) constraints ;
@end
@protocol UIViewUIConstraintBasedLayoutInstallingConstraintsCategoryClassExports<JSExport>
@end
@protocol UIViewUIConstraintBasedLayoutCoreMethodsCategoryInstanceExports<JSExport>
-(void) updateConstraintsIfNeeded;
-(void) updateConstraints;
-(BOOL) needsUpdateConstraints;
-(void) setNeedsUpdateConstraints;
@end
@protocol UIViewUIConstraintBasedLayoutCoreMethodsCategoryClassExports<JSExport>
@end
@protocol UIViewUIConstraintBasedCompatibilityCategoryInstanceExports<JSExport>
@property (nonatomic) BOOL translatesAutoresizingMaskIntoConstraints;
@end
@protocol UIViewUIConstraintBasedCompatibilityCategoryClassExports<JSExport>
+(BOOL) requiresConstraintBasedLayout;
@end
@protocol UIViewUIConstraintBasedLayoutLayeringCategoryInstanceExports<JSExport>
@property (readonly,nonatomic) UIEdgeInsets alignmentRectInsets;
@property (readonly,strong) UIView * viewForFirstBaselineLayout;
@property (readonly,strong) UIView * viewForLastBaselineLayout;
@property (readonly,nonatomic) CGSize intrinsicContentSize;
-(CGRect) alignmentRectForFrame: (CGRect) frame ;
-(CGRect) frameForAlignmentRect: (CGRect) alignmentRect ;
-(UIView *) viewForBaselineLayout;
-(void) invalidateIntrinsicContentSize;
-(UILayoutPriority) contentHuggingPriorityForAxis: (UILayoutConstraintAxis) axis ;
-(void) setContentHuggingPriority: (UILayoutPriority) priority forAxis: (UILayoutConstraintAxis) axis ;
-(UILayoutPriority) contentCompressionResistancePriorityForAxis: (UILayoutConstraintAxis) axis ;
-(void) setContentCompressionResistancePriority: (UILayoutPriority) priority forAxis: (UILayoutConstraintAxis) axis ;
@end
@protocol UIViewUIConstraintBasedLayoutLayeringCategoryClassExports<JSExport>
@end
@protocol UIViewUIConstraintBasedLayoutFittingSizeCategoryInstanceExports<JSExport>
-(CGSize) systemLayoutSizeFittingSize: (CGSize) targetSize ;
-(CGSize) systemLayoutSizeFittingSize: (CGSize) targetSize withHorizontalFittingPriority: (UILayoutPriority) horizontalFittingPriority verticalFittingPriority: (UILayoutPriority) verticalFittingPriority ;
@end
@protocol UIViewUIConstraintBasedLayoutFittingSizeCategoryClassExports<JSExport>
@end
@protocol UIViewUILayoutGuideSupportCategoryInstanceExports<JSExport>
@property (readonly,copy,nonatomic) NSArray * layoutGuides;
-(void) addLayoutGuide: (UILayoutGuide *) layoutGuide ;
-(void) removeLayoutGuide: (UILayoutGuide *) layoutGuide ;
@end
@protocol UIViewUILayoutGuideSupportCategoryClassExports<JSExport>
@end
@protocol UIViewUIViewLayoutConstraintCreationCategoryInstanceExports<JSExport>
@property (readonly,nonatomic,strong) NSLayoutXAxisAnchor * leadingAnchor;
@property (readonly,nonatomic,strong) NSLayoutXAxisAnchor * trailingAnchor;
@property (readonly,nonatomic,strong) NSLayoutXAxisAnchor * leftAnchor;
@property (readonly,nonatomic,strong) NSLayoutXAxisAnchor * rightAnchor;
@property (readonly,nonatomic,strong) NSLayoutYAxisAnchor * topAnchor;
@property (readonly,nonatomic,strong) NSLayoutYAxisAnchor * bottomAnchor;
@property (readonly,nonatomic,strong) NSLayoutDimension * widthAnchor;
@property (readonly,nonatomic,strong) NSLayoutDimension * heightAnchor;
@property (readonly,nonatomic,strong) NSLayoutXAxisAnchor * centerXAnchor;
@property (readonly,nonatomic,strong) NSLayoutYAxisAnchor * centerYAnchor;
@property (readonly,nonatomic,strong) NSLayoutYAxisAnchor * firstBaselineAnchor;
@property (readonly,nonatomic,strong) NSLayoutYAxisAnchor * lastBaselineAnchor;
@end
@protocol UIViewUIViewLayoutConstraintCreationCategoryClassExports<JSExport>
@end
@protocol UIViewUIConstraintBasedLayoutDebuggingCategoryInstanceExports<JSExport>
@property (readonly,nonatomic) BOOL hasAmbiguousLayout;
-(NSArray *) constraintsAffectingLayoutForAxis: (UILayoutConstraintAxis) axis ;
-(void) exerciseAmbiguityInLayout;
@end
@protocol UIViewUIConstraintBasedLayoutDebuggingCategoryClassExports<JSExport>
@end
@protocol UILayoutGuideUIConstraintBasedLayoutDebuggingCategoryInstanceExports<JSExport>
@property (readonly,nonatomic) BOOL hasAmbiguousLayout;
-(NSArray *) constraintsAffectingLayoutForAxis: (UILayoutConstraintAxis) axis ;
@end
@protocol UILayoutGuideUIConstraintBasedLayoutDebuggingCategoryClassExports<JSExport>
@end
@protocol UIViewUIStateRestorationCategoryInstanceExports<JSExport>
@property (copy,nonatomic) NSString * restorationIdentifier;
-(void) encodeRestorableStateWithCoder: (NSCoder *) coder ;
-(void) decodeRestorableStateWithCoder: (NSCoder *) coder ;
@end
@protocol UIViewUIStateRestorationCategoryClassExports<JSExport>
@end
@protocol UIViewUISnapshottingCategoryInstanceExports<JSExport>
-(UIView *) snapshotViewAfterScreenUpdates: (BOOL) afterUpdates ;
-(UIView *) resizableSnapshotViewFromRect: (CGRect) rect afterScreenUpdates: (BOOL) afterUpdates withCapInsets: (UIEdgeInsets) capInsets ;
-(BOOL) drawViewHierarchyInRect: (CGRect) rect afterScreenUpdates: (BOOL) afterUpdates ;
@end
@protocol UIViewUISnapshottingCategoryClassExports<JSExport>
@end
@protocol UIViewDeprecatedAnimationsCategoryInstanceExports<JSExport>
@end
@protocol UIViewDeprecatedAnimationsCategoryClassExports<JSExport>
+(void) commitAnimations;
+(void) setAnimationDelegate: (id) delegate ;
JSExportAs(setAnimationWillStartSelector,
+(void) jssetAnimationWillStartSelector: (NSString *) selector );
JSExportAs(setAnimationDidStopSelector,
+(void) jssetAnimationDidStopSelector: (NSString *) selector );
+(void) setAnimationDuration: (NSTimeInterval) duration ;
+(void) setAnimationDelay: (NSTimeInterval) delay ;
+(void) setAnimationStartDate: (NSDate *) startDate ;
+(void) setAnimationCurve: (UIViewAnimationCurve) curve ;
+(void) setAnimationRepeatCount: (float) repeatCount ;
+(void) setAnimationRepeatAutoreverses: (BOOL) repeatAutoreverses ;
+(void) setAnimationBeginsFromCurrentState: (BOOL) fromCurrentState ;
+(void) setAnimationTransition: (UIViewAnimationTransition) transition forView: (UIView *) view cache: (BOOL) cache ;
@end
@protocol UIViewUserInterfaceStyleCategoryInstanceExports<JSExport>
@property (nonatomic) UIUserInterfaceStyle overrideUserInterfaceStyle;
@end
@protocol UIViewUserInterfaceStyleCategoryClassExports<JSExport>
@end
@protocol UIViewUIContentSizeCategoryLimitCategoryInstanceExports<JSExport>
@property (copy,nonatomic) UIContentSizeCategory minimumContentSizeCategory;
@property (copy,nonatomic) UIContentSizeCategory maximumContentSizeCategory;
@property (readonly,copy,nonatomic) NSString * appliedContentSizeCategoryLimitsDescription;
@end
@protocol UIViewUIContentSizeCategoryLimitCategoryClassExports<JSExport>
@end
@protocol UIViewAnonCategoryInstanceExports<JSExport, UITraitChangeObservableInstanceExports_>
@property (readonly,nonatomic) id traitOverrides;
-(void) updateTraitsIfNeeded;
@end
@protocol UIViewAnonCategoryClassExports<JSExport, UITraitChangeObservableClassExports_>
@end
@protocol UICoordinateSpaceInstanceExports_<JSExport, NSObjectInstanceExports_>
@property (readonly,nonatomic) CGRect bounds;
-(CGPoint) convertPoint: (CGPoint) point toCoordinateSpace: (id) coordinateSpace ;
-(CGPoint) convertPoint: (CGPoint) point fromCoordinateSpace: (id) coordinateSpace ;
-(CGRect) convertRect: (CGRect) rect toCoordinateSpace: (id) coordinateSpace ;
-(CGRect) convertRect: (CGRect) rect fromCoordinateSpace: (id) coordinateSpace ;
@end
@protocol UICoordinateSpaceClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop