#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIViewAnimating_symbols(JSContext*);
@protocol UIViewAnimatingInstanceExports_<JSExport, NSObjectInstanceExports_>
@property (readonly,nonatomic) UIViewAnimatingState state;
@property (getter=isRunning,readonly,nonatomic) BOOL running;
@property (getter=isReversed,nonatomic) BOOL reversed;
@property (nonatomic) CGFloat fractionComplete;
-(void) startAnimation;
-(void) startAnimationAfterDelay: (NSTimeInterval) delay ;
-(void) pauseAnimation;
-(void) stopAnimation: (BOOL) withoutFinishing ;
-(void) finishAnimationAtPosition: (UIViewAnimatingPosition) finalPosition ;
@end
@protocol UIViewAnimatingClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UIViewImplicitlyAnimatingInstanceExports_<JSExport, UIViewAnimatingInstanceExports_>
JSExportAs(addAnimationsDelayFactor,
-(void) jsaddAnimations: (JSValue *) animation delayFactor: (CGFloat) delayFactor );
JSExportAs(addAnimations,
-(void) jsaddAnimations: (JSValue *) animation );
JSExportAs(addCompletion,
-(void) jsaddCompletion: (JSValue *) completion );
-(void) continueAnimationWithTimingParameters: (id) parameters durationFactor: (CGFloat) durationFactor ;
@end
@protocol UIViewImplicitlyAnimatingClassExports_<JSExport, UIViewAnimatingClassExports_>
@end
#pragma clang diagnostic pop