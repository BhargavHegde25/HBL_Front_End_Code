#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIViewControllerTransitioning_symbols(JSContext*);
@protocol UIPercentDrivenInteractiveTransitionInstanceExports<JSExport, UIViewControllerInteractiveTransitioningInstanceExports_>
@property (readonly) CGFloat duration;
@property (readonly) CGFloat percentComplete;
@property (assign,nonatomic) CGFloat completionSpeed;
@property (assign,nonatomic) UIViewAnimationCurve completionCurve;
@property (nonatomic,strong) id timingCurve;
@property (nonatomic) BOOL wantsInteractiveStart;
-(void) pauseInteractiveTransition;
-(void) updateInteractiveTransition: (CGFloat) percentComplete ;
-(void) cancelInteractiveTransition;
-(void) finishInteractiveTransition;
@end
@protocol UIPercentDrivenInteractiveTransitionClassExports<JSExport, UIViewControllerInteractiveTransitioningClassExports_>
@end
@protocol UIViewControllerContextTransitioningInstanceExports_<JSExport, NSObjectInstanceExports_>
@property (readonly,nonatomic) UIView * containerView;
@property (getter=isAnimated,readonly,nonatomic) BOOL animated;
@property (getter=isInteractive,readonly,nonatomic) BOOL interactive;
@property (readonly,nonatomic) BOOL transitionWasCancelled;
@property (readonly,nonatomic) UIModalPresentationStyle presentationStyle;
@property (readonly,nonatomic) CGAffineTransform targetTransform;
-(void) updateInteractiveTransition: (CGFloat) percentComplete ;
-(void) finishInteractiveTransition;
-(void) cancelInteractiveTransition;
-(void) pauseInteractiveTransition;
-(void) completeTransition: (BOOL) didComplete ;
-(__kindof UIViewController *) viewControllerForKey: (UITransitionContextViewControllerKey) key ;
-(__kindof UIView *) viewForKey: (UITransitionContextViewKey) key ;
JSExportAs(initialFrameForViewController,
-(CGRect) jsinitialFrameForViewController: (UIViewController *) vc );
-(CGRect) finalFrameForViewController: (UIViewController *) vc ;
@end
@protocol UIViewControllerContextTransitioningClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UIViewControllerAnimatedTransitioningInstanceExports_<JSExport, NSObjectInstanceExports_>
-(NSTimeInterval) transitionDuration: (id) transitionContext ;
-(void) animateTransition: (id) transitionContext ;
-(id) interruptibleAnimatorForTransition: (id) transitionContext ;
-(void) animationEnded: (BOOL) transitionCompleted ;
@end
@protocol UIViewControllerAnimatedTransitioningClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UIViewControllerInteractiveTransitioningInstanceExports_<JSExport, NSObjectInstanceExports_>
@property (readonly,nonatomic) CGFloat completionSpeed;
@property (readonly,nonatomic) UIViewAnimationCurve completionCurve;
@property (readonly,nonatomic) BOOL wantsInteractiveStart;
-(void) startInteractiveTransition: (id) transitionContext ;
@end
@protocol UIViewControllerInteractiveTransitioningClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UIViewControllerTransitioningDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(id) animationControllerForPresentedController: (UIViewController *) presented presentingController: (UIViewController *) presenting sourceController: (UIViewController *) source ;
-(id) animationControllerForDismissedController: (UIViewController *) dismissed ;
-(id) interactionControllerForPresentation: (id) animator ;
-(id) interactionControllerForDismissal: (id) animator ;
-(UIPresentationController *) presentationControllerForPresentedViewController: (UIViewController *) presented presentingViewController: (UIViewController *) presenting sourceViewController: (UIViewController *) source ;
@end
@protocol UIViewControllerTransitioningDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop