#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIWindow_symbols(JSContext*);
@protocol UIWindowInstanceExports<JSExport>
@property (nonatomic,weak) UIWindowScene * windowScene;
@property (setter=setCanResizeToFitContent:,nonatomic) BOOL canResizeToFitContent;
@property (nonatomic,strong) UIScreen * screen;
@property (getter=isKeyWindow,readonly,nonatomic) BOOL keyWindow;
@property (readonly,nonatomic) BOOL canBecomeKeyWindow;
@property (nonatomic,strong) UIViewController * rootViewController;
JSExportAs(initWithWindowScene,
-(id) jsinitWithWindowScene: (UIWindowScene *) windowScene );
-(void) setScreen: (UIScreen *) screen ;
-(void) becomeKeyWindow;
-(void) resignKeyWindow;
-(void) makeKeyWindow;
-(void) makeKeyAndVisible;
-(void) sendEvent: (UIEvent *) event ;
-(CGPoint) convertPoint: (CGPoint) point toWindow: (UIWindow *) window ;
-(CGPoint) convertPoint: (CGPoint) point fromWindow: (UIWindow *) window ;
-(CGRect) convertRect: (CGRect) rect toWindow: (UIWindow *) window ;
-(CGRect) convertRect: (CGRect) rect fromWindow: (UIWindow *) window ;
@end
@protocol UIWindowClassExports<JSExport>
@end
@protocol UIWindowUIWindowLayoutCategoryInstanceExports<JSExport>
@property (readonly,nonatomic,strong) UILayoutGuide * safeAreaAspectFitLayoutGuide;
@end
@protocol UIWindowUIWindowLayoutCategoryClassExports<JSExport>
@end
@protocol UILayoutGuideAspectFittingInstanceExports_<JSExport, NSObjectInstanceExports_>
@property (readwrite,nonatomic) CGFloat aspectRatio;
@end
@protocol UILayoutGuideAspectFittingClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop