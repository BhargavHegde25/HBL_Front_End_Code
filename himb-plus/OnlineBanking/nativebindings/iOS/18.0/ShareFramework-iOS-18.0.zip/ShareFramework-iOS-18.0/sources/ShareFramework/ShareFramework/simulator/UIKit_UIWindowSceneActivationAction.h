#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIWindowSceneActivationAction_symbols(JSContext*);
@protocol UIWindowSceneActivationActionInstanceExports<JSExport>
@property (copy,nonatomic) NSString * title;
@end
@protocol UIWindowSceneActivationActionClassExports<JSExport>
JSExportAs(actionWithIdentifierAlternateActionConfigurationProvider,
+(id) jsactionWithIdentifier: (UIActionIdentifier) identifier alternateAction: (UIAction *) alternateAction configurationProvider: (JSValue *) configurationProvider );
@end
#pragma clang diagnostic pop