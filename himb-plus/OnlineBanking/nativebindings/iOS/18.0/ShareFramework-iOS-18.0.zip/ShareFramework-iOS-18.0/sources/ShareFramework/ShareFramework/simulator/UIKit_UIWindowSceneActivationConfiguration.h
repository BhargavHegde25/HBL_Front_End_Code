#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIWindowSceneActivationConfiguration_symbols(JSContext*);
@protocol UIWindowSceneActivationConfigurationInstanceExports<JSExport>
@property (readonly,nonatomic,strong) NSUserActivity * userActivity;
@property (nonatomic,strong) UIWindowSceneActivationRequestOptions * options;
@property (nonatomic,strong) UITargetedPreview * preview;
JSExportAs(initWithUserActivity,
-(id) jsinitWithUserActivity: (NSUserActivity *) userActivity );
@end
@protocol UIWindowSceneActivationConfigurationClassExports<JSExport>
@end
#pragma clang diagnostic pop