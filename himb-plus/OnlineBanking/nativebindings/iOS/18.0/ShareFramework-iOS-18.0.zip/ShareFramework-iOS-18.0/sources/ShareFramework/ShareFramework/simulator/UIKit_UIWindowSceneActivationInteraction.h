#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIWindowSceneActivationInteraction_symbols(JSContext*);
@protocol UIWindowSceneActivationInteractionInstanceExports<JSExport, UIInteractionInstanceExports_>
JSExportAs(initWithConfigurationProviderErrorHandler,
-(id) jsinitWithConfigurationProvider: (JSValue *) configurationProvider errorHandler: (JSValue *) errorHandler );
@end
@protocol UIWindowSceneActivationInteractionClassExports<JSExport, UIInteractionClassExports_>
@end
#pragma clang diagnostic pop