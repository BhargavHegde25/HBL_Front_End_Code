#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIWindowSceneActivationRequestOptions_symbols(JSContext*);
@protocol UIWindowSceneActivationRequestOptionsInstanceExports<JSExport>
@property (readwrite,nonatomic) UIWindowScenePresentationStyle preferredPresentationStyle;
@property (copy,nonatomic) UIWindowScenePlacement * placement;
@end
@protocol UIWindowSceneActivationRequestOptionsClassExports<JSExport>
@end
#pragma clang diagnostic pop