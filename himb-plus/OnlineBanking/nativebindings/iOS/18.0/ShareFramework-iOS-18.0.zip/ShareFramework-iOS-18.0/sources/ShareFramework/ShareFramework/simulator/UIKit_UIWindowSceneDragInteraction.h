#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIWindowSceneDragInteraction_symbols(JSContext*);
@protocol UIWindowSceneDragInteractionInstanceExports<JSExport, UIInteractionInstanceExports_>
@property (readonly,nonatomic) UIGestureRecognizer * gestureForFailureRelationships;
@end
@protocol UIWindowSceneDragInteractionClassExports<JSExport, UIInteractionClassExports_>
@end
#pragma clang diagnostic pop