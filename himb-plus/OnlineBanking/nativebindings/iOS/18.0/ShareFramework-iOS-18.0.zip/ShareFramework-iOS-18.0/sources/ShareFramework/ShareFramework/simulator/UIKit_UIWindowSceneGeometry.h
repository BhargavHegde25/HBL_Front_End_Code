#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIWindowSceneGeometry_symbols(JSContext*);
@protocol UIWindowSceneGeometryInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (readonly,nonatomic) UIInterfaceOrientation interfaceOrientation;
@end
@protocol UIWindowSceneGeometryClassExports<JSExport, NSCopyingClassExports_>
@end
#pragma clang diagnostic pop