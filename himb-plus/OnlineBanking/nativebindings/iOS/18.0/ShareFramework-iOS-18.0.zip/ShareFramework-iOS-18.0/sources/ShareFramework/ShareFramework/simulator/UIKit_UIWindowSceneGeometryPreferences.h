#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIWindowSceneGeometryPreferences_symbols(JSContext*);
@protocol UIWindowSceneGeometryPreferencesInstanceExports<JSExport>
@end
@protocol UIWindowSceneGeometryPreferencesClassExports<JSExport>
@end
#pragma clang diagnostic pop