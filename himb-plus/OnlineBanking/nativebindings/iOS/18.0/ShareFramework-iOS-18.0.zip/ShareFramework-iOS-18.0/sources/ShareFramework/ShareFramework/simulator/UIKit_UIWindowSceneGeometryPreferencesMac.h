#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIWindowSceneGeometryPreferencesMac_symbols(JSContext*);
@protocol UIWindowSceneGeometryPreferencesMacInstanceExports<JSExport>
@property (assign,nonatomic) CGRect systemFrame;
-(id) jsinit;
JSExportAs(initWithSystemFrame,
-(id) jsinitWithSystemFrame: (CGRect) systemFrame );
@end
@protocol UIWindowSceneGeometryPreferencesMacClassExports<JSExport>
@end
#pragma clang diagnostic pop