#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIWindowSceneProminentPlacement_symbols(JSContext*);
@protocol UIWindowSceneProminentPlacementInstanceExports<JSExport>
@end
@protocol UIWindowSceneProminentPlacementClassExports<JSExport>
+(id) prominentPlacement;
@end
#pragma clang diagnostic pop