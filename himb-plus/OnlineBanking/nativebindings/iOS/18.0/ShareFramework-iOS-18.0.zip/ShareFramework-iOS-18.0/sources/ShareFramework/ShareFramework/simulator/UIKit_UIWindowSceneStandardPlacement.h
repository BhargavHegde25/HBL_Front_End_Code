#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIWindowSceneStandardPlacement_symbols(JSContext*);
@protocol UIWindowSceneStandardPlacementInstanceExports<JSExport>
@end
@protocol UIWindowSceneStandardPlacementClassExports<JSExport>
+(id) standardPlacement;
@end
#pragma clang diagnostic pop